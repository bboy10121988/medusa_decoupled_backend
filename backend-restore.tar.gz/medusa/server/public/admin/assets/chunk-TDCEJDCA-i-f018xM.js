import{aP as i}from"./index-DlpviiKV.js";var a=i("product","*categories,*shipping_profile,-variants");export{a as P};
