import{ap as c}from"./index-DlpviiKV.js";function m(o,r){const[t]=c(),s={};return o.forEach(a=>{const e=r?`${r}_${a}`:a,u=t.get(e)||void 0;s[a]=u}),s}export{m as u};
