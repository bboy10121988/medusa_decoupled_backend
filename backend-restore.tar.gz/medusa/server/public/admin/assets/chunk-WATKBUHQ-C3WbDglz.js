var a=(r,t)=>new Intl.NumberFormat(void 0,{style:"currency",currency:t,signDisplay:"auto"}).format(r);export{a as f};
