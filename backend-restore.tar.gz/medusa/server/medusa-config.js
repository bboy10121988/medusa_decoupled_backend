"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
function requiredEnv(key) {
    const value = process.env[key];
    if (!value) {
        throw new Error(`Environment variable ${key} is required but not defined.`);
    }
    return value;
}
(0, utils_1.loadEnv)(process.env.NODE_ENV || 'development', process.cwd());
// Default CORS settings for development and production
const DEFAULT_STORE_CORS = 'http://localhost:8000,https://timsfantasyworld.com';
const DEFAULT_ADMIN_CORS = "http://localhost:7001,http://localhost:9000,https://admin.timsfantasyworld.com,http://admin.timsfantasyworld.com,http://localhost:8000,http://35.185.142.194:9000";
const DEFAULT_AUTH_CORS = 'http://localhost:8000,http://localhost:9000,https://timsfantasyworld.com,https://admin.timsfantasyworld.com';
module.exports = (0, utils_1.defineConfig)({
    admin: {
        disable: false,
        backendUrl: "https://admin.timsfantasyworld.com"
    },
    projectConfig: {
        databaseUrl: process.env.DATABASE_URL,
        // Redis 配置 - 用於會話存儲和緩存
        redisUrl: process.env.REDIS_URL || 'redis://localhost:6379',
        http: {
            // CORS configuration for different parts of the application
            storeCors: process.env.STORE_CORS || DEFAULT_STORE_CORS,
            adminCors: process.env.ADMIN_CORS || DEFAULT_ADMIN_CORS,
            authCors: process.env.AUTH_CORS || DEFAULT_AUTH_CORS,
            jwtSecret: 'medusa-jwt-secret-2024-production-key-secure',
            cookieSecret: 'medusa-cookie-secret-2024-production-key-secure',
            // 🔐 定義不同角色可使用的認證方法
            authMethodsPerActor: {
                customer: ['emailpass', 'google'], // 顧客使用 Email/Password 或 Google 登入
                user: ['emailpass'], // 管理員使用 Email/Password 登入
            },
        }
    },
    modules: [
        {
            resolve: '@medusajs/auth',
            dependencies: [utils_1.Modules.CACHE, utils_1.ContainerRegistrationKeys.LOGGER],
            options: {
                providers: [
                    // Email/Password Provider
                    {
                        resolve: '@medusajs/auth-emailpass',
                        id: 'emailpass',
                    },
                    // Google OAuth Provider
                    {
                        resolve: '@medusajs/auth-google',
                        id: 'google',
                        options: {
                            clientId: process.env.GOOGLE_CLIENT_ID || '',
                            clientSecret: process.env.GOOGLE_CLIENT_SECRET || '',
                            callbackUrl: (() => {
                                const url = process.env.GOOGLE_CALLBACK_URL || 'https://admin.timsfantasyworld.com/auth/customer/google/callback';
                                return url;
                            })(),
                            // ✅ Medusa v2 verify callback
                            verify: async (container, req, accessToken, refreshToken, profile, done) => {
                                // 強制寫入 /tmp 下唯一的 debug log
                                const fs = require('fs');
                                function log(message) {
                                    try {
                                        const time = new Date().toISOString();
                                        fs.appendFileSync('/tmp/medusa-auth-debug.log', `[${time}] ${message}\n`);
                                    }
                                    catch (err) {
                                        console.error("Failed to write log:", err);
                                    }
                                }
                                log("🚀 Google Verify Callback STARTED 🚀");
                                try {
                                    log("Container available: " + (!!container));
                                    log("Profile ID: " + (profile?.id || 'unknown'));
                                }
                                catch (e) {
                                    log("Error in initial logging: " + e.message);
                                }
                                // --- 原本的邏輯 ---
                                // 處理 profile 結構可能不同的情況
                                const json = profile._json || profile;
                                const email = json.email;
                                const given_name = json.given_name;
                                const family_name = json.family_name;
                                const picture = json.picture;
                                const googleUserId = json.sub || json.id;
                                if (!email) {
                                    log("❌ Google profile missing email");
                                    return done(null, false, { message: 'Google profile did not return an email.' });
                                }
                                try {
                                    // 使用 Medusa v2 的 query API 檢查用戶是否存在
                                    const query = container.resolve("query");
                                    const { data: customers } = await query.graph({
                                        entity: "customer",
                                        fields: ["id", "email", "first_name", "last_name", "has_account"],
                                        filters: { email },
                                    });
                                    if (customers && customers.length > 0) {
                                        log(`✅ Google Auth: Customer ${email} already exists. Logging in.`);
                                        return done(null, customers[0]);
                                    }
                                    // 使用 Medusa v2 的 workflow 創建新用戶
                                    log(`➕ Google Auth: Creating new customer for ${email}...`);
                                    const { createCustomersWorkflow } = require('@medusajs/core-flows');
                                    // 注意: createCustomersWorkflow 需要傳入 container 或 invoke
                                    // 這裡嘗試直接傳入 container
                                    log("Running createCustomersWorkflow...");
                                    const { result } = await createCustomersWorkflow(container).run({
                                        input: {
                                            customersData: [{
                                                    email,
                                                    first_name: given_name || '',
                                                    last_name: family_name || '',
                                                    has_account: true,
                                                    metadata: {
                                                        auth_provider: 'google',
                                                        google_user_id: googleUserId,
                                                        picture,
                                                    }
                                                }]
                                        }
                                    });
                                    const newCustomer = result[0];
                                    log(`✅ Google Auth: New customer created: ${newCustomer.id}`);
                                    return done(null, newCustomer);
                                }
                                catch (error) {
                                    log("❌ Google Auth: Error in verify callback: " + error.message);
                                    log("Stack: " + error.stack);
                                    return done(error, false);
                                }
                            }
                        },
                    },
                ],
            },
        },
        {
            // Payment provider module
            resolve: '@medusajs/payment',
            options: {
                providers: [
                    {
                        // ECPay 信用卡支付
                        resolve: './src/modules/ecpayments',
                        id: 'ecpay_credit_card',
                        options: {},
                    },
                ],
            },
        },
        {
            // Notification module - 使用 Local 提供者（Resend 透過自定義訂閱者處理）
            resolve: '@medusajs/notification',
            options: {
                providers: [
                    // Local Provider - 實際郵件透過 Resend 在訂閱者中發送
                    {
                        resolve: '@medusajs/notification-local',
                        id: 'local',
                        options: {
                            channels: ['email'],
                        },
                    }
                ],
            },
        }, {
            // Redis 緩存模組 - 提升性能
            resolve: '@medusajs/cache-redis',
            key: utils_1.Modules.CACHE,
            options: {
                redisUrl: process.env.REDIS_URL || 'redis://localhost:6379',
            },
        },
        {
            // File service 配置
            // ⚠️ file-local 的 URL 生成邏輯：backend_url + '/' + fileKey
            // fileKey 只包含檔案名稱，不含 upload_dir 路徑
            // 因此 backend_url 必須包含完整的 URL 路徑前綴
            resolve: '@medusajs/file',
            key: utils_1.Modules.FILE,
            options: {
                providers: [
                    {
                        resolve: '@medusajs/file-local',
                        id: 'local',
                        options: {
                            // 檔案實際存儲位置（相對於專案根目錄）
                            upload_dir: 'static/uploads',
                            // URL 前綴（必須包含完整路徑，因為 file-local 只會在後面加檔案名稱）
                            backend_url: (process.env.BACKEND_URL || 'https://admin.timsfantasyworld.com') + '/static/uploads',
                        },
                    },
                ],
            },
        },
        {
            resolve: "./src/modules/affiliate",
        },
    ],
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVkdXNhLWNvbmZpZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL21lZHVzYS1jb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBcUc7QUFHckcsU0FBUyxXQUFXLENBQUMsR0FBVztJQUM5QixNQUFNLEtBQUssR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQzlCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNYLE1BQU0sSUFBSSxLQUFLLENBQUMsd0JBQXdCLEdBQUcsK0JBQStCLENBQUMsQ0FBQTtJQUM3RSxDQUFDO0lBQ0QsT0FBTyxLQUFLLENBQUE7QUFDZCxDQUFDO0FBRUQsSUFBQSxlQUFPLEVBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLElBQUksYUFBYSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFBO0FBRTdELHVEQUF1RDtBQUN2RCxNQUFNLGtCQUFrQixHQUFHLG9EQUFvRCxDQUFBO0FBQy9FLE1BQU0sa0JBQWtCLEdBQUcsbUtBQW1LLENBQUE7QUFDOUwsTUFBTSxpQkFBaUIsR0FBRyw2R0FBNkcsQ0FBQTtBQUV2SSxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUEsb0JBQVksRUFBQztJQUM1QixLQUFLLEVBQUU7UUFDTCxPQUFPLEVBQUUsS0FBSztRQUNkLFVBQVUsRUFBRSxvQ0FBb0M7S0FDakQ7SUFDRCxhQUFhLEVBQUU7UUFDYixXQUFXLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZO1FBQ3JDLHVCQUF1QjtRQUN2QixRQUFRLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLElBQUksd0JBQXdCO1FBQzNELElBQUksRUFBRTtZQUNKLDREQUE0RDtZQUM1RCxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLElBQUksa0JBQWtCO1lBQ3ZELFNBQVMsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsSUFBSSxrQkFBa0I7WUFDdkQsUUFBUSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxJQUFJLGlCQUFpQjtZQUNwRCxTQUFTLEVBQUUsOENBQThDO1lBQ3pELFlBQVksRUFBRSxpREFBaUQ7WUFDL0Qsb0JBQW9CO1lBQ3BCLG1CQUFtQixFQUFFO2dCQUNuQixRQUFRLEVBQUUsQ0FBQyxXQUFXLEVBQUUsUUFBUSxDQUFDLEVBQUUsa0NBQWtDO2dCQUNyRSxJQUFJLEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFBZ0IsMEJBQTBCO2FBQzlEO1NBQ0Y7S0FDRjtJQUNELE9BQU8sRUFBRTtRQUNQO1lBQ0UsT0FBTyxFQUFFLGdCQUFnQjtZQUN6QixZQUFZLEVBQUUsQ0FBQyxlQUFPLENBQUMsS0FBSyxFQUFFLGlDQUF5QixDQUFDLE1BQU0sQ0FBQztZQUMvRCxPQUFPLEVBQUU7Z0JBQ1AsU0FBUyxFQUFFO29CQUNULDBCQUEwQjtvQkFDMUI7d0JBQ0UsT0FBTyxFQUFFLDBCQUEwQjt3QkFDbkMsRUFBRSxFQUFFLFdBQVc7cUJBQ2hCO29CQUNELHdCQUF3QjtvQkFDeEI7d0JBQ0UsT0FBTyxFQUFFLHVCQUF1Qjt3QkFDaEMsRUFBRSxFQUFFLFFBQVE7d0JBQ1osT0FBTyxFQUFFOzRCQUNQLFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixJQUFJLEVBQUU7NEJBQzVDLFlBQVksRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixJQUFJLEVBQUU7NEJBQ3BELFdBQVcsRUFBRSxDQUFDLEdBQUcsRUFBRTtnQ0FDakIsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsSUFBSSxrRUFBa0UsQ0FBQTtnQ0FDakgsT0FBTyxHQUFHLENBQUE7NEJBQ1osQ0FBQyxDQUFDLEVBQUU7NEJBQ0osOEJBQThCOzRCQUM5QixNQUFNLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsV0FBVyxFQUFFLFlBQVksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUU7Z0NBQ3pFLDJCQUEyQjtnQ0FDM0IsTUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO2dDQUN6QixTQUFTLEdBQUcsQ0FBQyxPQUFPO29DQUNsQixJQUFJLENBQUM7d0NBQ0gsTUFBTSxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQzt3Q0FDdEMsRUFBRSxDQUFDLGNBQWMsQ0FBQyw0QkFBNEIsRUFBRSxJQUFJLElBQUksS0FBSyxPQUFPLElBQUksQ0FBQyxDQUFDO29DQUM1RSxDQUFDO29DQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7d0NBQ2IsT0FBTyxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsRUFBRSxHQUFHLENBQUMsQ0FBQztvQ0FDN0MsQ0FBQztnQ0FDSCxDQUFDO2dDQUVELEdBQUcsQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDO2dDQUM1QyxJQUFJLENBQUM7b0NBQ0gsR0FBRyxDQUFDLHVCQUF1QixHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7b0NBQzdDLEdBQUcsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxPQUFPLEVBQUUsRUFBRSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0NBQ25ELENBQUM7Z0NBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztvQ0FDWCxHQUFHLENBQUMsNEJBQTRCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dDQUNoRCxDQUFDO2dDQUVELGdCQUFnQjtnQ0FFaEIsdUJBQXVCO2dDQUN2QixNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsS0FBSyxJQUFJLE9BQU8sQ0FBQztnQ0FDdEMsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztnQ0FDekIsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztnQ0FDbkMsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztnQ0FDckMsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztnQ0FDN0IsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsRUFBRSxDQUFDO2dDQUV6QyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7b0NBQ1gsR0FBRyxDQUFDLGdDQUFnQyxDQUFDLENBQUE7b0NBQ3JDLE9BQU8sSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxPQUFPLEVBQUUseUNBQXlDLEVBQUUsQ0FBQyxDQUFBO2dDQUNsRixDQUFDO2dDQUVELElBQUksQ0FBQztvQ0FDSCxvQ0FBb0M7b0NBQ3BDLE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUE7b0NBQ3hDLE1BQU0sRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO3dDQUM1QyxNQUFNLEVBQUUsVUFBVTt3Q0FDbEIsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxZQUFZLEVBQUUsV0FBVyxFQUFFLGFBQWEsQ0FBQzt3Q0FDakUsT0FBTyxFQUFFLEVBQUUsS0FBSyxFQUFFO3FDQUNuQixDQUFDLENBQUE7b0NBRUYsSUFBSSxTQUFTLElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQzt3Q0FDdEMsR0FBRyxDQUFDLDJCQUEyQixLQUFLLDhCQUE4QixDQUFDLENBQUE7d0NBQ25FLE9BQU8sSUFBSSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtvQ0FDakMsQ0FBQztvQ0FFRCxnQ0FBZ0M7b0NBQ2hDLEdBQUcsQ0FBQyw0Q0FBNEMsS0FBSyxLQUFLLENBQUMsQ0FBQTtvQ0FFM0QsTUFBTSxFQUFFLHVCQUF1QixFQUFFLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7b0NBQ3BFLHNEQUFzRDtvQ0FDdEQscUJBQXFCO29DQUVyQixHQUFHLENBQUMsb0NBQW9DLENBQUMsQ0FBQTtvQ0FDekMsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sdUJBQXVCLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDO3dDQUM5RCxLQUFLLEVBQUU7NENBQ0wsYUFBYSxFQUFFLENBQUM7b0RBQ2QsS0FBSztvREFDTCxVQUFVLEVBQUUsVUFBVSxJQUFJLEVBQUU7b0RBQzVCLFNBQVMsRUFBRSxXQUFXLElBQUksRUFBRTtvREFDNUIsV0FBVyxFQUFFLElBQUk7b0RBQ2pCLFFBQVEsRUFBRTt3REFDUixhQUFhLEVBQUUsUUFBUTt3REFDdkIsY0FBYyxFQUFFLFlBQVk7d0RBQzVCLE9BQU87cURBQ1I7aURBQ0YsQ0FBQzt5Q0FDSDtxQ0FDRixDQUFDLENBQUE7b0NBRUYsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFBO29DQUM3QixHQUFHLENBQUMsd0NBQXdDLFdBQVcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFBO29DQUU3RCxPQUFPLElBQUksQ0FBQyxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUE7Z0NBRWhDLENBQUM7Z0NBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztvQ0FDZixHQUFHLENBQUMsMkNBQTJDLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFBO29DQUNoRSxHQUFHLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQTtvQ0FDNUIsT0FBTyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFBO2dDQUMzQixDQUFDOzRCQUNILENBQUM7eUJBQ0Y7cUJBQ0Y7aUJBQ0Y7YUFDRjtTQUNGO1FBQ0Q7WUFDRSwwQkFBMEI7WUFDMUIsT0FBTyxFQUFFLG1CQUFtQjtZQUM1QixPQUFPLEVBQUU7Z0JBQ1AsU0FBUyxFQUFFO29CQUNUO3dCQUNFLGNBQWM7d0JBQ2QsT0FBTyxFQUFFLDBCQUEwQjt3QkFDbkMsRUFBRSxFQUFFLG1CQUFtQjt3QkFDdkIsT0FBTyxFQUFFLEVBQUU7cUJBQ1o7aUJBQ0Y7YUFDRjtTQUNGO1FBQ0Q7WUFDRSx3REFBd0Q7WUFDeEQsT0FBTyxFQUFFLHdCQUF3QjtZQUNqQyxPQUFPLEVBQUU7Z0JBQ1AsU0FBUyxFQUFFO29CQUNULHlDQUF5QztvQkFDekM7d0JBQ0UsT0FBTyxFQUFFLDhCQUE4Qjt3QkFDdkMsRUFBRSxFQUFFLE9BQU87d0JBQ1gsT0FBTyxFQUFFOzRCQUNQLFFBQVEsRUFBRSxDQUFDLE9BQU8sQ0FBQzt5QkFDcEI7cUJBQ0Y7aUJBQ0Y7YUFDRjtTQUNGLEVBQUU7WUFDRCxvQkFBb0I7WUFDcEIsT0FBTyxFQUFFLHVCQUF1QjtZQUNoQyxHQUFHLEVBQUUsZUFBTyxDQUFDLEtBQUs7WUFDbEIsT0FBTyxFQUFFO2dCQUNQLFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsSUFBSSx3QkFBd0I7YUFDNUQ7U0FDRjtRQUNEO1lBQ0Usa0JBQWtCO1lBQ2xCLHVEQUF1RDtZQUN2RCxtQ0FBbUM7WUFDbkMsa0NBQWtDO1lBQ2xDLE9BQU8sRUFBRSxnQkFBZ0I7WUFDekIsR0FBRyxFQUFFLGVBQU8sQ0FBQyxJQUFJO1lBQ2pCLE9BQU8sRUFBRTtnQkFDUCxTQUFTLEVBQUU7b0JBQ1Q7d0JBQ0UsT0FBTyxFQUFFLHNCQUFzQjt3QkFDL0IsRUFBRSxFQUFFLE9BQU87d0JBQ1gsT0FBTyxFQUFFOzRCQUNQLHFCQUFxQjs0QkFDckIsVUFBVSxFQUFFLGdCQUFnQjs0QkFDNUIsNENBQTRDOzRCQUM1QyxXQUFXLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsSUFBSSxvQ0FBb0MsQ0FBQyxHQUFHLGlCQUFpQjt5QkFDbkc7cUJBQ0Y7aUJBQ0Y7YUFDRjtTQUNGO1FBQ0Q7WUFDRSxPQUFPLEVBQUUseUJBQXlCO1NBQ25DO0tBQ0Y7Q0FDRixDQUFDLENBQUEifQ==