"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class ManualPaymentProvider extends utils_1.AbstractPaymentProvider {
    constructor(container, options) {
        super(container, options);
    }
    async initiatePayment(input) {
        // For manual payments, we just create a session without actual payment processing
        return {
            data: {
                session_id: `manual_${Date.now()}`,
                status: 'pending'
            },
            id: `manual_${Date.now()}`
        };
    }
    async authorizePayment(input) {
        // Manual payment requires manual authorization
        return {
            data: {
                session_id: input.data?.session_id || input.id,
                status: 'authorized'
            },
            status: utils_1.PaymentSessionStatus.AUTHORIZED
        };
    }
    async capturePayment(input) {
        // Manual payment capture (when payment is actually received)
        return {
            data: {
                session_id: input.data?.session_id || input.id,
                status: 'captured'
            }
        };
    }
    async cancelPayment(input) {
        return {
            data: {
                session_id: input.data?.session_id || input.id,
                status: 'cancelled'
            }
        };
    }
    async deletePayment(input) {
        return {
            data: {}
        };
    }
    async getPaymentStatus(input) {
        // For manual payments, status needs to be manually updated
        return {
            status: utils_1.PaymentSessionStatus.PENDING
        };
    }
    async refundPayment(input) {
        return {
            data: {
                refund_id: `refund_${Date.now()}`,
                status: 'refunded'
            }
        };
    }
    async retrievePayment(input) {
        return {
            data: input.data || {}
        };
    }
    async updatePayment(input) {
        return {
            data: {
                ...input.data,
                updated_at: new Date().toISOString()
            }
        };
    }
    async getWebhookActionAndData(data) {
        return {
            action: utils_1.PaymentActions.NOT_SUPPORTED
        };
    }
    async getPaymentData(session) {
        return session.data || {};
    }
    async getStatus(session) {
        return session.data?.status || 'pending';
    }
    async createAccountHolder(input) {
        return { id: input.context?.customer?.id || 'manual_account' };
    }
    async deleteAccountHolder(input) {
        return { data: {} };
    }
}
ManualPaymentProvider.identifier = 'manual_manual';
exports.default = ManualPaymentProvider;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9tYW51YWwtcGF5bWVudC9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHFEQUF5RztBQUV6RyxNQUFNLHFCQUFzQixTQUFRLCtCQUF1QjtJQUd6RCxZQUFZLFNBQWMsRUFBRSxPQUFZO1FBQ3RDLEtBQUssQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUE7SUFDM0IsQ0FBQztJQUVELEtBQUssQ0FBQyxlQUFlLENBQUMsS0FBVTtRQUM5QixrRkFBa0Y7UUFDbEYsT0FBTztZQUNMLElBQUksRUFBRTtnQkFDSixVQUFVLEVBQUUsVUFBVSxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUU7Z0JBQ2xDLE1BQU0sRUFBRSxTQUFTO2FBQ2xCO1lBQ0QsRUFBRSxFQUFFLFVBQVUsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO1NBQzNCLENBQUE7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEtBQVU7UUFDL0IsK0NBQStDO1FBQy9DLE9BQU87WUFDTCxJQUFJLEVBQUU7Z0JBQ0osVUFBVSxFQUFFLEtBQUssQ0FBQyxJQUFJLEVBQUUsVUFBVSxJQUFJLEtBQUssQ0FBQyxFQUFFO2dCQUM5QyxNQUFNLEVBQUUsWUFBWTthQUNyQjtZQUNELE1BQU0sRUFBRSw0QkFBb0IsQ0FBQyxVQUFVO1NBQ3hDLENBQUE7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGNBQWMsQ0FBQyxLQUFVO1FBQzdCLDZEQUE2RDtRQUM3RCxPQUFPO1lBQ0wsSUFBSSxFQUFFO2dCQUNKLFVBQVUsRUFBRSxLQUFLLENBQUMsSUFBSSxFQUFFLFVBQVUsSUFBSSxLQUFLLENBQUMsRUFBRTtnQkFDOUMsTUFBTSxFQUFFLFVBQVU7YUFDbkI7U0FDRixDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBVTtRQUM1QixPQUFPO1lBQ0wsSUFBSSxFQUFFO2dCQUNKLFVBQVUsRUFBRSxLQUFLLENBQUMsSUFBSSxFQUFFLFVBQVUsSUFBSSxLQUFLLENBQUMsRUFBRTtnQkFDOUMsTUFBTSxFQUFFLFdBQVc7YUFDcEI7U0FDRixDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBVTtRQUM1QixPQUFPO1lBQ0wsSUFBSSxFQUFFLEVBQUU7U0FDVCxDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFVO1FBQy9CLDJEQUEyRDtRQUMzRCxPQUFPO1lBQ0wsTUFBTSxFQUFFLDRCQUFvQixDQUFDLE9BQU87U0FDckMsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsYUFBYSxDQUFDLEtBQVU7UUFDNUIsT0FBTztZQUNMLElBQUksRUFBRTtnQkFDSixTQUFTLEVBQUUsVUFBVSxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUU7Z0JBQ2pDLE1BQU0sRUFBRSxVQUFVO2FBQ25CO1NBQ0YsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsZUFBZSxDQUFDLEtBQVU7UUFDOUIsT0FBTztZQUNMLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxJQUFJLEVBQUU7U0FDdkIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsYUFBYSxDQUFDLEtBQVU7UUFDNUIsT0FBTztZQUNMLElBQUksRUFBRTtnQkFDSixHQUFHLEtBQUssQ0FBQyxJQUFJO2dCQUNiLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTthQUNyQztTQUNGLENBQUE7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLHVCQUF1QixDQUFDLElBQVM7UUFDckMsT0FBTztZQUNMLE1BQU0sRUFBRSxzQkFBYyxDQUFDLGFBQWE7U0FDckMsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUFDLE9BQVk7UUFDL0IsT0FBTyxPQUFPLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQTtJQUMzQixDQUFDO0lBRUQsS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFZO1FBQzFCLE9BQU8sT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLElBQUksU0FBUyxDQUFBO0lBQzFDLENBQUM7SUFFRCxLQUFLLENBQUMsbUJBQW1CLENBQUMsS0FBVTtRQUNsQyxPQUFPLEVBQUUsRUFBRSxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUUsSUFBSSxnQkFBZ0IsRUFBRSxDQUFBO0lBQ2hFLENBQUM7SUFFRCxLQUFLLENBQUMsbUJBQW1CLENBQUMsS0FBVTtRQUNsQyxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxDQUFBO0lBQ3JCLENBQUM7O0FBeEdNLGdDQUFVLEdBQUcsZUFBZSxDQUFBO0FBMkdyQyxrQkFBZSxxQkFBcUIsQ0FBQSJ9