"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AffiliateLink = void 0;
const utils_1 = require("@medusajs/framework/utils");
const affiliate_1 = require("./affiliate");
const affiliate_click_1 = require("./affiliate-click");
const affiliate_conversion_1 = require("./affiliate-conversion");
exports.AffiliateLink = utils_1.model.define("affiliate_link", {
    id: utils_1.model.id().primaryKey(),
    url: utils_1.model.text(), // The target URL
    code: utils_1.model.text().unique(), // Unique short code for this specific link
    clicks: utils_1.model.number().default(0),
    conversions: utils_1.model.number().default(0),
    metadata: utils_1.model.json().nullable(),
    affiliate_id: utils_1.model.text(),
    affiliate: utils_1.model.belongsTo(() => affiliate_1.Affiliate, { mappedBy: "links" }),
    clicks_details: utils_1.model.hasMany(() => affiliate_click_1.AffiliateClick, { mappedBy: "link" }),
    conversions_details: utils_1.model.hasMany(() => affiliate_conversion_1.AffiliateConversion, { mappedBy: "link" }),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWZmaWxpYXRlLWxpbmsuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9hZmZpbGlhdGUvbW9kZWxzL2FmZmlsaWF0ZS1saW5rLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUFpRDtBQUNqRCwyQ0FBdUM7QUFDdkMsdURBQWtEO0FBQ2xELGlFQUE0RDtBQUUvQyxRQUFBLGFBQWEsR0FBRyxhQUFLLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFO0lBQzFELEVBQUUsRUFBRSxhQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxFQUFFO0lBQzNCLEdBQUcsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLEVBQUUsaUJBQWlCO0lBQ3BDLElBQUksRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxFQUFFLEVBQUUsMkNBQTJDO0lBQ3hFLE1BQU0sRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNqQyxXQUFXLEVBQUUsYUFBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDdEMsUUFBUSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDakMsWUFBWSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDMUIsU0FBUyxFQUFFLGFBQUssQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMscUJBQVMsRUFBRSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsQ0FBQztJQUNsRSxjQUFjLEVBQUUsYUFBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxnQ0FBYyxFQUFFLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDO0lBQ3pFLG1CQUFtQixFQUFFLGFBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsMENBQW1CLEVBQUUsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUM7Q0FDcEYsQ0FBQyxDQUFBIn0=