"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AffiliateConversion = void 0;
const utils_1 = require("@medusajs/framework/utils");
const affiliate_1 = require("./affiliate");
const affiliate_link_1 = require("./affiliate-link");
exports.AffiliateConversion = utils_1.model.define("affiliate_conversion", {
    id: utils_1.model.id().primaryKey(),
    order_id: utils_1.model.text().nullable(), // ID of the order in Medusa (if applicable)
    amount: utils_1.model.bigNumber().default(0), // Order value
    commission: utils_1.model.bigNumber().default(0), // Commission amount
    status: utils_1.model.enum(["pending", "confirmed", "cancelled"]).default("pending"),
    metadata: utils_1.model.json().nullable(),
    affiliate_id: utils_1.model.text(),
    affiliate: utils_1.model.belongsTo(() => affiliate_1.Affiliate, { mappedBy: "conversions" }),
    link: utils_1.model.belongsTo(() => affiliate_link_1.AffiliateLink, { mappedBy: "conversions_details" }),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWZmaWxpYXRlLWNvbnZlcnNpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9hZmZpbGlhdGUvbW9kZWxzL2FmZmlsaWF0ZS1jb252ZXJzaW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUFpRDtBQUNqRCwyQ0FBdUM7QUFDdkMscURBQWdEO0FBRW5DLFFBQUEsbUJBQW1CLEdBQUcsYUFBSyxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsRUFBRTtJQUN0RSxFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRTtJQUMzQixRQUFRLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFFLDRDQUE0QztJQUMvRSxNQUFNLEVBQUUsYUFBSyxDQUFDLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxjQUFjO0lBQ3BELFVBQVUsRUFBRSxhQUFLLENBQUMsU0FBUyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLG9CQUFvQjtJQUM5RCxNQUFNLEVBQUUsYUFBSyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsRUFBRSxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO0lBQzVFLFFBQVEsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ2pDLFlBQVksRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQzFCLFNBQVMsRUFBRSxhQUFLLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLHFCQUFTLEVBQUUsRUFBRSxRQUFRLEVBQUUsYUFBYSxFQUFFLENBQUM7SUFDeEUsSUFBSSxFQUFFLGFBQUssQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsOEJBQWEsRUFBRSxFQUFFLFFBQVEsRUFBRSxxQkFBcUIsRUFBRSxDQUFDO0NBQ2hGLENBQUMsQ0FBQSJ9