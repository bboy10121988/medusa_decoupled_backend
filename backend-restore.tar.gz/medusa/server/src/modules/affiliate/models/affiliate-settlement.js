"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AffiliateSettlement = void 0;
const utils_1 = require("@medusajs/framework/utils");
// import { Affiliate } from "./affiliate"
exports.AffiliateSettlement = utils_1.model.define("affiliate_settlement", {
    id: utils_1.model.id().primaryKey(),
    amount: utils_1.model.bigNumber().default(0),
    currency_code: utils_1.model.text(),
    status: utils_1.model.enum(["pending", "processing", "paid", "failed"]).default("pending"),
    period_start: utils_1.model.dateTime().nullable(),
    period_end: utils_1.model.dateTime().nullable(),
    metadata: utils_1.model.json().nullable(),
    // affiliate: model.belongsTo(() => Affiliate, { mappedBy: "settlements" }),
    affiliate_id: utils_1.model.text(),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWZmaWxpYXRlLXNldHRsZW1lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9hZmZpbGlhdGUvbW9kZWxzL2FmZmlsaWF0ZS1zZXR0bGVtZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUFpRDtBQUNqRCwwQ0FBMEM7QUFFN0IsUUFBQSxtQkFBbUIsR0FBRyxhQUFLLENBQUMsTUFBTSxDQUFDLHNCQUFzQixFQUFFO0lBQ3RFLEVBQUUsRUFBRSxhQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxFQUFFO0lBQzNCLE1BQU0sRUFBRSxhQUFLLENBQUMsU0FBUyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNwQyxhQUFhLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUMzQixNQUFNLEVBQUUsYUFBSyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsRUFBRSxZQUFZLEVBQUUsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztJQUNsRixZQUFZLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUN6QyxVQUFVLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUN2QyxRQUFRLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNqQyw0RUFBNEU7SUFDNUUsWUFBWSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7Q0FDM0IsQ0FBQyxDQUFBIn0=