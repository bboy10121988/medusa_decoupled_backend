"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const affiliate_1 = require("./models/affiliate");
const affiliate_link_1 = require("./models/affiliate-link");
const affiliate_click_1 = require("./models/affiliate-click");
const affiliate_conversion_1 = require("./models/affiliate-conversion");
const affiliate_settlement_1 = require("./models/affiliate-settlement");
class AffiliateService extends (0, utils_1.MedusaService)({
    Affiliate: affiliate_1.Affiliate,
    AffiliateLink: affiliate_link_1.AffiliateLink,
    AffiliateClick: affiliate_click_1.AffiliateClick,
    AffiliateConversion: affiliate_conversion_1.AffiliateConversion,
    AffiliateSettlement: affiliate_settlement_1.AffiliateSettlement,
}) {
}
exports.default = AffiliateService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL2FmZmlsaWF0ZS9zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEscURBQXlEO0FBQ3pELGtEQUE4QztBQUM5Qyw0REFBdUQ7QUFDdkQsOERBQXlEO0FBQ3pELHdFQUFtRTtBQUNuRSx3RUFBbUU7QUFFbkUsTUFBTSxnQkFBaUIsU0FBUSxJQUFBLHFCQUFhLEVBQUM7SUFDM0MsU0FBUyxFQUFULHFCQUFTO0lBQ1QsYUFBYSxFQUFiLDhCQUFhO0lBQ2IsY0FBYyxFQUFkLGdDQUFjO0lBQ2QsbUJBQW1CLEVBQW5CLDBDQUFtQjtJQUNuQixtQkFBbUIsRUFBbkIsMENBQW1CO0NBQ3BCLENBQUM7Q0FFRDtBQUVELGtCQUFlLGdCQUFnQixDQUFBIn0=