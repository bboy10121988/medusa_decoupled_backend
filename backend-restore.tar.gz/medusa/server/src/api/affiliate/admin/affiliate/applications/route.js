"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
// GET /affiliate/admin/affiliate/applications - 管理員獲取聯盟申請
async function GET(req, res) {
    try {
        // 這裡應該驗證管理員權限
        // 暫時返回模擬資料
        const applications = [
            {
                id: "app_1",
                name: "聯盟夥伴A",
                email: "partner-a@example.com",
                website: "https://example-a.com",
                status: "pending",
                created_at: new Date("2024-01-15"),
                updated_at: new Date("2024-01-15")
            },
            {
                id: "app_2",
                name: "聯盟夥伴B",
                email: "partner-b@example.com",
                website: "https://example-b.com",
                status: "approved",
                created_at: new Date("2024-01-10"),
                updated_at: new Date("2024-01-12")
            }
        ];
        res.json({
            applications,
            count: applications.length,
            offset: 0,
            limit: 20
        });
    }
    catch (error) {
        res.status(500).json({
            error: "Internal server error",
            message: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FmZmlsaWF0ZS9hZG1pbi9hZmZpbGlhdGUvYXBwbGljYXRpb25zL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBTUEsa0JBd0NDO0FBekNELDBEQUEwRDtBQUNuRCxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixJQUFJLENBQUM7UUFDSCxjQUFjO1FBQ2QsV0FBVztRQUNYLE1BQU0sWUFBWSxHQUFHO1lBQ25CO2dCQUNFLEVBQUUsRUFBRSxPQUFPO2dCQUNYLElBQUksRUFBRSxPQUFPO2dCQUNiLEtBQUssRUFBRSx1QkFBdUI7Z0JBQzlCLE9BQU8sRUFBRSx1QkFBdUI7Z0JBQ2hDLE1BQU0sRUFBRSxTQUFTO2dCQUNqQixVQUFVLEVBQUUsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDO2dCQUNsQyxVQUFVLEVBQUUsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDO2FBQ25DO1lBQ0Q7Z0JBQ0UsRUFBRSxFQUFFLE9BQU87Z0JBQ1gsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsS0FBSyxFQUFFLHVCQUF1QjtnQkFDOUIsT0FBTyxFQUFFLHVCQUF1QjtnQkFDaEMsTUFBTSxFQUFFLFVBQVU7Z0JBQ2xCLFVBQVUsRUFBRSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUM7Z0JBQ2xDLFVBQVUsRUFBRSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUM7YUFDbkM7U0FDRixDQUFBO1FBRUQsR0FBRyxDQUFDLElBQUksQ0FBQztZQUNQLFlBQVk7WUFDWixLQUFLLEVBQUUsWUFBWSxDQUFDLE1BQU07WUFDMUIsTUFBTSxFQUFFLENBQUM7WUFDVCxLQUFLLEVBQUUsRUFBRTtTQUNWLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRSx1QkFBdUI7WUFDOUIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3ZCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=