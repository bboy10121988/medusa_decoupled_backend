"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseEcpayCallback = parseEcpayCallback;
exports.isSuccessfulPayment = isSuccessfulPayment;
exports.extractOrderInfo = extractOrderInfo;
/**
 * 將 ECPay 回呼的 JSON 資料轉換為 EcpayCallbackBody 介面
 * ECPay 回呼中的數值欄位通常是字串格式，需要轉換為數字
 */
function parseEcpayCallback(jsonData) {
    let data;
    // 如果傳入的是字串，先解析 JSON
    if (typeof jsonData === 'string') {
        try {
            data = JSON.parse(jsonData);
        }
        catch (error) {
            throw new Error('Invalid JSON format for ECPay callback data');
        }
    }
    else {
        data = jsonData;
    }
    // 轉換字串數值為數字類型
    const converted = {
        ...data,
        // 數值類型欄位的轉換
        RtnCode: data.RtnCode ? parseInt(data.RtnCode, 10) : undefined,
        TradeAmt: data.TradeAmt ? parseInt(data.TradeAmt, 10) : undefined,
        PaymentTypeChargeFee: data.PaymentTypeChargeFee ? parseInt(data.PaymentTypeChargeFee, 10) : undefined,
        SimulatePaid: data.SimulatePaid ? parseInt(data.SimulatePaid, 10) : undefined,
        gwsr: data.gwsr ? parseInt(data.gwsr, 10) : undefined,
        amount: data.amount ? parseInt(data.amount, 10) : undefined,
    };
    return converted;
}
/**
 * 驗證 ECPay 回呼是否為成功的付款
 */
function isSuccessfulPayment(callbackData) {
    return callbackData.RtnCode === "1" && callbackData.RtnMsg === 'paid';
}
/**
 * 從 ECPay 回呼資料中提取重要的訂單資訊
 */
function extractOrderInfo(callbackData) {
    return {
        orderId: callbackData.CustomField2, // 通常在 CustomField2 中存放訂單 ID
        paymentCollectionId: callbackData.CustomField3, // 付款集合 ID
        paymentSessionId: callbackData.CustomField4, // 付款會話 ID
        merchantTradeNo: callbackData.MerchantTradeNo,
        tradeNo: callbackData.TradeNo,
        tradeAmount: callbackData.TradeAmt,
        paymentDate: callbackData.PaymentDate,
        paymentType: callbackData.PaymentType,
        isSuccess: isSuccessfulPayment(callbackData),
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWNwYXktY2FsbGJhY2stdXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2N1c3RvbS1ob29rcy9lY3BheS1jYWxsYmFjay11dGlscy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU1BLGdEQTJCQztBQUtELGtEQUVDO0FBS0QsNENBWUM7QUF2REQ7OztHQUdHO0FBQ0gsU0FBZ0Isa0JBQWtCLENBQUMsUUFBc0I7SUFDdkQsSUFBSSxJQUFTLENBQUM7SUFFZCxvQkFBb0I7SUFDcEIsSUFBSSxPQUFPLFFBQVEsS0FBSyxRQUFRLEVBQUUsQ0FBQztRQUNqQyxJQUFJLENBQUM7WUFDSCxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM5QixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE1BQU0sSUFBSSxLQUFLLENBQUMsNkNBQTZDLENBQUMsQ0FBQztRQUNqRSxDQUFDO0lBQ0gsQ0FBQztTQUFNLENBQUM7UUFDTixJQUFJLEdBQUcsUUFBUSxDQUFDO0lBQ2xCLENBQUM7SUFFRCxjQUFjO0lBQ2QsTUFBTSxTQUFTLEdBQXNCO1FBQ25DLEdBQUcsSUFBSTtRQUNQLFlBQVk7UUFDWixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7UUFDOUQsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO1FBQ2pFLG9CQUFvQixFQUFFLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztRQUNyRyxZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7UUFDN0UsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO1FBQ3JELE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztLQUM1RCxDQUFDO0lBRUYsT0FBTyxTQUFTLENBQUM7QUFDbkIsQ0FBQztBQUVEOztHQUVHO0FBQ0gsU0FBZ0IsbUJBQW1CLENBQUMsWUFBK0I7SUFDakUsT0FBTyxZQUFZLENBQUMsT0FBTyxLQUFLLEdBQUcsSUFBSSxZQUFZLENBQUMsTUFBTSxLQUFLLE1BQU0sQ0FBQztBQUN4RSxDQUFDO0FBRUQ7O0dBRUc7QUFDSCxTQUFnQixnQkFBZ0IsQ0FBQyxZQUErQjtJQUM5RCxPQUFPO1FBQ0wsT0FBTyxFQUFFLFlBQVksQ0FBQyxZQUFZLEVBQUUsNEJBQTRCO1FBQ2hFLG1CQUFtQixFQUFFLFlBQVksQ0FBQyxZQUFZLEVBQUUsVUFBVTtRQUMxRCxnQkFBZ0IsRUFBRSxZQUFZLENBQUMsWUFBWSxFQUFFLFVBQVU7UUFDdkQsZUFBZSxFQUFFLFlBQVksQ0FBQyxlQUFlO1FBQzdDLE9BQU8sRUFBRSxZQUFZLENBQUMsT0FBTztRQUM3QixXQUFXLEVBQUUsWUFBWSxDQUFDLFFBQVE7UUFDbEMsV0FBVyxFQUFFLFlBQVksQ0FBQyxXQUFXO1FBQ3JDLFdBQVcsRUFBRSxZQUFZLENBQUMsV0FBVztRQUNyQyxTQUFTLEVBQUUsbUJBQW1CLENBQUMsWUFBWSxDQUFDO0tBQzdDLENBQUM7QUFDSixDQUFDIn0=