"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ecpayCallBack = void 0;
const utils_1 = require("@medusajs/framework/utils");
const core_flows_1 = require("@medusajs/medusa/core-flows");
const ecpayCallBack = async (req, res, next) => {
    const action = "ecpayCallBack";
    const handler = "ecpayment_callback";
    console.log(action, "Received ECPay callback", req.body);
    try {
        const body = req.body;
        if (!body) {
            throw new Error("Request body is empty");
        }
        const data = body;
        console.log(action, "Parsed ECPay callback data:", data);
        let orderID = "";
        let paymentCollectionID = "";
        let paymentSessionID = "";
        if (!data.PaymentType || data.PaymentType !== "Credit_CreditCard") {
            console.log(action, "Only Credit_CreditCard is supported, got:", data.PaymentType);
            throw new Error("Only Credit_CreditCard is supported");
        }
        if (!data.CustomField2) {
            throw new Error("CustomField2 (order_id) is missing");
        }
        else {
            orderID = data.CustomField2;
        }
        if (!data.CustomField3) {
            throw new Error("CustomField3 (payment_collection_id) is missing");
        }
        else {
            paymentCollectionID = data.CustomField3;
        }
        if (!data.CustomField4) {
            throw new Error("CustomField4 (payment_session_id) is missing");
        }
        else {
            paymentSessionID = data.CustomField4;
        }
        // 正確：直接拿到 query 實例，呼叫 graph
        const query = req.scope.resolve("query");
        const { data: orders } = await query.graph({
            entity: "order",
            fields: ["id", "payment_collections.*", "payment_collections.payments.*"],
            filters: { id: orderID },
        });
        console.log(action, "list orders : ", orders);
        const theOrder = orders?.find((order) => order.id === orderID);
        if (!theOrder) {
            console.log(action, "order not found by orderID:", orderID);
            throw new Error("Order not found");
        }
        console.log(action, "find order by orderID:", theOrder);
        const thePaymentCollection = theOrder.payment_collections?.find((paymentCollection) => paymentCollection.id === paymentCollectionID);
        if (!thePaymentCollection) {
            console.log(action, "paymentCollection not found by paymentCollectionID:", paymentCollectionID);
            throw new Error("PaymentCollection not found");
        }
        const thePayment = thePaymentCollection.payments?.find((payment) => payment?.payment_session_id === paymentSessionID);
        if (!thePayment) {
            console.log(action, "payment not found by paymentSessionID:", paymentSessionID);
            throw new Error("Payment not found");
        }
        const paymentModuleService = req.scope.resolve(utils_1.Modules.PAYMENT);
        // 試驗証明：updatePaymentSession根本一點屁用沒有，裡面的data只有在init的時候可以何存，之後的更新都不會影響到payment的data欄位
        // 只好把原本data的地方直接放到order的metadata裡面去
        // const paymentUpdateSession = await paymentModuleService.updatePaymentSession(
        //     {
        //         id:paymentSessionID,
        //         currency_code:thePayment.currency_code,
        //         amount:thePayment.amount,
        //         data:{
        //             type: data.PaymentType,
        //             rtn_code: data.RtnCode,
        //             amount: data.amount,
        //             payment_type: data.PaymentType,
        //             payment_status: data.RtnCode,
        //             merchant_trade_no: data.MerchantTradeNo,
        //             trade_no: data.TradeNo,
        //             credit_refund_id: data.gwsr,
        //             status: "authorized"
        //         },
        //     }
        // )
        // console.log(action,"updatePaymentSession result:",paymentUpdateSession)
        console.log(action, "excute capturePaymentWorkflow, paymentID:", thePayment.id);
        const ecpayData = {
            payment_source: "ecpay",
            payment_type: data.PaymentType,
            payment_code: data.RtnCode,
            payment_msg: data.RtnMsg,
            payment_status: data.RtnCode === "1" ? "success" : "failed",
            payment_amount: data.amount,
            merchant_trade_no: data.MerchantTradeNo,
            trade_no: data.TradeNo,
            credit_refund_id: data.gwsr,
        };
        await (0, core_flows_1.updateOrderWorkflow)(req.scope).run({
            input: {
                id: orderID,
                user_id: handler,
                metadata: ecpayData
            }
        });
        if (data.RtnCode === "1") {
            // 如果付款成功，就刪掉原本的payment session，並且建立一個含有正確data的新的payment session
            // 取消原本的payment
            await paymentModuleService.cancelPayment(thePayment.id);
            // 刪除原本的payment session
            await paymentModuleService.deletePaymentSession(paymentSessionID);
            // 建立一個新的payment session，並且把callback data放進去
            const createdPaymentSession = await paymentModuleService.createPaymentSession(paymentCollectionID, {
                provider_id: thePayment.provider_id,
                currency_code: thePayment.currency_code,
                amount: thePayment.amount,
                data: ecpayData
            });
            console.log(action, "create new payment session result:", createdPaymentSession);
            // 藉由auth新的payment session來capture payment
            const createdPayment = await paymentModuleService.authorizePaymentSession(createdPaymentSession.id, {});
            console.log(action, "authorizePaymentSession result:", createdPayment);
            await (0, core_flows_1.capturePaymentWorkflow)(req.scope).run({
                input: {
                    payment_id: createdPayment.id,
                    amount: data.amount
                },
            });
        }
        else {
            await (0, core_flows_1.cancelOrderWorkflow)(req.scope).run({
                input: {
                    order_id: orderID,
                    canceled_by: handler,
                }
            });
        }
    }
    catch (error) {
        console.error(action, "Error parsing request body:", error);
        res.status(400).send("0|Error");
        return;
    }
    res.status(200).send("1|OK");
};
exports.ecpayCallBack = ecpayCallBack;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWNwYXktY2FsbGJhY2suanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2N1c3RvbS1ob29rcy9lY3BheS1jYWxsYmFjay50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxxREFBbUQ7QUFDbkQsNERBQXdLO0FBR3hLLE1BQU0sYUFBYSxHQUFHLEtBQUssRUFBRSxHQUFrQixFQUFFLEdBQW1CLEVBQUMsSUFBd0IsRUFBRSxFQUFFO0lBRTdGLE1BQU0sTUFBTSxHQUFXLGVBQWUsQ0FBQTtJQUN0QyxNQUFNLE9BQU8sR0FBVyxvQkFBb0IsQ0FBQTtJQUU1QyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBQyx5QkFBeUIsRUFBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUE7SUFFdEQsSUFBSSxDQUFDO1FBQ0QsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQTtRQUVyQixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDUixNQUFNLElBQUksS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUE7UUFDNUMsQ0FBQztRQUVELE1BQU0sSUFBSSxHQUFHLElBQXlCLENBQUE7UUFFdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsNkJBQTZCLEVBQUMsSUFBSSxDQUFDLENBQUE7UUFHdEQsSUFBSSxPQUFPLEdBQVcsRUFBRSxDQUFBO1FBQ3hCLElBQUksbUJBQW1CLEdBQVcsRUFBRSxDQUFBO1FBQ3BDLElBQUksZ0JBQWdCLEdBQVcsRUFBRSxDQUFBO1FBRWpDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssbUJBQW1CLEVBQUMsQ0FBQztZQUMvRCxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBQywyQ0FBMkMsRUFBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUE7WUFDaEYsTUFBTSxJQUFJLEtBQUssQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFBO1FBQzFELENBQUM7UUFHRCxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBQyxDQUFDO1lBQ3BCLE1BQU0sSUFBSSxLQUFLLENBQUMsb0NBQW9DLENBQUMsQ0FBQTtRQUN6RCxDQUFDO2FBQUksQ0FBQztZQUNGLE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFBO1FBQy9CLENBQUM7UUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBQyxDQUFDO1lBQ3BCLE1BQU0sSUFBSSxLQUFLLENBQUMsaURBQWlELENBQUMsQ0FBQTtRQUN0RSxDQUFDO2FBQUksQ0FBQztZQUNGLG1CQUFtQixHQUFHLElBQUksQ0FBQyxZQUFZLENBQUE7UUFDM0MsQ0FBQztRQUVELElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFDLENBQUM7WUFDcEIsTUFBTSxJQUFJLEtBQUssQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFBO1FBQ25FLENBQUM7YUFBSSxDQUFDO1lBQ0YsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQTtRQUN4QyxDQUFDO1FBSUQsNEJBQTRCO1FBQzVCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFBO1FBRXhDLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1lBQ3ZDLE1BQU0sRUFBRSxPQUFPO1lBQ2YsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLHVCQUF1QixFQUFDLGdDQUFnQyxDQUFDO1lBQ3hFLE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUU7U0FDM0IsQ0FBQyxDQUFBO1FBRUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsZ0JBQWdCLEVBQUMsTUFBTSxDQUFDLENBQUE7UUFFM0MsTUFBTSxRQUFRLEdBQUcsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsS0FBTSxDQUFDLEVBQUUsS0FBSyxPQUFPLENBQUMsQ0FBQTtRQUUvRCxJQUFJLENBQUMsUUFBUSxFQUFDLENBQUM7WUFDWCxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBQyw2QkFBNkIsRUFBQyxPQUFPLENBQUMsQ0FBQTtZQUN6RCxNQUFNLElBQUksS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUE7UUFDdEMsQ0FBQztRQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFDLHdCQUF3QixFQUFDLFFBQVEsQ0FBQyxDQUFBO1FBRXJELE1BQU0sb0JBQW9CLEdBQUcsUUFBUSxDQUFDLG1CQUFtQixFQUFFLElBQUksQ0FBQyxDQUFDLGlCQUFpQixFQUFFLEVBQUUsQ0FBQyxpQkFBa0IsQ0FBQyxFQUFFLEtBQUssbUJBQW1CLENBQUMsQ0FBQTtRQUVySSxJQUFJLENBQUMsb0JBQW9CLEVBQUMsQ0FBQztZQUN2QixPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBQyxxREFBcUQsRUFBQyxtQkFBbUIsQ0FBQyxDQUFBO1lBQzdGLE1BQU0sSUFBSSxLQUFLLENBQUMsNkJBQTZCLENBQUMsQ0FBQTtRQUNsRCxDQUFDO1FBRUQsTUFBTSxVQUFVLEdBQUcsb0JBQW9CLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsT0FBTyxFQUFFLGtCQUFrQixLQUFLLGdCQUFnQixDQUFDLENBQUE7UUFFckgsSUFBSSxDQUFDLFVBQVUsRUFBQyxDQUFDO1lBQ2IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsd0NBQXdDLEVBQUMsZ0JBQWdCLENBQUMsQ0FBQTtZQUM3RSxNQUFNLElBQUksS0FBSyxDQUFDLG1CQUFtQixDQUFDLENBQUE7UUFDeEMsQ0FBQztRQUVELE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLE9BQU8sQ0FBQyxDQUFBO1FBRS9ELG9GQUFvRjtRQUNwRixvQ0FBb0M7UUFFcEMsZ0ZBQWdGO1FBQ2hGLFFBQVE7UUFDUiwrQkFBK0I7UUFDL0Isa0RBQWtEO1FBQ2xELG9DQUFvQztRQUNwQyxpQkFBaUI7UUFDakIsc0NBQXNDO1FBQ3RDLHNDQUFzQztRQUN0QyxtQ0FBbUM7UUFDbkMsOENBQThDO1FBQzlDLDRDQUE0QztRQUM1Qyx1REFBdUQ7UUFDdkQsc0NBQXNDO1FBQ3RDLDJDQUEyQztRQUMzQyxtQ0FBbUM7UUFDbkMsYUFBYTtRQUNiLFFBQVE7UUFDUixJQUFJO1FBQ0osMEVBQTBFO1FBRTFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFDLDJDQUEyQyxFQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUU3RSxNQUFNLFNBQVMsR0FBRztZQUNkLGNBQWMsRUFBRSxPQUFPO1lBQ3ZCLFlBQVksRUFBRSxJQUFJLENBQUMsV0FBVztZQUM5QixZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU87WUFDMUIsV0FBVyxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ3hCLGNBQWMsRUFBRSxJQUFJLENBQUMsT0FBTyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxRQUFRO1lBQzNELGNBQWMsRUFBRSxJQUFJLENBQUMsTUFBTTtZQUMzQixpQkFBaUIsRUFBRSxJQUFJLENBQUMsZUFBZTtZQUN2QyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU87WUFDdEIsZ0JBQWdCLEVBQUMsSUFBSSxDQUFDLElBQUk7U0FDN0IsQ0FBQTtRQUVELE1BQU0sSUFBQSxnQ0FBbUIsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO1lBQ3JDLEtBQUssRUFBQztnQkFDRixFQUFFLEVBQUUsT0FBTztnQkFDWCxPQUFPLEVBQUUsT0FBTztnQkFDaEIsUUFBUSxFQUFDLFNBQVM7YUFDckI7U0FDSixDQUFDLENBQUE7UUFFRixJQUFJLElBQUksQ0FBQyxPQUFPLEtBQUssR0FBRyxFQUFDLENBQUM7WUFFdEIsZ0VBQWdFO1lBRWhFLGVBQWU7WUFDZixNQUFNLG9CQUFvQixDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUE7WUFFdkQsdUJBQXVCO1lBQ3ZCLE1BQU0sb0JBQW9CLENBQUMsb0JBQW9CLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtZQUVqRSw0Q0FBNEM7WUFDNUMsTUFBTSxxQkFBcUIsR0FBRyxNQUFNLG9CQUFvQixDQUFDLG9CQUFvQixDQUN6RSxtQkFBbUIsRUFDbkI7Z0JBQ0ksV0FBVyxFQUFFLFVBQVUsQ0FBQyxXQUFXO2dCQUNuQyxhQUFhLEVBQUUsVUFBVSxDQUFDLGFBQWE7Z0JBQ3ZDLE1BQU0sRUFBRSxVQUFVLENBQUMsTUFBTTtnQkFDekIsSUFBSSxFQUFDLFNBQVM7YUFDakIsQ0FDSixDQUFBO1lBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsb0NBQW9DLEVBQUMscUJBQXFCLENBQUMsQ0FBQTtZQUU5RSwwQ0FBMEM7WUFDMUMsTUFBTSxjQUFjLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyx1QkFBdUIsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLEVBQUMsRUFBRSxDQUFDLENBQUE7WUFFdEcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsaUNBQWlDLEVBQUMsY0FBYyxDQUFDLENBQUE7WUFFcEUsTUFBTSxJQUFBLG1DQUFzQixFQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUM7Z0JBQ3hDLEtBQUssRUFBRTtvQkFDSCxVQUFVLEVBQUUsY0FBYyxDQUFDLEVBQUU7b0JBQzdCLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtpQkFDdEI7YUFDSixDQUFDLENBQUE7UUFFTixDQUFDO2FBQUksQ0FBQztZQUNGLE1BQU0sSUFBQSxnQ0FBbUIsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO2dCQUNyQyxLQUFLLEVBQUM7b0JBQ0YsUUFBUSxFQUFFLE9BQU87b0JBQ2pCLFdBQVcsRUFBRSxPQUFPO2lCQUN2QjthQUNKLENBQUMsQ0FBQTtRQUNOLENBQUM7SUFFTCxDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNiLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFDLDZCQUE2QixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQzFELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFBO1FBQy9CLE9BQU07SUFDVixDQUFDO0lBRUQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDaEMsQ0FBQyxDQUFBO0FBRVEsc0NBQWEifQ==