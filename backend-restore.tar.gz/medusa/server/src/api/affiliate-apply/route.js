"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
// POST /affiliate-apply - 聯盟註冊申請
async function POST(req, res) {
    try {
        const body = req.body;
        const { name, email, phone, website, socialMedia, experience, description } = body;
        // 基本驗證
        if (!name || !email) {
            res.status(400).json({
                error: "Missing required fields",
                message: "Name and email are required"
            });
            return;
        }
        // 電子郵件格式驗證
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            res.status(400).json({
                error: "Invalid email format",
                message: "Please provide a valid email address"
            });
            return;
        }
        // 讀取現有的 affiliate.json 檔案
        const jsonFilePath = path.join(process.cwd(), 'src/data/affiliate.json');
        let affiliateData = {};
        try {
            if (fs.existsSync(jsonFilePath)) {
                const fileContent = fs.readFileSync(jsonFilePath, 'utf8');
                affiliateData = JSON.parse(fileContent);
            }
        }
        catch (readError) {
            console.error('Error reading affiliate.json:', readError);
            // 如果讀取失敗，使用預設結構
            affiliateData = { affiliates: [], applications: [] };
        }
        // 確保 applications 陣列存在
        if (!affiliateData.applications) {
            affiliateData.applications = [];
        }
        // 檢查是否已有相同 email 的申請
        const existingApplication = affiliateData.applications.find((app) => app.email === email);
        if (existingApplication) {
            res.status(400).json({
                error: "Application exists",
                message: "此電子郵件地址已經提交過申請"
            });
            return;
        }
        // 生成新申請
        const applicationId = `app_${Date.now()}`;
        const newApplication = {
            id: applicationId,
            name,
            email,
            phone: phone || null,
            website: website || null,
            socialMedia: socialMedia || null,
            experience: experience || null,
            description: description || null,
            status: "pending",
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };
        // 添加新申請到陣列
        affiliateData.applications.push(newApplication);
        // 將更新後的資料寫回檔案
        try {
            fs.writeFileSync(jsonFilePath, JSON.stringify(affiliateData, null, 2));
        }
        catch (writeError) {
            console.error('Error writing affiliate.json:', writeError);
            res.status(500).json({
                error: "Internal server error",
                message: "申請提交失敗，請稍後再試"
            });
            return;
        }
        res.status(201).json({
            success: true,
            message: "聯盟申請提交成功",
            data: {
                ...newApplication,
                message: "申請已提交，我們會在 3-5 個工作天內審核您的申請。"
            }
        });
    }
    catch (error) {
        console.error("Affiliate application error:", error);
        res.status(500).json({
            error: "Internal server error",
            message: "申請提交失敗，請稍後再試"
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FmZmlsaWF0ZS1hcHBseS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQVFBLG9CQWlIQztBQXJIRCx1Q0FBd0I7QUFDeEIsMkNBQTRCO0FBRTVCLGlDQUFpQztBQUMxQixLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixJQUFJLENBQUM7UUFDSCxNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsSUFRaEIsQ0FBQTtRQUVELE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsR0FBRyxJQUFJLENBQUE7UUFFbEYsT0FBTztRQUNQLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNwQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkIsS0FBSyxFQUFFLHlCQUF5QjtnQkFDaEMsT0FBTyxFQUFFLDZCQUE2QjthQUN2QyxDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1IsQ0FBQztRQUVELFdBQVc7UUFDWCxNQUFNLFVBQVUsR0FBRyw0QkFBNEIsQ0FBQTtRQUMvQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQzVCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNuQixLQUFLLEVBQUUsc0JBQXNCO2dCQUM3QixPQUFPLEVBQUUsc0NBQXNDO2FBQ2hELENBQUMsQ0FBQTtZQUNGLE9BQU07UUFDUixDQUFDO1FBRUQsMEJBQTBCO1FBQzFCLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxFQUFFLHlCQUF5QixDQUFDLENBQUE7UUFDeEUsSUFBSSxhQUFhLEdBQVEsRUFBRSxDQUFBO1FBRTNCLElBQUksQ0FBQztZQUNILElBQUksRUFBRSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO2dCQUNoQyxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLFlBQVksRUFBRSxNQUFNLENBQUMsQ0FBQTtnQkFDekQsYUFBYSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUE7WUFDekMsQ0FBQztRQUNILENBQUM7UUFBQyxPQUFPLFNBQVMsRUFBRSxDQUFDO1lBQ25CLE9BQU8sQ0FBQyxLQUFLLENBQUMsK0JBQStCLEVBQUUsU0FBUyxDQUFDLENBQUE7WUFDekQsZ0JBQWdCO1lBQ2hCLGFBQWEsR0FBRyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsWUFBWSxFQUFFLEVBQUUsRUFBRSxDQUFBO1FBQ3RELENBQUM7UUFFRCx1QkFBdUI7UUFDdkIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUNoQyxhQUFhLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQTtRQUNqQyxDQUFDO1FBRUQscUJBQXFCO1FBQ3JCLE1BQU0sbUJBQW1CLEdBQUcsYUFBYSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFRLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEtBQUssS0FBSyxDQUFDLENBQUE7UUFDOUYsSUFBSSxtQkFBbUIsRUFBRSxDQUFDO1lBQ3hCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNuQixLQUFLLEVBQUUsb0JBQW9CO2dCQUMzQixPQUFPLEVBQUUsZ0JBQWdCO2FBQzFCLENBQUMsQ0FBQTtZQUNGLE9BQU07UUFDUixDQUFDO1FBRUQsUUFBUTtRQUNSLE1BQU0sYUFBYSxHQUFHLE9BQU8sSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUE7UUFDekMsTUFBTSxjQUFjLEdBQUc7WUFDckIsRUFBRSxFQUFFLGFBQWE7WUFDakIsSUFBSTtZQUNKLEtBQUs7WUFDTCxLQUFLLEVBQUUsS0FBSyxJQUFJLElBQUk7WUFDcEIsT0FBTyxFQUFFLE9BQU8sSUFBSSxJQUFJO1lBQ3hCLFdBQVcsRUFBRSxXQUFXLElBQUksSUFBSTtZQUNoQyxVQUFVLEVBQUUsVUFBVSxJQUFJLElBQUk7WUFDOUIsV0FBVyxFQUFFLFdBQVcsSUFBSSxJQUFJO1lBQ2hDLE1BQU0sRUFBRSxTQUFTO1lBQ2pCLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtZQUNwQyxVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7U0FDckMsQ0FBQTtRQUVELFdBQVc7UUFDWCxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQTtRQUUvQyxjQUFjO1FBQ2QsSUFBSSxDQUFDO1lBQ0gsRUFBRSxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFDeEUsQ0FBQztRQUFDLE9BQU8sVUFBVSxFQUFFLENBQUM7WUFDcEIsT0FBTyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsRUFBRSxVQUFVLENBQUMsQ0FBQTtZQUMxRCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkIsS0FBSyxFQUFFLHVCQUF1QjtnQkFDOUIsT0FBTyxFQUFFLGNBQWM7YUFDeEIsQ0FBQyxDQUFBO1lBQ0YsT0FBTTtRQUNSLENBQUM7UUFFRCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixPQUFPLEVBQUUsSUFBSTtZQUNiLE9BQU8sRUFBRSxVQUFVO1lBQ25CLElBQUksRUFBRTtnQkFDSixHQUFHLGNBQWM7Z0JBQ2pCLE9BQU8sRUFBRSw2QkFBNkI7YUFDdkM7U0FDRixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsOEJBQThCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDcEQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFLHVCQUF1QjtZQUM5QixPQUFPLEVBQUUsY0FBYztTQUN4QixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9