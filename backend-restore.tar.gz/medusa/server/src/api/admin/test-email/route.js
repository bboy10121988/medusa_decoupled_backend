"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = void 0;
const utils_1 = require("@medusajs/framework/utils");
/**
 * 測試電子郵件發送的 API 端點
 * POST /admin/test-email
 */
const POST = async (req, res) => {
    const body = req.body;
    const { to, template, data } = body;
    if (!to || !template) {
        return res.status(400).json({
            error: "Missing required fields: 'to' and 'template'"
        });
    }
    try {
        const notificationModuleService = req.scope.resolve(utils_1.Modules.NOTIFICATION);
        await notificationModuleService.createNotifications({
            to,
            channel: "email",
            template,
            data: data || {
                test_message: "這是一個測試電子郵件",
                timestamp: new Date().toISOString(),
                store_name: "Tim's Fantasy World",
            },
        });
        console.log(`📧 測試郵件已發送到: ${to}`);
        res.status(200).json({
            success: true,
            message: `Test email sent to ${to} with template ${template}`,
            provider: process.env.SENDGRID_API_KEY ? 'SendGrid' : 'Local',
        });
    }
    catch (error) {
        console.error("❌ 測試郵件發送失敗:", error);
        res.status(500).json({
            error: "Failed to send test email",
            details: error instanceof Error ? error.message : String(error),
        });
    }
};
exports.POST = POST;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3Rlc3QtZW1haWwvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBSUEscURBQW1EO0FBRW5EOzs7R0FHRztBQUNJLE1BQU0sSUFBSSxHQUFHLEtBQUssRUFDdkIsR0FBK0IsRUFDL0IsR0FBbUIsRUFDbkIsRUFBRTtJQUNGLE1BQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxJQUFzRCxDQUFBO0lBQ3ZFLE1BQU0sRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQTtJQUVuQyxJQUFJLENBQUMsRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDckIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixLQUFLLEVBQUUsOENBQThDO1NBQ3RELENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxNQUFNLHlCQUF5QixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQTtRQUV6RSxNQUFNLHlCQUF5QixDQUFDLG1CQUFtQixDQUFDO1lBQ2xELEVBQUU7WUFDRixPQUFPLEVBQUUsT0FBTztZQUNoQixRQUFRO1lBQ1IsSUFBSSxFQUFFLElBQUksSUFBSTtnQkFDWixZQUFZLEVBQUUsWUFBWTtnQkFDMUIsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO2dCQUNuQyxVQUFVLEVBQUUscUJBQXFCO2FBQ2xDO1NBQ0YsQ0FBQyxDQUFBO1FBRUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLENBQUMsQ0FBQTtRQUVqQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixPQUFPLEVBQUUsSUFBSTtZQUNiLE9BQU8sRUFBRSxzQkFBc0IsRUFBRSxrQkFBa0IsUUFBUSxFQUFFO1lBQzdELFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLE9BQU87U0FDOUQsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUNuQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUUsMkJBQTJCO1lBQ2xDLE9BQU8sRUFBRSxLQUFLLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1NBQ2hFLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDLENBQUE7QUExQ1ksUUFBQSxJQUFJLFFBMENoQiJ9