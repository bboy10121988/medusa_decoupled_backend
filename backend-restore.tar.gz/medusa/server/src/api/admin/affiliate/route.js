"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
// GET /admin/affiliate - 獲取聯盟申請列表
async function GET(req, res) {
    try {
        // 讀取 affiliate.json 檔案
        const jsonFilePath = path.join(process.cwd(), 'src/data/affiliate.json');
        let affiliateData = { applications: [], affiliates: [] };
        try {
            if (fs.existsSync(jsonFilePath)) {
                const fileContent = fs.readFileSync(jsonFilePath, 'utf8');
                affiliateData = JSON.parse(fileContent);
            }
        }
        catch (readError) {
            console.error('Error reading affiliate.json:', readError);
        }
        // 獲取查詢參數
        const { status = 'pending', limit = 20, offset = 0 } = req.query;
        // 過濾申請
        let applications = affiliateData.applications || [];
        if (status && status !== 'all') {
            applications = applications.filter((app) => app.status === status);
        }
        // 分頁
        const total = applications.length;
        const paginatedApplications = applications.slice(Number(offset), Number(offset) + Number(limit));
        res.json({
            applications: paginatedApplications,
            affiliates: affiliateData.affiliates || [],
            count: total,
            offset: Number(offset),
            limit: Number(limit)
        });
    }
    catch (error) {
        console.error("Admin affiliate GET error:", error);
        res.status(500).json({
            error: "Internal server error",
            message: "獲取聯盟申請列表失敗"
        });
    }
}
// POST /admin/affiliate - 審核聯盟申請 (批准/拒絕)
async function POST(req, res) {
    try {
        const body = req.body;
        const { applicationId, action, commissionRate = 0.05, referralCode } = body;
        if (!applicationId || !action) {
            res.status(400).json({
                error: "Missing required fields",
                message: "Application ID and action are required"
            });
            return;
        }
        // 讀取現有資料
        const jsonFilePath = path.join(process.cwd(), 'src/data/affiliate.json');
        let affiliateData = { applications: [], affiliates: [] };
        try {
            if (fs.existsSync(jsonFilePath)) {
                const fileContent = fs.readFileSync(jsonFilePath, 'utf8');
                affiliateData = JSON.parse(fileContent);
            }
        }
        catch (readError) {
            console.error('Error reading affiliate.json:', readError);
            res.status(500).json({
                error: "Internal server error",
                message: "讀取資料失敗"
            });
            return;
        }
        // 找到對應申請
        const applicationIndex = affiliateData.applications.findIndex((app) => app.id === applicationId);
        if (applicationIndex === -1) {
            res.status(404).json({
                error: "Application not found",
                message: "找不到對應的申請"
            });
            return;
        }
        const application = affiliateData.applications[applicationIndex];
        if (action === 'approve') {
            // 批准申請 - 移動到聯盟夥伴列表
            const newAffiliate = {
                id: `aff_partner_${Date.now()}`,
                name: application.name,
                email: application.email,
                referral_code: referralCode || `REF${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
                commission_rate: commissionRate,
                status: "active",
                total_earnings: 0,
                pending_earnings: 0,
                website: application.website,
                social_media: application.socialMedia ? { description: application.socialMedia } : {},
                created_at: application.created_at,
                updated_at: new Date().toISOString()
            };
            // 添加到聯盟夥伴列表
            if (!affiliateData.affiliates) {
                affiliateData.affiliates = [];
            }
            affiliateData.affiliates.push(newAffiliate);
            // 更新申請狀態
            affiliateData.applications[applicationIndex].status = 'approved';
            affiliateData.applications[applicationIndex].updated_at = new Date().toISOString();
        }
        else if (action === 'reject') {
            // 拒絕申請
            affiliateData.applications[applicationIndex].status = 'rejected';
            affiliateData.applications[applicationIndex].updated_at = new Date().toISOString();
        }
        // 寫回檔案
        try {
            fs.writeFileSync(jsonFilePath, JSON.stringify(affiliateData, null, 2));
        }
        catch (writeError) {
            console.error('Error writing affiliate.json:', writeError);
            res.status(500).json({
                error: "Internal server error",
                message: "更新資料失敗"
            });
            return;
        }
        res.json({
            success: true,
            message: action === 'approve' ? '申請已批准' : '申請已拒絕',
            application: affiliateData.applications[applicationIndex]
        });
    }
    catch (error) {
        console.error("Admin affiliate POST error:", error);
        res.status(500).json({
            error: "Internal server error",
            message: "處理申請失敗"
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2FmZmlsaWF0ZS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQVFBLGtCQThDQztBQUdELG9CQThHQztBQW5LRCx1Q0FBd0I7QUFDeEIsMkNBQTRCO0FBRTVCLGtDQUFrQztBQUMzQixLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixJQUFJLENBQUM7UUFDSCx1QkFBdUI7UUFDdkIsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEVBQUUseUJBQXlCLENBQUMsQ0FBQTtRQUN4RSxJQUFJLGFBQWEsR0FBUSxFQUFFLFlBQVksRUFBRSxFQUFFLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxDQUFBO1FBRTdELElBQUksQ0FBQztZQUNILElBQUksRUFBRSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO2dCQUNoQyxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLFlBQVksRUFBRSxNQUFNLENBQUMsQ0FBQTtnQkFDekQsYUFBYSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUE7WUFDekMsQ0FBQztRQUNILENBQUM7UUFBQyxPQUFPLFNBQVMsRUFBRSxDQUFDO1lBQ25CLE9BQU8sQ0FBQyxLQUFLLENBQUMsK0JBQStCLEVBQUUsU0FBUyxDQUFDLENBQUE7UUFDM0QsQ0FBQztRQUVELFNBQVM7UUFDVCxNQUFNLEVBQUUsTUFBTSxHQUFHLFNBQVMsRUFBRSxLQUFLLEdBQUcsRUFBRSxFQUFFLE1BQU0sR0FBRyxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO1FBRWhFLE9BQU87UUFDUCxJQUFJLFlBQVksR0FBRyxhQUFhLENBQUMsWUFBWSxJQUFJLEVBQUUsQ0FBQTtRQUNuRCxJQUFJLE1BQU0sSUFBSSxNQUFNLEtBQUssS0FBSyxFQUFFLENBQUM7WUFDL0IsWUFBWSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFRLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEtBQUssTUFBTSxDQUFDLENBQUE7UUFDekUsQ0FBQztRQUVELEtBQUs7UUFDTCxNQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFBO1FBQ2pDLE1BQU0scUJBQXFCLEdBQUcsWUFBWSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFBO1FBRWhHLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxZQUFZLEVBQUUscUJBQXFCO1lBQ25DLFVBQVUsRUFBRSxhQUFhLENBQUMsVUFBVSxJQUFJLEVBQUU7WUFDMUMsS0FBSyxFQUFFLEtBQUs7WUFDWixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQztZQUN0QixLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQztTQUNyQixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDbEQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFLHVCQUF1QjtZQUM5QixPQUFPLEVBQUUsWUFBWTtTQUN0QixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVELHlDQUF5QztBQUNsQyxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixJQUFJLENBQUM7UUFDSCxNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsSUFLaEIsQ0FBQTtRQUVELE1BQU0sRUFBRSxhQUFhLEVBQUUsTUFBTSxFQUFFLGNBQWMsR0FBRyxJQUFJLEVBQUUsWUFBWSxFQUFFLEdBQUcsSUFBSSxDQUFBO1FBRTNFLElBQUksQ0FBQyxhQUFhLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUM5QixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkIsS0FBSyxFQUFFLHlCQUF5QjtnQkFDaEMsT0FBTyxFQUFFLHdDQUF3QzthQUNsRCxDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1IsQ0FBQztRQUVELFNBQVM7UUFDVCxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsRUFBRSx5QkFBeUIsQ0FBQyxDQUFBO1FBQ3hFLElBQUksYUFBYSxHQUFRLEVBQUUsWUFBWSxFQUFFLEVBQUUsRUFBRSxVQUFVLEVBQUUsRUFBRSxFQUFFLENBQUE7UUFFN0QsSUFBSSxDQUFDO1lBQ0gsSUFBSSxFQUFFLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7Z0JBQ2hDLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxDQUFBO2dCQUN6RCxhQUFhLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQTtZQUN6QyxDQUFDO1FBQ0gsQ0FBQztRQUFDLE9BQU8sU0FBUyxFQUFFLENBQUM7WUFDbkIsT0FBTyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsRUFBRSxTQUFTLENBQUMsQ0FBQTtZQUN6RCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkIsS0FBSyxFQUFFLHVCQUF1QjtnQkFDOUIsT0FBTyxFQUFFLFFBQVE7YUFDbEIsQ0FBQyxDQUFBO1lBQ0YsT0FBTTtRQUNSLENBQUM7UUFFRCxTQUFTO1FBQ1QsTUFBTSxnQkFBZ0IsR0FBRyxhQUFhLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQVEsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxhQUFhLENBQUMsQ0FBQTtRQUNyRyxJQUFJLGdCQUFnQixLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDNUIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ25CLEtBQUssRUFBRSx1QkFBdUI7Z0JBQzlCLE9BQU8sRUFBRSxVQUFVO2FBQ3BCLENBQUMsQ0FBQTtZQUNGLE9BQU07UUFDUixDQUFDO1FBRUQsTUFBTSxXQUFXLEdBQUcsYUFBYSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBO1FBRWhFLElBQUksTUFBTSxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQ3pCLG1CQUFtQjtZQUNuQixNQUFNLFlBQVksR0FBRztnQkFDbkIsRUFBRSxFQUFFLGVBQWUsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO2dCQUMvQixJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUk7Z0JBQ3RCLEtBQUssRUFBRSxXQUFXLENBQUMsS0FBSztnQkFDeEIsYUFBYSxFQUFFLFlBQVksSUFBSSxNQUFNLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsRUFBRTtnQkFDNUYsZUFBZSxFQUFFLGNBQWM7Z0JBQy9CLE1BQU0sRUFBRSxRQUFRO2dCQUNoQixjQUFjLEVBQUUsQ0FBQztnQkFDakIsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDbkIsT0FBTyxFQUFFLFdBQVcsQ0FBQyxPQUFPO2dCQUM1QixZQUFZLEVBQUUsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsV0FBVyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNyRixVQUFVLEVBQUUsV0FBVyxDQUFDLFVBQVU7Z0JBQ2xDLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTthQUNyQyxDQUFBO1lBRUQsWUFBWTtZQUNaLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQzlCLGFBQWEsQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFBO1lBQy9CLENBQUM7WUFDRCxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQTtZQUUzQyxTQUFTO1lBQ1QsYUFBYSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUE7WUFDaEUsYUFBYSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLFVBQVUsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFBO1FBRXBGLENBQUM7YUFBTSxJQUFJLE1BQU0sS0FBSyxRQUFRLEVBQUUsQ0FBQztZQUMvQixPQUFPO1lBQ1AsYUFBYSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUE7WUFDaEUsYUFBYSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLFVBQVUsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFBO1FBQ3BGLENBQUM7UUFFRCxPQUFPO1FBQ1AsSUFBSSxDQUFDO1lBQ0gsRUFBRSxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFDeEUsQ0FBQztRQUFDLE9BQU8sVUFBVSxFQUFFLENBQUM7WUFDcEIsT0FBTyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsRUFBRSxVQUFVLENBQUMsQ0FBQTtZQUMxRCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkIsS0FBSyxFQUFFLHVCQUF1QjtnQkFDOUIsT0FBTyxFQUFFLFFBQVE7YUFDbEIsQ0FBQyxDQUFBO1lBQ0YsT0FBTTtRQUNSLENBQUM7UUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ1AsT0FBTyxFQUFFLElBQUk7WUFDYixPQUFPLEVBQUUsTUFBTSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPO1lBQ2pELFdBQVcsRUFBRSxhQUFhLENBQUMsWUFBWSxDQUFDLGdCQUFnQixDQUFDO1NBQzFELENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyw2QkFBNkIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUNuRCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUUsdUJBQXVCO1lBQzlCLE9BQU8sRUFBRSxRQUFRO1NBQ2xCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=