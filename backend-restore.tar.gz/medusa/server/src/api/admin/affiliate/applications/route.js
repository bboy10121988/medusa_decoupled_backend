"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
// GET /admin/affiliate/applications - 獲取聯盟申請列表
async function GET(req, res) {
    try {
        // 這裡應該從資料庫獲取聯盟申請資料
        // 暫時返回模擬資料
        const applications = [
            {
                id: "aff_1",
                name: "測試聯盟夥伴",
                email: "partner@example.com",
                status: "pending",
                created_at: new Date(),
                updated_at: new Date()
            }
        ];
        res.json({
            applications,
            count: applications.length,
            offset: 0,
            limit: 20
        });
    }
    catch (error) {
        res.status(500).json({
            error: "Internal server error",
            message: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2FmZmlsaWF0ZS9hcHBsaWNhdGlvbnMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFNQSxrQkE4QkM7QUEvQkQsK0NBQStDO0FBQ3hDLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLElBQUksQ0FBQztRQUNILG1CQUFtQjtRQUNuQixXQUFXO1FBQ1gsTUFBTSxZQUFZLEdBQUc7WUFDbkI7Z0JBQ0UsRUFBRSxFQUFFLE9BQU87Z0JBQ1gsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsS0FBSyxFQUFFLHFCQUFxQjtnQkFDNUIsTUFBTSxFQUFFLFNBQVM7Z0JBQ2pCLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRTtnQkFDdEIsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO2FBQ3ZCO1NBQ0YsQ0FBQTtRQUVELEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxZQUFZO1lBQ1osS0FBSyxFQUFFLFlBQVksQ0FBQyxNQUFNO1lBQzFCLE1BQU0sRUFBRSxDQUFDO1lBQ1QsS0FBSyxFQUFFLEVBQUU7U0FDVixDQUFDLENBQUE7SUFDSixDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUUsdUJBQXVCO1lBQzlCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztTQUN2QixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9