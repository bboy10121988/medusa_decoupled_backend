"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const medusa_1 = require("@medusajs/medusa");
/**
 * 覆蓋 Medusa 預設的 Multer middleware
 *
 * Medusa 內建的 /admin/uploads 路由使用 Multer middleware
 * 這會導致:
 * 1. Buffer 被轉為 binary 字串 (實際上變成 Base64)
 * 2. 檔案儲存為文字而非二進位
 *
 * 此檔案禁用預設 middleware,讓我們的自訂路由使用 Formidable
 */
exports.default = (0, medusa_1.defineMiddlewares)({
    routes: [
        {
            matcher: "/admin/uploads",
            middlewares: [
            // 空陣列 = 不使用任何 middleware
            // 這樣 route.ts 可以完全控制請求處理
            ],
        },
    ],
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWlkZGxld2FyZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3VwbG9hZHMvbWlkZGxld2FyZXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSw2Q0FBb0Q7QUFFcEQ7Ozs7Ozs7OztHQVNHO0FBQ0gsa0JBQWUsSUFBQSwwQkFBaUIsRUFBQztJQUMvQixNQUFNLEVBQUU7UUFDTjtZQUNFLE9BQU8sRUFBRSxnQkFBZ0I7WUFDekIsV0FBVyxFQUFFO1lBQ1gseUJBQXlCO1lBQ3pCLHlCQUF5QjthQUMxQjtTQUNGO0tBQ0Y7Q0FDRixDQUFDLENBQUEifQ==