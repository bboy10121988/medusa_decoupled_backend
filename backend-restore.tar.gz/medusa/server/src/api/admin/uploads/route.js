"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.POST = POST;
const formidable_1 = __importDefault(require("formidable"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.AUTHENTICATE = true;
// 清理文件名函數
function sanitizeFilename(filename) {
    if (!filename)
        return Date.now().toString();
    const ext = path_1.default.extname(filename);
    let baseName = path_1.default.basename(filename, ext);
    // 移除特殊字符,保留英文、數字、連字號和下劃線
    baseName = baseName
        .replace(/[^\w\-_.]/g, '_')
        .replace(/_{2,}/g, '_')
        .substring(0, 50);
    return `${baseName}_${Date.now()}${ext}`;
}
async function POST(req, res) {
    const startTime = Date.now();
    try {
        console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        console.log("📤 File upload request received via /admin/uploads");
        console.log(`   Request content-type:`, req.headers['content-type']);
        console.log(`   Request content-length:`, req.headers['content-length']);
        // 確保上傳目錄存在 - 使用與 files 相同的目錄結構
        const uploadDir = path_1.default.join(process.cwd(), 'static', 'uploads');
        if (!fs_1.default.existsSync(uploadDir)) {
            fs_1.default.mkdirSync(uploadDir, { recursive: true });
        }
        console.log(`   ⏱️  [${Date.now() - startTime}ms] Directory check complete`);
        // 解析表單數據 - 使用與 files 相同的配置
        const parseStart = Date.now();
        const form = (0, formidable_1.default)({
            maxFileSize: 50 * 1024 * 1024, // 50MB (與 Nginx 一致)
            multiples: true,
            uploadDir: uploadDir,
            keepExtensions: true,
        });
        const [fields, files] = await form.parse(req);
        console.log(`   ⏱️  [${Date.now() - parseStart}ms] Form parse complete`);
        const uploadedFiles = [];
        const fileList = Array.isArray(files.files) ? files.files : [files.files].filter(Boolean);
        console.log(`   📦 Processing ${fileList.length} file(s)...`);
        const processStart = Date.now();
        for (const file of fileList) {
            if (!file)
                continue;
            const fileStart = Date.now();
            // 清理文件名 - 與 files 相同的邏輯
            const sanitizedName = sanitizeFilename(file.originalFilename || file.newFilename || 'upload');
            const newPath = path_1.default.join(uploadDir, sanitizedName);
            // 移動文件到最終位置
            if (file.filepath !== newPath) {
                fs_1.default.renameSync(file.filepath, newPath);
            }
            // 使用與 files 相同的 URL 格式
            const baseUrl = process.env.BACKEND_URL || 'https://admin.timsfantasyworld.com';
            const fullUrl = `${baseUrl}/static/uploads/${sanitizedName}`;
            const fileTime = Date.now() - fileStart;
            console.log(`   ✅ File: ${sanitizedName}`);
            console.log(`      Size: ${(file.size / 1024).toFixed(2)} KB`);
            console.log(`      Time: ${fileTime}ms`);
            console.log(`      URL: ${fullUrl}`);
            // 使用與 files 完全相同的回應格式
            uploadedFiles.push({
                id: sanitizedName,
                url: fullUrl,
                filename: file.originalFilename || file.newFilename,
                size: file.size,
                mimetype: file.mimetype || 'application/octet-stream'
            });
        }
        const processTime = Date.now() - processStart;
        const totalTime = Date.now() - startTime;
        console.log(`   ⏱️  Files processing: ${processTime}ms`);
        console.log(`✅ Successfully uploaded ${uploadedFiles.length} files via /admin/uploads`);
        console.log(`   ⏱️  TOTAL TIME: ${totalTime}ms`);
        console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        // 回應格式與 files 完全一致
        res.json({
            files: uploadedFiles
        });
    }
    catch (error) {
        const errorTime = Date.now() - startTime;
        console.error("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        console.error("❌ Upload error:", error);
        console.error(`   ⏱️  Failed after: ${errorTime}ms`);
        console.error("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        res.status(500).json({
            message: "Upload failed",
            error: error instanceof Error ? error.message : "Unknown error"
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3VwbG9hZHMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBMkJBLG9CQThGQztBQXBIRCw0REFBbUM7QUFDbkMsNENBQW1CO0FBQ25CLGdEQUF1QjtBQUVWLFFBQUEsWUFBWSxHQUFHLElBQUksQ0FBQTtBQUVoQyxVQUFVO0FBQ1YsU0FBUyxnQkFBZ0IsQ0FBQyxRQUFnQjtJQUN4QyxJQUFJLENBQUMsUUFBUTtRQUFFLE9BQU8sSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFBO0lBRTNDLE1BQU0sR0FBRyxHQUFHLGNBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUE7SUFDbEMsSUFBSSxRQUFRLEdBQUcsY0FBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUE7SUFFM0MseUJBQXlCO0lBQ3pCLFFBQVEsR0FBRyxRQUFRO1NBQ2hCLE9BQU8sQ0FBQyxZQUFZLEVBQUUsR0FBRyxDQUFDO1NBQzFCLE9BQU8sQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDO1NBQ3RCLFNBQVMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUE7SUFFbkIsT0FBTyxHQUFHLFFBQVEsSUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsR0FBRyxFQUFFLENBQUE7QUFDMUMsQ0FBQztBQUVNLEtBQUssVUFBVSxJQUFJLENBQ3hCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQTtJQUM1QixJQUFJLENBQUM7UUFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLDBDQUEwQyxDQUFDLENBQUE7UUFDdkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvREFBb0QsQ0FBQyxDQUFBO1FBQ2pFLE9BQU8sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFBO1FBQ3BFLE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUE7UUFFeEUsK0JBQStCO1FBQy9CLE1BQU0sU0FBUyxHQUFHLGNBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQTtRQUMvRCxJQUFJLENBQUMsWUFBRSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO1lBQzlCLFlBQUUsQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7UUFDOUMsQ0FBQztRQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsU0FBUyw4QkFBOEIsQ0FBQyxDQUFBO1FBRTVFLDJCQUEyQjtRQUMzQixNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUE7UUFDN0IsTUFBTSxJQUFJLEdBQUcsSUFBQSxvQkFBVSxFQUFDO1lBQ3RCLFdBQVcsRUFBRSxFQUFFLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBRSxvQkFBb0I7WUFDbkQsU0FBUyxFQUFFLElBQUk7WUFDZixTQUFTLEVBQUUsU0FBUztZQUNwQixjQUFjLEVBQUUsSUFBSTtTQUNyQixDQUFDLENBQUE7UUFFRixNQUFNLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQTtRQUM3QyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLFVBQVUseUJBQXlCLENBQUMsQ0FBQTtRQUV4RSxNQUFNLGFBQWEsR0FBVSxFQUFFLENBQUE7UUFDL0IsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUV6RixPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixRQUFRLENBQUMsTUFBTSxhQUFhLENBQUMsQ0FBQTtRQUU3RCxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUE7UUFDL0IsS0FBSyxNQUFNLElBQUksSUFBSSxRQUFRLEVBQUUsQ0FBQztZQUM1QixJQUFJLENBQUMsSUFBSTtnQkFBRSxTQUFRO1lBRW5CLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQTtZQUM1Qix3QkFBd0I7WUFDeEIsTUFBTSxhQUFhLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGdCQUFnQixJQUFJLElBQUksQ0FBQyxXQUFXLElBQUksUUFBUSxDQUFDLENBQUE7WUFDN0YsTUFBTSxPQUFPLEdBQUcsY0FBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsYUFBYSxDQUFDLENBQUE7WUFFbkQsWUFBWTtZQUNaLElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxPQUFPLEVBQUUsQ0FBQztnQkFDOUIsWUFBRSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFBO1lBQ3ZDLENBQUM7WUFFRCx1QkFBdUI7WUFDdkIsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLElBQUksb0NBQW9DLENBQUE7WUFDL0UsTUFBTSxPQUFPLEdBQUcsR0FBRyxPQUFPLG1CQUFtQixhQUFhLEVBQUUsQ0FBQTtZQUU1RCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsU0FBUyxDQUFBO1lBQ3ZDLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxhQUFhLEVBQUUsQ0FBQyxDQUFBO1lBQzFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQTtZQUM5RCxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsUUFBUSxJQUFJLENBQUMsQ0FBQTtZQUN4QyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsT0FBTyxFQUFFLENBQUMsQ0FBQTtZQUVwQyxzQkFBc0I7WUFDdEIsYUFBYSxDQUFDLElBQUksQ0FBQztnQkFDakIsRUFBRSxFQUFFLGFBQWE7Z0JBQ2pCLEdBQUcsRUFBRSxPQUFPO2dCQUNaLFFBQVEsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLElBQUksSUFBSSxDQUFDLFdBQVc7Z0JBQ25ELElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtnQkFDZixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsSUFBSSwwQkFBMEI7YUFDdEQsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxZQUFZLENBQUE7UUFDN0MsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLFNBQVMsQ0FBQTtRQUV4QyxPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixXQUFXLElBQUksQ0FBQyxDQUFBO1FBQ3hELE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLGFBQWEsQ0FBQyxNQUFNLDJCQUEyQixDQUFDLENBQUE7UUFDdkYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsU0FBUyxJQUFJLENBQUMsQ0FBQTtRQUNoRCxPQUFPLENBQUMsR0FBRyxDQUFDLDBDQUEwQyxDQUFDLENBQUE7UUFFdkQsbUJBQW1CO1FBQ25CLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxLQUFLLEVBQUUsYUFBYTtTQUNyQixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxTQUFTLENBQUE7UUFDeEMsT0FBTyxDQUFDLEtBQUssQ0FBQywwQ0FBMEMsQ0FBQyxDQUFBO1FBQ3pELE9BQU8sQ0FBQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDdkMsT0FBTyxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsU0FBUyxJQUFJLENBQUMsQ0FBQTtRQUNwRCxPQUFPLENBQUMsS0FBSyxDQUFDLDBDQUEwQyxDQUFDLENBQUE7UUFDekQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsT0FBTyxFQUFFLGVBQWU7WUFDeEIsS0FBSyxFQUFFLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWU7U0FDaEUsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==