"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.POST = POST;
const formidable_1 = __importDefault(require("formidable"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.AUTHENTICATE = true;
// 清理文件名函數
function sanitizeFilename(filename) {
    if (!filename)
        return Date.now().toString();
    const ext = path_1.default.extname(filename);
    let baseName = path_1.default.basename(filename, ext);
    // 移除特殊字符，保留英文、數字、連字號和下劃線
    baseName = baseName
        .replace(/[^\w\-_.]/g, '_')
        .replace(/_{2,}/g, '_')
        .substring(0, 50);
    return `${baseName}_${Date.now()}${ext}`;
}
async function POST(req, res) {
    const startTime = Date.now();
    try {
        console.log("📤 File upload request received via /admin/uploads");
        console.log(`   Request headers:`, req.headers['content-type']);
        console.log(`   Request size:`, req.headers['content-length']);
        // 確保上傳目錄存在
        const uploadDir = path_1.default.join(process.cwd(), 'static', 'uploads');
        if (!fs_1.default.existsSync(uploadDir)) {
            fs_1.default.mkdirSync(uploadDir, { recursive: true });
        }
        console.log(`   ⏱️  [${Date.now() - startTime}ms] Directory check complete`);
        // 解析表單數據
        const parseStart = Date.now();
        const form = (0, formidable_1.default)({
            maxFileSize: 10 * 1024 * 1024, // 10MB
            multiples: true,
            uploadDir: uploadDir,
            keepExtensions: true,
        });
        const [fields, files] = await form.parse(req);
        console.log(`   ⏱️  [${Date.now() - parseStart}ms] Form parse complete`);
        const uploadedFiles = [];
        const fileList = Array.isArray(files.files) ? files.files : [files.files].filter(Boolean);
        for (const file of fileList) {
            if (!file)
                continue;
            // 清理文件名
            const sanitizedName = sanitizeFilename(file.originalFilename || file.newFilename || 'upload');
            const newPath = path_1.default.join(uploadDir, sanitizedName);
            // 移動文件到最終位置
            if (file.filepath !== newPath) {
                fs_1.default.renameSync(file.filepath, newPath);
            }
            const baseUrl = process.env.BACKEND_URL || 'https://admin.timsfantasyworld.com';
            const fullUrl = `${baseUrl}/static/uploads/${sanitizedName}`;
            console.log(`✅ Uploaded file via /admin/uploads: ${sanitizedName}`);
            console.log(`   URL: ${fullUrl}`);
            uploadedFiles.push({
                id: sanitizedName,
                url: fullUrl,
                key: sanitizedName, // 只用檔名作為 key
                filename: file.originalFilename || file.newFilename,
                size: file.size,
                mimetype: file.mimetype || 'application/octet-stream'
            });
        }
        console.log(`✅ Successfully uploaded ${uploadedFiles.length} files via /admin/uploads`);
        // 返回格式：files（與 /admin/files 相同）
        res.status(200).json({
            files: uploadedFiles
        });
    }
    catch (error) {
        console.error("❌ Upload error:", error);
        res.status(500).json({
            message: "Upload failed",
            error: error instanceof Error ? error.message : "Unknown error"
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuYmFja3VwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL2FwaS9hZG1pbi91cGxvYWRzL3JvdXRlLmJhY2t1cC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUEyQkEsb0JBMkVDO0FBakdELDREQUFtQztBQUNuQyw0Q0FBbUI7QUFDbkIsZ0RBQXVCO0FBRVYsUUFBQSxZQUFZLEdBQUcsSUFBSSxDQUFBO0FBRWhDLFVBQVU7QUFDVixTQUFTLGdCQUFnQixDQUFDLFFBQWdCO0lBQ3hDLElBQUksQ0FBQyxRQUFRO1FBQUUsT0FBTyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUE7SUFFM0MsTUFBTSxHQUFHLEdBQUcsY0FBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUNsQyxJQUFJLFFBQVEsR0FBRyxjQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQTtJQUUzQyx5QkFBeUI7SUFDekIsUUFBUSxHQUFHLFFBQVE7U0FDaEIsT0FBTyxDQUFDLFlBQVksRUFBRSxHQUFHLENBQUM7U0FDMUIsT0FBTyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUM7U0FDdEIsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQTtJQUVuQixPQUFPLEdBQUcsUUFBUSxJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxHQUFHLEVBQUUsQ0FBQTtBQUMxQyxDQUFDO0FBRU0sS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBK0IsRUFDL0IsR0FBbUI7SUFFbkIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFBO0lBQzVCLElBQUksQ0FBQztRQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsb0RBQW9ELENBQUMsQ0FBQTtRQUNqRSxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQTtRQUMvRCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFBO1FBRTlELFdBQVc7UUFDWCxNQUFNLFNBQVMsR0FBRyxjQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUE7UUFDL0QsSUFBSSxDQUFDLFlBQUUsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztZQUM5QixZQUFFLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1FBQzlDLENBQUM7UUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLFNBQVMsOEJBQThCLENBQUMsQ0FBQTtRQUU1RSxTQUFTO1FBQ1QsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFBO1FBQzdCLE1BQU0sSUFBSSxHQUFHLElBQUEsb0JBQVUsRUFBQztZQUN0QixXQUFXLEVBQUUsRUFBRSxHQUFHLElBQUksR0FBRyxJQUFJLEVBQUUsT0FBTztZQUN0QyxTQUFTLEVBQUUsSUFBSTtZQUNmLFNBQVMsRUFBRSxTQUFTO1lBQ3BCLGNBQWMsRUFBRSxJQUFJO1NBQ3JCLENBQUMsQ0FBQTtRQUVGLE1BQU0sQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFBO1FBQzdDLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsVUFBVSx5QkFBeUIsQ0FBQyxDQUFBO1FBRXhFLE1BQU0sYUFBYSxHQUFVLEVBQUUsQ0FBQTtRQUMvQixNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFBO1FBRXpGLEtBQUssTUFBTSxJQUFJLElBQUksUUFBUSxFQUFFLENBQUM7WUFDNUIsSUFBSSxDQUFDLElBQUk7Z0JBQUUsU0FBUTtZQUVuQixRQUFRO1lBQ1IsTUFBTSxhQUFhLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGdCQUFnQixJQUFJLElBQUksQ0FBQyxXQUFXLElBQUksUUFBUSxDQUFDLENBQUE7WUFDN0YsTUFBTSxPQUFPLEdBQUcsY0FBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsYUFBYSxDQUFDLENBQUE7WUFFbkQsWUFBWTtZQUNaLElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxPQUFPLEVBQUUsQ0FBQztnQkFDOUIsWUFBRSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFBO1lBQ3ZDLENBQUM7WUFFRCxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsSUFBSSxvQ0FBb0MsQ0FBQTtZQUMvRSxNQUFNLE9BQU8sR0FBRyxHQUFHLE9BQU8sbUJBQW1CLGFBQWEsRUFBRSxDQUFBO1lBRTVELE9BQU8sQ0FBQyxHQUFHLENBQUMsdUNBQXVDLGFBQWEsRUFBRSxDQUFDLENBQUE7WUFDbkUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLE9BQU8sRUFBRSxDQUFDLENBQUE7WUFFakMsYUFBYSxDQUFDLElBQUksQ0FBQztnQkFDakIsRUFBRSxFQUFFLGFBQWE7Z0JBQ2pCLEdBQUcsRUFBRSxPQUFPO2dCQUNaLEdBQUcsRUFBRSxhQUFhLEVBQUcsYUFBYTtnQkFDbEMsUUFBUSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJLENBQUMsV0FBVztnQkFDbkQsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2dCQUNmLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxJQUFJLDBCQUEwQjthQUN0RCxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsYUFBYSxDQUFDLE1BQU0sMkJBQTJCLENBQUMsQ0FBQTtRQUV2RixnQ0FBZ0M7UUFDaEMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFLGFBQWE7U0FDckIsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQ3ZDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLE9BQU8sRUFBRSxlQUFlO1lBQ3hCLEtBQUssRUFBRSxLQUFLLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFlO1NBQ2hFLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=