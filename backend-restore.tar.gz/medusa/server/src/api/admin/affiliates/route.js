"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const affiliate_1 = require("../../../modules/affiliate");
async function GET(req, res) {
    const affiliateService = req.scope.resolve(affiliate_1.AFFILIATE_MODULE);
    const { skip, take } = req.query;
    const [affiliates, count] = await affiliateService.listAndCountAffiliates({}, {
        skip: Number(skip) || 0,
        take: Number(take) || 20,
        order: { created_at: "DESC" }
    });
    res.json({
        affiliates,
        count,
        offset: Number(skip) || 0,
        limit: Number(take) || 20
    });
}
async function POST(req, res) {
    const affiliateService = req.scope.resolve(affiliate_1.AFFILIATE_MODULE);
    const body = req.body;
    // Admin can create affiliate directly
    const affiliate = await affiliateService.createAffiliates(body);
    res.json({ affiliate });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2FmZmlsaWF0ZXMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFJQSxrQkF1QkM7QUFFRCxvQkFXQztBQXZDRCwwREFBNkQ7QUFHdEQsS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxnQkFBZ0IsR0FBcUIsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsNEJBQWdCLENBQUMsQ0FBQTtJQUU5RSxNQUFNLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUE7SUFFaEMsTUFBTSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFNLGdCQUFnQixDQUFDLHNCQUFzQixDQUN2RSxFQUFFLEVBQ0Y7UUFDRSxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDdkIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFO1FBQ3hCLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUU7S0FDOUIsQ0FDRixDQUFBO0lBRUQsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNQLFVBQVU7UUFDVixLQUFLO1FBQ0wsTUFBTSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ3pCLEtBQUssRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRTtLQUMxQixDQUFDLENBQUE7QUFDSixDQUFDO0FBRU0sS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxnQkFBZ0IsR0FBcUIsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsNEJBQWdCLENBQUMsQ0FBQTtJQUM5RSxNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsSUFBVyxDQUFBO0lBRTVCLHNDQUFzQztJQUN0QyxNQUFNLFNBQVMsR0FBRyxNQUFNLGdCQUFnQixDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFBO0lBRS9ELEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFBO0FBQ3pCLENBQUMifQ==