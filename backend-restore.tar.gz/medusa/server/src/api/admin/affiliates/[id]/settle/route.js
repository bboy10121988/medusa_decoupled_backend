"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const affiliate_1 = require("../../../../../modules/affiliate");
async function POST(req, res) {
    const { id } = req.params;
    const affiliateService = req.scope.resolve(affiliate_1.AFFILIATE_MODULE);
    try {
        const affiliate = await affiliateService.retrieveAffiliate(id);
        const balance = Number(affiliate.balance);
        if (balance <= 0) {
            return res.status(400).json({ message: "No balance to settle" });
        }
        // Create settlement record
        const settlement = await affiliateService.createAffiliateSettlements({
            affiliate_id: id,
            amount: balance,
            currency_code: "TWD", // Default to TWD for now, or fetch from region/store
            status: "paid", // Administrative settlement assumes payment is handled
            period_start: null, // Could be calculated
            period_end: new Date(),
            metadata: {
                settled_by: "admin_manual_action",
                settled_at: new Date().toISOString()
            }
        });
        // Reset affiliate balance
        await affiliateService.updateAffiliates({
            id,
            balance: 0
        });
        res.json({
            message: "Settlement created successfully",
            settlement
        });
    }
    catch (error) {
        console.error("Error creating settlement:", error);
        res.status(500).json({ message: "Internal server error" });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2FmZmlsaWF0ZXMvW2lkXS9zZXR0bGUvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFJQSxvQkE2Q0M7QUFoREQsZ0VBQW1FO0FBRzVELEtBQUssVUFBVSxJQUFJLENBQ3RCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sRUFBRSxFQUFFLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFBO0lBQ3pCLE1BQU0sZ0JBQWdCLEdBQXFCLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLDRCQUFnQixDQUFDLENBQUE7SUFFOUUsSUFBSSxDQUFDO1FBQ0QsTUFBTSxTQUFTLEdBQUcsTUFBTSxnQkFBZ0IsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUU5RCxNQUFNLE9BQU8sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFBO1FBRXpDLElBQUksT0FBTyxJQUFJLENBQUMsRUFBRSxDQUFDO1lBQ2YsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxzQkFBc0IsRUFBRSxDQUFDLENBQUE7UUFDcEUsQ0FBQztRQUVELDJCQUEyQjtRQUMzQixNQUFNLFVBQVUsR0FBRyxNQUFNLGdCQUFnQixDQUFDLDBCQUEwQixDQUFDO1lBQ2pFLFlBQVksRUFBRSxFQUFFO1lBQ2hCLE1BQU0sRUFBRSxPQUFPO1lBQ2YsYUFBYSxFQUFFLEtBQUssRUFBRSxxREFBcUQ7WUFDM0UsTUFBTSxFQUFFLE1BQU0sRUFBRSx1REFBdUQ7WUFDdkUsWUFBWSxFQUFFLElBQUksRUFBRSxzQkFBc0I7WUFDMUMsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1lBQ3RCLFFBQVEsRUFBRTtnQkFDTixVQUFVLEVBQUUscUJBQXFCO2dCQUNqQyxVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7YUFDdkM7U0FDSixDQUFDLENBQUE7UUFFRiwwQkFBMEI7UUFDMUIsTUFBTSxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQztZQUNwQyxFQUFFO1lBQ0YsT0FBTyxFQUFFLENBQUM7U0FDYixDQUFDLENBQUE7UUFFRixHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ0wsT0FBTyxFQUFFLGlDQUFpQztZQUMxQyxVQUFVO1NBQ2IsQ0FBQyxDQUFBO0lBRU4sQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDYixPQUFPLENBQUMsS0FBSyxDQUFDLDRCQUE0QixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQ2xELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLHVCQUF1QixFQUFFLENBQUMsQ0FBQTtJQUM5RCxDQUFDO0FBQ0wsQ0FBQyJ9