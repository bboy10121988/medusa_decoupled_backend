"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.GET = GET;
exports.POST = POST;
const formidable_1 = __importDefault(require("formidable"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.AUTHENTICATE = true;
async function GET(req, res) {
    res.json({
        message: "File upload endpoint ready",
        methods: ["POST"],
        authenticated: true
    });
}
// 清理文件名函數
function sanitizeFilename(filename) {
    if (!filename)
        return Date.now().toString();
    const ext = path_1.default.extname(filename);
    let baseName = path_1.default.basename(filename, ext);
    // 移除特殊字符，保留英文、數字、連字號和下劃線
    baseName = baseName
        .replace(/[^\w\-_.]/g, '_')
        .replace(/_{2,}/g, '_')
        .substring(0, 50);
    return `${baseName}_${Date.now()}${ext}`;
}
async function POST(req, res) {
    try {
        console.log("📤 File upload request received");
        // 確保上傳目錄存在
        const uploadDir = path_1.default.join(process.cwd(), 'static', 'uploads');
        if (!fs_1.default.existsSync(uploadDir)) {
            fs_1.default.mkdirSync(uploadDir, { recursive: true });
        }
        // 解析表單數據
        const form = (0, formidable_1.default)({
            maxFileSize: 10 * 1024 * 1024, // 10MB
            multiples: true,
            uploadDir: uploadDir,
            keepExtensions: true,
        });
        const [fields, files] = await form.parse(req);
        const uploadedFiles = [];
        const fileList = Array.isArray(files.files) ? files.files : [files.files].filter(Boolean);
        for (const file of fileList) {
            if (!file)
                continue;
            // 清理文件名
            const sanitizedName = sanitizeFilename(file.originalFilename || file.newFilename || 'upload');
            const newPath = path_1.default.join(uploadDir, sanitizedName);
            // 移動文件到最終位置
            if (file.filepath !== newPath) {
                fs_1.default.renameSync(file.filepath, newPath);
            }
            const baseUrl = process.env.BACKEND_URL || 'http://localhost:9000';
            const fileUrl = `${baseUrl}/static/uploads/${sanitizedName}`;
            console.log(`✅ Uploaded file: ${sanitizedName}`);
            console.log(`   BACKEND_URL: ${process.env.BACKEND_URL}`);
            console.log(`   Generated URL: ${fileUrl}`);
            uploadedFiles.push({
                id: sanitizedName,
                url: fileUrl,
                filename: file.originalFilename || file.newFilename,
                size: file.size,
                mimetype: file.mimetype || 'application/octet-stream'
            });
        }
        console.log(`✅ Successfully uploaded ${uploadedFiles.length} files`);
        res.json({
            files: uploadedFiles
        });
    }
    catch (error) {
        console.error("❌ Upload error:", error);
        res.status(500).json({
            message: "Upload failed",
            error: error instanceof Error ? error.message : "Unknown error"
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2ZpbGVzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztBQVdBLGtCQVNDO0FBa0JELG9CQW1FQztBQXBHRCw0REFBbUM7QUFDbkMsNENBQW1CO0FBQ25CLGdEQUF1QjtBQUVWLFFBQUEsWUFBWSxHQUFHLElBQUksQ0FBQTtBQUV6QixLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUErQixFQUMvQixHQUFtQjtJQUVuQixHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsT0FBTyxFQUFFLDRCQUE0QjtRQUNyQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUM7UUFDakIsYUFBYSxFQUFFLElBQUk7S0FDcEIsQ0FBQyxDQUFBO0FBQ0osQ0FBQztBQUVELFVBQVU7QUFDVixTQUFTLGdCQUFnQixDQUFDLFFBQWdCO0lBQ3hDLElBQUksQ0FBQyxRQUFRO1FBQUUsT0FBTyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUE7SUFFM0MsTUFBTSxHQUFHLEdBQUcsY0FBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUNsQyxJQUFJLFFBQVEsR0FBRyxjQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQTtJQUUzQyx5QkFBeUI7SUFDekIsUUFBUSxHQUFHLFFBQVE7U0FDaEIsT0FBTyxDQUFDLFlBQVksRUFBRSxHQUFHLENBQUM7U0FDMUIsT0FBTyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUM7U0FDdEIsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQTtJQUVuQixPQUFPLEdBQUcsUUFBUSxJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxHQUFHLEVBQUUsQ0FBQTtBQUMxQyxDQUFDO0FBRU0sS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBK0IsRUFDL0IsR0FBbUI7SUFFbkIsSUFBSSxDQUFDO1FBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFBO1FBRTlDLFdBQVc7UUFDWCxNQUFNLFNBQVMsR0FBRyxjQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUE7UUFDL0QsSUFBSSxDQUFDLFlBQUUsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztZQUM5QixZQUFFLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1FBQzlDLENBQUM7UUFFRCxTQUFTO1FBQ1QsTUFBTSxJQUFJLEdBQUcsSUFBQSxvQkFBVSxFQUFDO1lBQ3RCLFdBQVcsRUFBRSxFQUFFLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBRSxPQUFPO1lBQ3RDLFNBQVMsRUFBRSxJQUFJO1lBQ2YsU0FBUyxFQUFFLFNBQVM7WUFDcEIsY0FBYyxFQUFFLElBQUk7U0FDckIsQ0FBQyxDQUFBO1FBRUYsTUFBTSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUE7UUFFN0MsTUFBTSxhQUFhLEdBQVUsRUFBRSxDQUFBO1FBQy9CLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUE7UUFFekYsS0FBSyxNQUFNLElBQUksSUFBSSxRQUFRLEVBQUUsQ0FBQztZQUM1QixJQUFJLENBQUMsSUFBSTtnQkFBRSxTQUFRO1lBRW5CLFFBQVE7WUFDUixNQUFNLGFBQWEsR0FBRyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxRQUFRLENBQUMsQ0FBQTtZQUM3RixNQUFNLE9BQU8sR0FBRyxjQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxhQUFhLENBQUMsQ0FBQTtZQUVuRCxZQUFZO1lBQ1osSUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLE9BQU8sRUFBRSxDQUFDO2dCQUM5QixZQUFFLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUE7WUFDdkMsQ0FBQztZQUVELE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxJQUFJLHVCQUF1QixDQUFBO1lBQ2xFLE1BQU0sT0FBTyxHQUFHLEdBQUcsT0FBTyxtQkFBbUIsYUFBYSxFQUFFLENBQUE7WUFFNUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsYUFBYSxFQUFFLENBQUMsQ0FBQTtZQUNoRCxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUE7WUFDekQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsT0FBTyxFQUFFLENBQUMsQ0FBQTtZQUUzQyxhQUFhLENBQUMsSUFBSSxDQUFDO2dCQUNqQixFQUFFLEVBQUUsYUFBYTtnQkFDakIsR0FBRyxFQUFFLE9BQU87Z0JBQ1osUUFBUSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJLENBQUMsV0FBVztnQkFDbkQsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2dCQUNmLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxJQUFJLDBCQUEwQjthQUN0RCxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsYUFBYSxDQUFDLE1BQU0sUUFBUSxDQUFDLENBQUE7UUFFcEUsR0FBRyxDQUFDLElBQUksQ0FBQztZQUNQLEtBQUssRUFBRSxhQUFhO1NBQ3JCLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUN2QyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixPQUFPLEVBQUUsZUFBZTtZQUN4QixLQUFLLEVBQUUsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZTtTQUNoRSxDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9