"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = exports.AUTHENTICATE = void 0;
exports.AUTHENTICATE = false;
const POST = async (req, res) => {
    try {
        console.log('🔑 收到 JWT token 生成請求');
        console.log('📋 Body:', req.body);
        const { auth_identity_id } = req.body;
        if (!auth_identity_id) {
            return res.status(400).json({
                error: 'Missing auth_identity_id'
            });
        }
        const authModuleService = req.scope.resolve("auth");
        // 取得 auth identity
        const authIdentity = await authModuleService.retrieveAuthIdentity(auth_identity_id);
        if (!authIdentity) {
            console.error('❌ Auth identity not found:', auth_identity_id);
            return res.status(404).json({
                error: 'Auth identity not found'
            });
        }
        console.log('✅ 找到 auth identity:', authIdentity.id);
        req.session = {
            auth_identity_id: authIdentity.id,
            actor_id: authIdentity.entity_id,
            actor_type: 'customer',
        };
        console.log('🔐 Session 已設置');
        // 對於 Medusa v2,我們返回成功狀態
        // 實際的認證通過 session cookie 處理
        return res.status(200).json({
            success: true,
            message: 'Authentication successful'
        });
    }
    catch (error) {
        console.error("❌ Token generation error:", error);
        return res.status(500).json({
            error: error.message || 'Failed to generate token'
        });
    }
};
exports.POST = POST;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2F1dGgvdG9rZW4vcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBRWEsUUFBQSxZQUFZLEdBQUcsS0FBSyxDQUFBO0FBRTFCLE1BQU0sSUFBSSxHQUFHLEtBQUssRUFDdkIsR0FBa0IsRUFDbEIsR0FBbUIsRUFDbkIsRUFBRTtJQUNGLElBQUksQ0FBQztRQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQTtRQUNuQyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUE7UUFFakMsTUFBTSxFQUFFLGdCQUFnQixFQUFFLEdBQUcsR0FBRyxDQUFDLElBQXFDLENBQUE7UUFFdEUsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDdEIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsS0FBSyxFQUFFLDBCQUEwQjthQUNsQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsTUFBTSxpQkFBaUIsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUVuRCxtQkFBbUI7UUFDbkIsTUFBTSxZQUFZLEdBQUcsTUFBTSxpQkFBaUIsQ0FBQyxvQkFBb0IsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBO1FBRW5GLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUNsQixPQUFPLENBQUMsS0FBSyxDQUFDLDRCQUE0QixFQUFFLGdCQUFnQixDQUFDLENBQUE7WUFDN0QsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsS0FBSyxFQUFFLHlCQUF5QjthQUNqQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxZQUFZLENBQUMsRUFBRSxDQUFDLENBUWxEO1FBQUMsR0FBVyxDQUFDLE9BQU8sR0FBRztZQUN0QixnQkFBZ0IsRUFBRSxZQUFZLENBQUMsRUFBRTtZQUNqQyxRQUFRLEVBQUcsWUFBb0IsQ0FBQyxTQUFTO1lBQ3pDLFVBQVUsRUFBRSxVQUFVO1NBQ3ZCLENBQUE7UUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUE7UUFFN0Isd0JBQXdCO1FBQ3hCLDRCQUE0QjtRQUM1QixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxJQUFJO1lBQ2IsT0FBTyxFQUFFLDJCQUEyQjtTQUNyQyxDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixPQUFPLENBQUMsS0FBSyxDQUFDLDJCQUEyQixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQ2pELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPLElBQUksMEJBQTBCO1NBQ25ELENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDLENBQUE7QUF6RFksUUFBQSxJQUFJLFFBeURoQiJ9