"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const affiliate_1 = require("../../../../../modules/affiliate");
async function POST(req, res) {
    const affiliateService = req.scope.resolve(affiliate_1.AFFILIATE_MODULE);
    const { linkId, affiliateId } = req.body;
    if (!linkId) {
        return res.status(400).json({ message: "Link ID is required" });
    }
    // Find the link
    const links = await affiliateService.listAffiliateLinks({ id: linkId }, { relations: ['affiliate'] });
    if (links.length === 0) {
        return res.status(404).json({ message: "Link not found" });
    }
    const link = links[0];
    // Record click
    await affiliateService.createAffiliateClicks({
        affiliate_id: affiliateId || link.affiliate?.id,
        link_id: link.id,
        ip: req.ip,
        user_agent: req.get('User-Agent'),
        metadata: {
            referrer: req.get('Referer')
        }
    });
    // Update link stats
    await affiliateService.updateAffiliateLinks({
        id: link.id,
        clicks: (link.clicks || 0) + 1
    });
    res.json({ success: true });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2FmZmlsaWF0ZXMvbGlua3MvY2xpY2svcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFJQSxvQkFvQ0M7QUF2Q0QsZ0VBQW1FO0FBRzVELEtBQUssVUFBVSxJQUFJLENBQ3hCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sZ0JBQWdCLEdBQXFCLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLDRCQUFnQixDQUFDLENBQUE7SUFDOUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFBVyxDQUFBO0lBRS9DLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNaLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsQ0FBQyxDQUFBO0lBQ2pFLENBQUM7SUFFRCxnQkFBZ0I7SUFDaEIsTUFBTSxLQUFLLEdBQUcsTUFBTSxnQkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUNyRyxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7UUFDdkIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxDQUFDLENBQUE7SUFDNUQsQ0FBQztJQUNELE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUVyQixlQUFlO0lBQ2YsTUFBTSxnQkFBZ0IsQ0FBQyxxQkFBcUIsQ0FBQztRQUMzQyxZQUFZLEVBQUUsV0FBVyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRTtRQUMvQyxPQUFPLEVBQUUsSUFBSSxDQUFDLEVBQUU7UUFDaEIsRUFBRSxFQUFFLEdBQUcsQ0FBQyxFQUFFO1FBQ1YsVUFBVSxFQUFFLEdBQUcsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDO1FBQ2pDLFFBQVEsRUFBRTtZQUNSLFFBQVEsRUFBRSxHQUFHLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztTQUM3QjtLQUNGLENBQUMsQ0FBQTtJQUVGLG9CQUFvQjtJQUNwQixNQUFNLGdCQUFnQixDQUFDLG9CQUFvQixDQUFDO1FBQzFDLEVBQUUsRUFBRSxJQUFJLENBQUMsRUFBRTtRQUNYLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQztLQUMvQixDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7QUFDN0IsQ0FBQyJ9