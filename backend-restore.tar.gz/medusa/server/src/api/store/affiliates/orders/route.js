"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const affiliate_1 = require("../../../../modules/affiliate");
const affiliate_auth_1 = require("../../../../utils/affiliate-auth");
async function GET(req, res) {
    const affiliateAuth = (0, affiliate_auth_1.getAffiliateFromRequest)(req);
    if (!affiliateAuth) {
        return res.status(401).json({ message: "Unauthorized" });
    }
    const affiliateService = req.scope.resolve(affiliate_1.AFFILIATE_MODULE);
    const conversions = await affiliateService.listAffiliateConversions({
        affiliate_id: affiliateAuth.id
    }, {
        relations: ["link"]
    });
    // Map to frontend expected format
    const orders = conversions.map(c => ({
        id: c.order_id,
        clickId: "N/A",
        linkId: c.link?.id,
        linkName: c.link?.code,
        orderValue: c.amount,
        commission: c.commission,
        customerEmail: c.metadata?.customer_email,
        createdAt: c.created_at,
        status: c.status
    }));
    const summary = {
        totalOrders: orders.length,
        totalValue: orders.reduce((sum, o) => sum + Number(o.orderValue), 0),
        totalCommission: orders.reduce((sum, o) => sum + Number(o.commission), 0),
        pendingCommission: orders.filter(o => o.status === 'pending').reduce((sum, o) => sum + Number(o.commission), 0)
    };
    res.json({
        summary,
        orders
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2FmZmlsaWF0ZXMvb3JkZXJzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBS0Esa0JBeUNDO0FBN0NELDZEQUFnRTtBQUVoRSxxRUFBMEU7QUFFbkUsS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxhQUFhLEdBQUcsSUFBQSx3Q0FBdUIsRUFBQyxHQUFHLENBQUMsQ0FBQTtJQUNsRCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDbkIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxjQUFjLEVBQUUsQ0FBQyxDQUFBO0lBQzFELENBQUM7SUFFRCxNQUFNLGdCQUFnQixHQUFxQixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyw0QkFBZ0IsQ0FBQyxDQUFBO0lBRTlFLE1BQU0sV0FBVyxHQUFHLE1BQU0sZ0JBQWdCLENBQUMsd0JBQXdCLENBQUM7UUFDbEUsWUFBWSxFQUFFLGFBQWEsQ0FBQyxFQUFFO0tBQy9CLEVBQUU7UUFDRCxTQUFTLEVBQUUsQ0FBQyxNQUFNLENBQUM7S0FDcEIsQ0FBQyxDQUFBO0lBRUYsa0NBQWtDO0lBQ2xDLE1BQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ25DLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUTtRQUNkLE9BQU8sRUFBRSxLQUFLO1FBQ2QsTUFBTSxFQUFFLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRTtRQUNsQixRQUFRLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxJQUFJO1FBQ3RCLFVBQVUsRUFBRSxDQUFDLENBQUMsTUFBTTtRQUNwQixVQUFVLEVBQUUsQ0FBQyxDQUFDLFVBQVU7UUFDeEIsYUFBYSxFQUFHLENBQUMsQ0FBQyxRQUFnQixFQUFFLGNBQWM7UUFDbEQsU0FBUyxFQUFFLENBQUMsQ0FBQyxVQUFVO1FBQ3ZCLE1BQU0sRUFBRSxDQUFDLENBQUMsTUFBTTtLQUNqQixDQUFDLENBQUMsQ0FBQTtJQUVILE1BQU0sT0FBTyxHQUFHO1FBQ2QsV0FBVyxFQUFFLE1BQU0sQ0FBQyxNQUFNO1FBQzFCLFVBQVUsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3BFLGVBQWUsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3pFLGlCQUFpQixFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUNoSCxDQUFBO0lBRUQsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNQLE9BQU87UUFDUCxNQUFNO0tBQ1AsQ0FBQyxDQUFBO0FBQ0osQ0FBQyJ9