"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const affiliate_1 = require("../../../../modules/affiliate");
const affiliate_auth_1 = require("../../../../utils/affiliate-auth");
async function GET(req, res) {
    const affiliateAuth = (0, affiliate_auth_1.getAffiliateFromRequest)(req);
    if (!affiliateAuth) {
        return res.status(401).json({ message: "Unauthorized" });
    }
    const affiliateService = req.scope.resolve(affiliate_1.AFFILIATE_MODULE);
    const affiliate = await affiliateService.retrieveAffiliate(affiliateAuth.id);
    res.json({
        id: affiliate.id,
        email: affiliate.email,
        first_name: affiliate.first_name,
        last_name: affiliate.last_name,
        code: affiliate.code,
        status: affiliate.status,
        balance: affiliate.balance,
        total_earnings: affiliate.total_earnings,
        settings: affiliate.settings
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2FmZmlsaWF0ZXMvbWUvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFLQSxrQkF3QkM7QUE1QkQsNkRBQWdFO0FBRWhFLHFFQUEwRTtBQUVuRSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLGFBQWEsR0FBRyxJQUFBLHdDQUF1QixFQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQ2xELElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNuQixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLGNBQWMsRUFBRSxDQUFDLENBQUE7SUFDMUQsQ0FBQztJQUVELE1BQU0sZ0JBQWdCLEdBQXFCLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLDRCQUFnQixDQUFDLENBQUE7SUFFOUUsTUFBTSxTQUFTLEdBQUcsTUFBTSxnQkFBZ0IsQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUE7SUFFNUUsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNQLEVBQUUsRUFBRSxTQUFTLENBQUMsRUFBRTtRQUNoQixLQUFLLEVBQUUsU0FBUyxDQUFDLEtBQUs7UUFDdEIsVUFBVSxFQUFFLFNBQVMsQ0FBQyxVQUFVO1FBQ2hDLFNBQVMsRUFBRSxTQUFTLENBQUMsU0FBUztRQUM5QixJQUFJLEVBQUUsU0FBUyxDQUFDLElBQUk7UUFDcEIsTUFBTSxFQUFFLFNBQVMsQ0FBQyxNQUFNO1FBQ3hCLE9BQU8sRUFBRSxTQUFTLENBQUMsT0FBTztRQUMxQixjQUFjLEVBQUUsU0FBUyxDQUFDLGNBQWM7UUFDeEMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxRQUFRO0tBQzdCLENBQUMsQ0FBQTtBQUNKLENBQUMifQ==