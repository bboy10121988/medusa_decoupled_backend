"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = exports.GET = void 0;
/**
 * GET /auth/customer/google/callback
 *
 * Medusa v2 標準的 Google OAuth callback 端點
 *
 * 這個端點由 @medusajs/auth-google middleware 自動處理
 * 當 Google 重定向回來時,middleware 會:
 * 1. 驗證 state (CSRF protection)
 * 2. 用 code 交換 access token
 * 3. 呼叫我們在 medusa-config.ts 中定義的 verify callback
 * 4. 建立/查找 customer
 * 5. 建立 auth session
 *
 * 我們在這裡的工作是:
 * 1. 從 middleware 處理後的結果取得 auth token
 * 2. 設定 HTTP-only cookie
 * 3. 重定向回前端
 */
const GET = async (req, res) => {
    try {
        console.log("=== /auth/customer/google/callback ===");
        console.log("Query params:", req.query);
        console.log("Auth context:", req.auth_context);
        console.log("Session:", req.session);
        // Medusa v2 auth middleware 處理後,會在 req 中設定這些屬性
        const auth = req.auth_context;
        if (!auth) {
            console.error("❌ No auth_context found - OAuth might have failed");
            const frontendUrl = process.env.FRONTEND_URL || 'https://timsfantasyworld.com';
            return res.redirect(`${frontendUrl}/tw/auth/google/callback?error=no_auth_context`);
        }
        console.log("✅ Auth context found:", {
            actor_id: auth.actor_id,
            actor_type: auth.actor_type,
            auth_identity_id: auth.auth_identity_id
        });
        // 從 JWT service 產生 token
        const jwtService = req.scope.resolve("jwt");
        const token = jwtService.generate({
            actor_id: auth.actor_id,
            actor_type: auth.actor_type,
            auth_identity_id: auth.auth_identity_id,
            app_metadata: {
                customer_id: auth.actor_id
            }
        });
        console.log("🔐 JWT token generated");
        console.log("🍪 Setting cookie...");
        // 設定 HTTP-only cookie (這是關鍵!)
        res.cookie('_medusa_jwt', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'lax', // 允許從 Google 跳轉時攜帶
            domain: '.timsfantasyworld.com', // 跨子網域共享
            path: '/',
            maxAge: 30 * 24 * 60 * 60 * 1000 // 30 天
        });
        console.log("✅ Cookie set successfully");
        // 重定向回前端 (帶上成功狀態)
        const frontendUrl = process.env.FRONTEND_URL || 'https://timsfantasyworld.com';
        const redirectUrl = `${frontendUrl}/tw/auth/google/callback?success=true`;
        console.log("📤 Redirecting to:", redirectUrl);
        return res.redirect(redirectUrl);
    }
    catch (error) {
        const fs = require('fs');
        try {
            fs.appendFileSync('/tmp/medusa-auth-debug.log', `[${new Date().toISOString()}] ❌ Route Handler Error: ${error}\nStack: ${error.stack}\n`);
        }
        catch (e) { }
        console.error("❌ OAuth callback error:", error);
        console.error("Stack:", error instanceof Error ? error.stack : 'Unknown');
        const frontendUrl = process.env.FRONTEND_URL || 'https://timsfantasyworld.com';
        return res.redirect(`${frontendUrl}/tw/auth/google/callback?error=server_error`);
    }
};
exports.GET = GET;
// 這個端點不應該被 Medusa 的標準認證 middleware 保護
// 因為它是 OAuth flow 的一部分
exports.AUTHENTICATE = false;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2F1dGgvY3VzdG9tZXIvZ29vZ2xlL2NhbGxiYWNrL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQU1BOzs7Ozs7Ozs7Ozs7Ozs7OztHQWlCRztBQUNJLE1BQU0sR0FBRyxHQUFHLEtBQUssRUFDdEIsR0FBa0IsRUFDbEIsR0FBbUIsRUFDbkIsRUFBRTtJQUNGLElBQUksQ0FBQztRQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsd0NBQXdDLENBQUMsQ0FBQTtRQUNyRCxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUE7UUFDdkMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUcsR0FBVyxDQUFDLFlBQVksQ0FBQyxDQUFBO1FBQ3ZELE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFHLEdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUU3QywrQ0FBK0M7UUFDL0MsTUFBTSxJQUFJLEdBQUksR0FBa0MsQ0FBQyxZQUFZLENBQUE7UUFFN0QsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ1YsT0FBTyxDQUFDLEtBQUssQ0FBQyxtREFBbUQsQ0FBQyxDQUFBO1lBQ2xFLE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxJQUFJLDhCQUE4QixDQUFBO1lBQzlFLE9BQU8sR0FBRyxDQUFDLFFBQVEsQ0FDakIsR0FBRyxXQUFXLGdEQUFnRCxDQUMvRCxDQUFBO1FBQ0gsQ0FBQztRQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLEVBQUU7WUFDbkMsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO1lBQ3ZCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtZQUMzQixnQkFBZ0IsRUFBRSxJQUFJLENBQUMsZ0JBQWdCO1NBQ3hDLENBQUMsQ0FBQTtRQUVGLHlCQUF5QjtRQUN6QixNQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQVEsQ0FBQTtRQUNsRCxNQUFNLEtBQUssR0FBRyxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ2hDLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtZQUN2QixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7WUFDM0IsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLGdCQUFnQjtZQUN2QyxZQUFZLEVBQUU7Z0JBQ1osV0FBVyxFQUFFLElBQUksQ0FBQyxRQUFRO2FBQzNCO1NBQ0YsQ0FBQyxDQUFBO1FBRUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFBO1FBQ3JDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQTtRQUVuQyw4QkFBOEI7UUFDOUIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsS0FBSyxFQUFFO1lBQy9CLFFBQVEsRUFBRSxJQUFJO1lBQ2QsTUFBTSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxLQUFLLFlBQVk7WUFDN0MsUUFBUSxFQUFFLEtBQUssRUFBRSxtQkFBbUI7WUFDcEMsTUFBTSxFQUFFLHVCQUF1QixFQUFFLFNBQVM7WUFDMUMsSUFBSSxFQUFFLEdBQUc7WUFDVCxNQUFNLEVBQUUsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxPQUFPO1NBQ3pDLENBQUMsQ0FBQTtRQUVGLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsQ0FBQTtRQUV4QyxrQkFBa0I7UUFDbEIsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLElBQUksOEJBQThCLENBQUE7UUFDOUUsTUFBTSxXQUFXLEdBQUcsR0FBRyxXQUFXLHVDQUF1QyxDQUFBO1FBRXpFLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsV0FBVyxDQUFDLENBQUE7UUFDOUMsT0FBTyxHQUFHLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFBO0lBRWxDLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsTUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3pCLElBQUksQ0FBQztZQUNILEVBQUUsQ0FBQyxjQUFjLENBQUMsNEJBQTRCLEVBQUUsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSw0QkFBNEIsS0FBSyxZQUFZLEtBQUssQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDO1FBQzVJLENBQUM7UUFBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUVmLE9BQU8sQ0FBQyxLQUFLLENBQUMseUJBQXlCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDL0MsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUE7UUFFekUsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLElBQUksOEJBQThCLENBQUE7UUFDOUUsT0FBTyxHQUFHLENBQUMsUUFBUSxDQUNqQixHQUFHLFdBQVcsNkNBQTZDLENBQzVELENBQUE7SUFDSCxDQUFDO0FBQ0gsQ0FBQyxDQUFBO0FBMUVZLFFBQUEsR0FBRyxPQTBFZjtBQUVELHNDQUFzQztBQUN0Qyx1QkFBdUI7QUFDVixRQUFBLFlBQVksR0FBRyxLQUFLLENBQUEifQ==