"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const funcs_1 = require("./funcs");
class Service {
    constructor(merchantID, host, hashKey, hashIV) {
        this.merchantID = '';
        this.host = '';
        this.hashKey = '';
        this.hashIV = '';
        this.merchantID = merchantID;
        this.host = host;
        this.hashKey = hashKey;
        this.hashIV = hashIV;
    }
    static createDefault() {
        const merchantID = process.env.ECPAY_MERCHANT_ID || '';
        const host = process.env.ECPAY_HOST || 'https://payment.ecpay.com.tw';
        const hashKey = process.env.ECPAY_HASH_KEY || '';
        const hashIV = process.env.ECPAY_HASH_IV || '';
        console.log("ECPay Service Config:", {
            "merchantID": merchantID,
            "host": host,
            "hashKey": hashKey,
            "hashIV": hashIV,
        });
        if (!merchantID) {
            throw new Error("ECPAY_MERCHANT_ID is not set in environment variables");
        }
        if (!hashKey) {
            throw new Error("ECPAY_HASH_KEY is not set in environment variables");
        }
        if (!hashIV) {
            throw new Error("ECPAY_HASH_IV is not set in environment variables");
        }
        if (!host) {
            throw new Error("ECPAY_HOST is not set in environment variables");
        }
        return new Service(merchantID, host, hashKey, hashIV);
    }
    getMerchantID() {
        return this.merchantID;
    }
    getHashKey() {
        return this.hashKey;
    }
    getHashIV() {
        return this.hashIV;
    }
    getHost() {
        return this.host;
    }
    getURL(path) {
        return this.host + path;
    }
    async getCreditDetail(param) {
        // 構建請求參數使用 URLSearchParams
        const requestData = new URLSearchParams({
            MerchantID: this.merchantID,
            CreditRefundId: param.CreditRefundId.toString(),
            CreditAmount: param.CreditAmount.toString(),
            CreditCheckCode: param.CreditCheckCode.toString()
        });
        // 為了生成檢查碼，需要轉換為物件格式
        // const dataForMac = Object.fromEntries(requestData);
        const checkMacValue = (0, funcs_1.createCheckMac)(requestData, this.hashKey, this.hashIV);
        // 添加檢查碼到請求參數
        requestData.append('CheckMacValue', checkMacValue);
        try {
            // 發送 POST 請求到綠界 API
            const response = await fetch(this.getURL('/CreditDetail/QueryTrade/V2'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: requestData.toString()
            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            // 直接解析 JSON 響應
            const responseData = await response.json();
            const result = {
                RtnMsg: responseData.RtnMsg || '',
                RtnValue: {
                    TradeID: responseData.RtnValue?.TradeID || '',
                    amount: responseData.RtnValue?.amount || '',
                    clsamt: responseData.RtnValue?.clsamt || '',
                    authtime: responseData.RtnValue?.authtime || '',
                    status: responseData.RtnValue?.status || '',
                    close_data: responseData.RtnValue?.close_data || []
                }
            };
            return result;
        }
        catch (error) {
            throw new Error(`Failed to get credit detail: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    async doCreditAction(param) {
        // 構建請求參數使用 URLSearchParams
        const requestData = new URLSearchParams({
            MerchantID: this.merchantID,
            MerchantTradeNo: param.MerchantTradeNo,
            TradeNo: param.TradeNo,
            Action: param.Action,
            TotalAmount: param.TotalAmount.toString(),
        });
        // 生成檢查碼
        const checkMacValue = (0, funcs_1.createCheckMac)(requestData, this.hashKey, this.hashIV);
        // 添加檢查碼到請求參數
        requestData.append('CheckMacValue', checkMacValue);
        try {
            // 發送 POST 請求到綠界 API
            const response = await fetch(this.getURL('/CreditDetail/DoAction'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: requestData.toString()
            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            console.log("ECPay doCreditAction response status:", response);
            const responseText = await response.text();
            console.log("ECPay doCreditAction response text:", responseText);
            let responseData = {};
            try {
                // 首先嘗試解析為 JSON
                responseData = JSON.parse(responseText);
                console.log("ECPay doCreditAction parsed response json data:", responseData);
            }
            catch (_) {
                console.log("Response is not JSON, trying form-encoded parsing...");
                // 如果不是 JSON，嘗試解析為 form-encoded 格式
                try {
                    const params = new URLSearchParams(responseText);
                    responseData = Object.fromEntries(params.entries());
                    console.log("Successfully parsed as form-encoded:", responseData);
                }
                catch (_) {
                    console.log("Response is not form-encoded, trying key-value parsing...");
                    // 如果也不是 form-encoded，嘗試解析為 key=value&key=value 格式
                    const lines = responseText.split('&');
                    if (lines.length === 0) {
                        throw new Error("Response format is unrecognized");
                    }
                    for (const line of lines) {
                        const [key, value] = line.split('=');
                        if (key && value !== undefined) {
                            responseData[key] = decodeURIComponent(value);
                        }
                    }
                    console.log("Parsed as key-value pairs:", responseData);
                }
            }
            // 直接解析 JSON 響應
            // const responseData = await response.json();
            const result = {
                MerchantID: responseData.MerchantID || '',
                MerchantTradeNo: responseData.MerchantTradeNo || '',
                TradeNo: responseData.TradeNo || '',
                RtnCode: responseData.RtnCode || 0,
                RtnMsg: responseData.RtnMsg || '',
            };
            return result;
        }
        catch (error) {
            throw new Error(`Failed to execute credit action: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
}
exports.default = Service;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9pbnRlcm5hbC9lY3BheXMvc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUNBLG1DQUF1QztBQUV2QyxNQUFNLE9BQU87SUFPVCxZQUFZLFVBQWtCLEVBQUUsSUFBWSxFQUFFLE9BQWUsRUFBRSxNQUFjO1FBTHRFLGVBQVUsR0FBVyxFQUFFLENBQUM7UUFDeEIsU0FBSSxHQUFVLEVBQUUsQ0FBQztRQUNqQixZQUFPLEdBQVcsRUFBRSxDQUFDO1FBQ3JCLFdBQU0sR0FBVyxFQUFFLENBQUM7UUFHdkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7UUFDN0IsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7UUFDakIsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7UUFDdkIsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7SUFDekIsQ0FBQztJQUVELE1BQU0sQ0FBQyxhQUFhO1FBR2hCLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLElBQUksRUFBRSxDQUFDO1FBQ3ZELE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxJQUFJLDhCQUE4QixDQUFDO1FBQ3RFLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxJQUFJLEVBQUUsQ0FBQztRQUNqRCxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsSUFBSSxFQUFFLENBQUM7UUFFL0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsRUFBQztZQUNoQyxZQUFZLEVBQUMsVUFBVTtZQUN2QixNQUFNLEVBQUMsSUFBSTtZQUNYLFNBQVMsRUFBRSxPQUFPO1lBQ2xCLFFBQVEsRUFBRSxNQUFNO1NBQ25CLENBQUMsQ0FBQTtRQUVGLElBQUksQ0FBQyxVQUFVLEVBQUMsQ0FBQztZQUNiLE1BQU0sSUFBSSxLQUFLLENBQUMsdURBQXVELENBQUMsQ0FBQztRQUM3RSxDQUFDO1FBRUQsSUFBSSxDQUFDLE9BQU8sRUFBQyxDQUFDO1lBQ1YsTUFBTSxJQUFJLEtBQUssQ0FBQyxvREFBb0QsQ0FBQyxDQUFDO1FBQzFFLENBQUM7UUFFRCxJQUFJLENBQUMsTUFBTSxFQUFDLENBQUM7WUFDVCxNQUFNLElBQUksS0FBSyxDQUFDLG1EQUFtRCxDQUFDLENBQUM7UUFDekUsQ0FBQztRQUVELElBQUksQ0FBQyxJQUFJLEVBQUMsQ0FBQztZQUNQLE1BQU0sSUFBSSxLQUFLLENBQUMsZ0RBQWdELENBQUMsQ0FBQztRQUN0RSxDQUFDO1FBR0QsT0FBTyxJQUFJLE9BQU8sQ0FDZCxVQUFVLEVBQ1YsSUFBSSxFQUNKLE9BQU8sRUFDUCxNQUFNLENBQ1QsQ0FBQztJQUNOLENBQUM7SUFFTSxhQUFhO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQztJQUMzQixDQUFDO0lBRU0sVUFBVTtRQUNiLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUN4QixDQUFDO0lBRU0sU0FBUztRQUNaLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQztJQUN2QixDQUFDO0lBRU0sT0FBTztRQUNWLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQztJQUNyQixDQUFDO0lBRU0sTUFBTSxDQUFDLElBQVc7UUFDckIsT0FBTyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztJQUM1QixDQUFDO0lBS0QsS0FBSyxDQUFDLGVBQWUsQ0FBQyxLQUFvQztRQUV0RCwyQkFBMkI7UUFDM0IsTUFBTSxXQUFXLEdBQUcsSUFBSSxlQUFlLENBQUM7WUFDcEMsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO1lBQzNCLGNBQWMsRUFBRSxLQUFLLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRTtZQUMvQyxZQUFZLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUU7WUFDM0MsZUFBZSxFQUFFLEtBQUssQ0FBQyxlQUFlLENBQUMsUUFBUSxFQUFFO1NBQ3BELENBQUMsQ0FBQztRQUVILG9CQUFvQjtRQUNwQixzREFBc0Q7UUFDdEQsTUFBTSxhQUFhLEdBQUcsSUFBQSxzQkFBYyxFQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUU3RSxhQUFhO1FBQ2IsV0FBVyxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFFbkQsSUFBSSxDQUFDO1lBQ0Qsb0JBQW9CO1lBQ3BCLE1BQU0sUUFBUSxHQUFHLE1BQU0sS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsNkJBQTZCLENBQUMsRUFBRTtnQkFDckUsTUFBTSxFQUFFLE1BQU07Z0JBQ2QsT0FBTyxFQUFFO29CQUNMLGNBQWMsRUFBRSxtQ0FBbUM7aUJBQ3REO2dCQUNELElBQUksRUFBRSxXQUFXLENBQUMsUUFBUSxFQUFFO2FBQy9CLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLENBQUM7Z0JBQ2YsTUFBTSxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFDOUQsQ0FBQztZQUVELGVBQWU7WUFDZixNQUFNLFlBQVksR0FBRyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUMzQyxNQUFNLE1BQU0sR0FBbUM7Z0JBQzNDLE1BQU0sRUFBRSxZQUFZLENBQUMsTUFBTSxJQUFJLEVBQUU7Z0JBQ2pDLFFBQVEsRUFBRTtvQkFDTixPQUFPLEVBQUUsWUFBWSxDQUFDLFFBQVEsRUFBRSxPQUFPLElBQUksRUFBRTtvQkFDN0MsTUFBTSxFQUFFLFlBQVksQ0FBQyxRQUFRLEVBQUUsTUFBTSxJQUFJLEVBQUU7b0JBQzNDLE1BQU0sRUFBRSxZQUFZLENBQUMsUUFBUSxFQUFFLE1BQU0sSUFBSSxFQUFFO29CQUMzQyxRQUFRLEVBQUUsWUFBWSxDQUFDLFFBQVEsRUFBRSxRQUFRLElBQUksRUFBRTtvQkFDL0MsTUFBTSxFQUFFLFlBQVksQ0FBQyxRQUFRLEVBQUUsTUFBTSxJQUFJLEVBQUU7b0JBQzNDLFVBQVUsRUFBRSxZQUFZLENBQUMsUUFBUSxFQUFFLFVBQVUsSUFBSSxFQUFFO2lCQUN0RDthQUNKLENBQUM7WUFFRixPQUFPLE1BQU0sQ0FBQztRQUVsQixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNiLE1BQU0sSUFBSSxLQUFLLENBQUMsZ0NBQWdDLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7UUFDaEgsQ0FBQztJQUNMLENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUFDLEtBQXNDO1FBRXZELDJCQUEyQjtRQUMzQixNQUFNLFdBQVcsR0FBRyxJQUFJLGVBQWUsQ0FBQztZQUNwQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7WUFDM0IsZUFBZSxFQUFFLEtBQUssQ0FBQyxlQUFlO1lBQ3RDLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztZQUN0QixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU07WUFDcEIsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFO1NBQzVDLENBQUMsQ0FBQztRQUVILFFBQVE7UUFDUixNQUFNLGFBQWEsR0FBRyxJQUFBLHNCQUFjLEVBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTdFLGFBQWE7UUFDYixXQUFXLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUVuRCxJQUFJLENBQUM7WUFDRCxvQkFBb0I7WUFDcEIsTUFBTSxRQUFRLEdBQUcsTUFBTSxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxFQUFFO2dCQUNoRSxNQUFNLEVBQUUsTUFBTTtnQkFDZCxPQUFPLEVBQUU7b0JBQ0wsY0FBYyxFQUFFLG1DQUFtQztpQkFDdEQ7Z0JBQ0QsSUFBSSxFQUFFLFdBQVcsQ0FBQyxRQUFRLEVBQUU7YUFDL0IsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQztnQkFDZixNQUFNLElBQUksS0FBSyxDQUFDLHVCQUF1QixRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUM5RCxDQUFDO1lBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1Q0FBdUMsRUFBQyxRQUFRLENBQUMsQ0FBQztZQUk5RCxNQUFNLFlBQVksR0FBRyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUUzQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxFQUFDLFlBQVksQ0FBQyxDQUFDO1lBR2hFLElBQUksWUFBWSxHQUFRLEVBQUUsQ0FBQztZQUMzQixJQUFHLENBQUM7Z0JBQ0EsZUFBZTtnQkFDZixZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDeEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpREFBaUQsRUFBQyxZQUFZLENBQUMsQ0FBQztZQUVoRixDQUFDO1lBQUEsT0FBTSxDQUFDLEVBQUMsQ0FBQztnQkFFTixPQUFPLENBQUMsR0FBRyxDQUFDLHNEQUFzRCxDQUFDLENBQUM7Z0JBRXBFLGtDQUFrQztnQkFDbEMsSUFBRyxDQUFDO29CQUNBLE1BQU0sTUFBTSxHQUFHLElBQUksZUFBZSxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUNqRCxZQUFZLEdBQUcsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztvQkFDcEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFDdEUsQ0FBQztnQkFBQSxPQUFNLENBQUMsRUFBQyxDQUFDO29CQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkRBQTJELENBQUMsQ0FBQztvQkFDekUsa0RBQWtEO29CQUNsRCxNQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUV0QyxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFDLENBQUM7d0JBQ3BCLE1BQU0sSUFBSSxLQUFLLENBQUMsaUNBQWlDLENBQUMsQ0FBQztvQkFDdkQsQ0FBQztvQkFFRCxLQUFLLE1BQU0sSUFBSSxJQUFJLEtBQUssRUFBRSxDQUFDO3dCQUN2QixNQUFNLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQ3JDLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSyxTQUFTLEVBQUUsQ0FBQzs0QkFDN0IsWUFBWSxDQUFDLEdBQUcsQ0FBQyxHQUFHLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUNsRCxDQUFDO29CQUNMLENBQUM7b0JBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFHNUQsQ0FBQztZQUVMLENBQUM7WUFJRCxlQUFlO1lBQ2YsOENBQThDO1lBQzlDLE1BQU0sTUFBTSxHQUFxQztnQkFDN0MsVUFBVSxFQUFFLFlBQVksQ0FBQyxVQUFVLElBQUksRUFBRTtnQkFDekMsZUFBZSxFQUFFLFlBQVksQ0FBQyxlQUFlLElBQUksRUFBRTtnQkFDbkQsT0FBTyxFQUFFLFlBQVksQ0FBQyxPQUFPLElBQUksRUFBRTtnQkFDbkMsT0FBTyxFQUFFLFlBQVksQ0FBQyxPQUFPLElBQUksQ0FBQztnQkFDbEMsTUFBTSxFQUFFLFlBQVksQ0FBQyxNQUFNLElBQUksRUFBRTthQUNwQyxDQUFDO1lBRUYsT0FBTyxNQUFNLENBQUM7UUFFbEIsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDYixNQUFNLElBQUksS0FBSyxDQUFDLG9DQUFvQyxLQUFLLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO1FBQ3BILENBQUM7SUFDTCxDQUFDO0NBRUo7QUFFRCxrQkFBZSxPQUFPLENBQUMifQ==