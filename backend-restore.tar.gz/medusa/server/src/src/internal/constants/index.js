"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ENV_MODE_PROD = exports.ENV_MODE_DEV = exports.ENV_MODE_LOCALHOST = void 0;
/**
 * 環境模式常數
 *
 * - 用途：集中管理 ENVIRONMENT_MODE 可用值，避免魔法字串散落各處。
 * - 匯出：以 named export 匯出，import 目錄即可使用（index.ts）。
 */
exports.ENV_MODE_LOCALHOST = "localhost";
exports.ENV_MODE_DEV = "dev";
exports.ENV_MODE_PROD = "prod";
exports.default = {
    ENV_MODE_LOCALHOST: exports.ENV_MODE_LOCALHOST,
    ENV_MODE_DEV: exports.ENV_MODE_DEV,
    ENV_MODE_PROD: exports.ENV_MODE_PROD,
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvc3JjL2ludGVybmFsL2NvbnN0YW50cy9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQTs7Ozs7R0FLRztBQUNVLFFBQUEsa0JBQWtCLEdBQUcsV0FBVyxDQUFBO0FBQ2hDLFFBQUEsWUFBWSxHQUFHLEtBQUssQ0FBQTtBQUNwQixRQUFBLGFBQWEsR0FBRyxNQUFNLENBQUE7QUFFbkMsa0JBQWU7SUFDYixrQkFBa0IsRUFBbEIsMEJBQWtCO0lBQ2xCLFlBQVksRUFBWixvQkFBWTtJQUNaLGFBQWEsRUFBYixxQkFBYTtDQUNkLENBQUEifQ==