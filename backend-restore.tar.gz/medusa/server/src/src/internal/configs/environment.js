"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getEnvironmentMode = getEnvironmentMode;
exports.isEnvironmentMode = isEnvironmentMode;
exports.isEnvironmentModeProd = isEnvironmentModeProd;
const constants = __importStar(require("../constants"));
/**
 * getEnvironmentMode
 *
 * - 方法用途：讀取 `.env` 檔中的 `ENVIRONMENT_MODE`，回傳目前執行環境模式字串。
 * - 參數說明：無。
 * - 回傳值說明：若環境變數存在則回傳其字串值，否則回傳空字串。
 */
function getEnvironmentMode() {
    return process.env.ENVIRONMENT_MODE ?? constants.ENV_MODE_LOCALHOST;
}
/**
 * isEnvironmentMode
 *
 * - 方法用途：檢查目前的 `ENVIRONMENT_MODE` 是否等於指定值。
 * - 參數說明：
 *   - `mode`: 要比對的模式字串（例如："localhost"、"dev"、"prod"）。
 * - 回傳值說明：
 *   - 若目前環境模式等於 `mode` 回傳 `true`，否則回傳 `false`。
 */
function isEnvironmentMode(mode) {
    return getEnvironmentMode() === mode;
}
/**
 * isEnvironmentModeProd
 *
 * - 方法用途：檢查目前的 `ENVIRONMENT_MODE` 是否為生產環境模式。
 * - 參數說明：無。
 * - 回傳值說明：
 *   - 若目前環境模式為生產環境回傳 `true`，否則回傳 `false`。
 */
function isEnvironmentModeProd() {
    return isEnvironmentMode(constants.ENV_MODE_PROD);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW52aXJvbm1lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvc3JjL2ludGVybmFsL2NvbmZpZ3MvZW52aXJvbm1lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF1Q1MsZ0RBQWtCO0FBQUUsOENBQWlCO0FBQUUsc0RBQXFCO0FBdkNyRSx3REFBeUM7QUFFekM7Ozs7OztHQU1HO0FBQ0gsU0FBUyxrQkFBa0I7SUFDekIsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixJQUFJLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQTtBQUNyRSxDQUFDO0FBRUQ7Ozs7Ozs7O0dBUUc7QUFDSCxTQUFTLGlCQUFpQixDQUFDLElBQVk7SUFDckMsT0FBTyxrQkFBa0IsRUFBRSxLQUFLLElBQUksQ0FBQTtBQUN0QyxDQUFDO0FBRUQ7Ozs7Ozs7R0FPRztBQUNILFNBQVMscUJBQXFCO0lBQzVCLE9BQU8saUJBQWlCLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxDQUFBO0FBQ25ELENBQUMifQ==