"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const uuid_1 = require("uuid");
const funcs_1 = require("./funcs");
/**
 * ECPayCreditProviderService
 *
 * - 提供 Medusa Payment Module 的 ECPay 信用卡支付實作入口
 * - 目前僅提供必要方法的「空實作」與完整註解，方便後續填入實際邏輯
 */
class ECPayCreditProviderService extends utils_1.AbstractPaymentProvider {
    /**
     * 建構子
     *
     * - 方法用途：初始化第三方金流客戶端或連線，並接收框架容器與模組設定。
     * - 參數說明：
     *   - `container`: 由 Medusa 模組提供的 DI 容器（可解析 logger、repositories 等）。
     *   - `config`: 此金流供應商在 `medusa-config.ts` 中註冊時傳入的設定物件。
     * - 回傳值說明：無（建構子不回傳）。
     */
    constructor(container, config = {}) {
        super(container, config);
        this.container = container;
        this.config = config;
    }
    /**
     * initiatePayment
     *
     * - 方法用途：向第三方金流建立/初始化一筆付款會話（payment session），供後續授權/支付流程使用。
     * - 參數說明：
     *   - `input`: 包含金額、幣別與結帳情境（context，如顧客資訊）的初始化輸入。
     * - 回傳值說明：
     *   - 回傳一個物件，至少包含 `data` 欄位（會存入 PaymentSession 的 `data`）。
     */
    async initiatePayment(input) {
        return {
            id: (0, uuid_1.v4)(),
            data: {
                form_url: (0, funcs_1.getECPayFormURL)()
            }
        };
    }
    /**
     * authorizePayment
     *
     * - 方法用途：於下單前授權付款（例如信用卡 3DS 驗證完成後），建立實際 Payment 記錄。
     * - 參數說明：
     *   - `input`: 內含先前 `initiatePayment` 所存於 Session `data` 的資訊，用來在第三方完成授權。
     * - 回傳值說明：
     *   - 回傳 `{ status, data }`；`status` 通常為 `authorized`，`data` 會存入 Payment 的 `data`。
     */
    async authorizePayment(input) {
        return {
            status: "authorized",
            data: {}
        };
    }
    /**
     * capturePayment
     *
     * - 方法用途：對已授權的付款進行請款（capture）。通常由後台操作或自動流程觸發。
     * - 參數說明：
     *   - `input`: 內含 Payment `data`（通常有第三方的付款識別），用以在第三方執行請款。
     * - 回傳值說明：
     *   - 回傳 `{ data }`；可回存第三方回傳的最新付款資料至 Payment 的 `data`。
     */
    async capturePayment(input) {
        return {
            data: input.data
        };
    }
    /**
     * refundPayment
     *
     * - 方法用途：對已請款成功的付款進行退款（可為部分或全部）。
     * - 參數說明：
     *   - `input`: 內含 Payment `data` 與退款金額 `amount` 等，用以在第三方執行退款。
     * - 回傳值說明：
     *   - 回傳 `{ data }`；可回存第三方回傳的退款結果至 Payment 的 `data`。
     */
    async refundPayment(input) {
        throw new Error("ECPayCreditProviderService.refundPayment 尚未實作");
    }
    /**
     * retrievePayment
     *
     * - 方法用途：向第三方查詢付款詳情，以回傳最新狀態或資料。
     * - 參數說明：
     *   - `input`: 內含 Payment `data`（例如第三方付款編號），用於第三方查詢付款。
     * - 回傳值說明：
     *   - 回傳第三方付款的資料物件。
     */
    async retrievePayment(input) {
        throw new Error("ECPayCreditProviderService.retrievePayment 尚未實作");
    }
    /**
     * cancelPayment
     *
     * - 方法用途：取消尚未請款的付款（通常用於訂單取消）。
     * - 參數說明：
     *   - `input`: 內含 Payment `data`，用以在第三方執行取消。
     * - 回傳值說明：
     *   - 回傳 `{ data }`（如需回存第三方取消結果）。
     */
    async cancelPayment(input) {
        throw new Error("ECPayCreditProviderService.cancelPayment 尚未實作");
    }
    /**
     * updatePayment
     *
     * - 方法用途：更新先前以 `initiatePayment` 建立的付款資訊（如金額、顧客資訊等）。
     * - 參數說明：
     *   - `input`: 內含要更新的欄位與既有 Session `data`。
     * - 回傳值說明：
     *   - 回傳最新的付款資料物件，將覆蓋/合併至 Session 的 `data`。
     */
    async updatePayment(input) {
        throw new Error("ECPayCreditProviderService.updatePayment 尚未實作");
    }
    /**
     * deletePayment
     *
     * - 方法用途：刪除／作廢已建立但未使用的付款會話（若第三方支援）。
     * - 參數說明：
     *   - `input`: 內含 Session `data`，用以在第三方取消/刪除對應會話。
     * - 回傳值說明：
     *   - 回傳 `{ data }`；可原樣回傳或附上第三方回應結果。
     */
    async deletePayment(input) {
        return {
            data: input.data
        };
    }
    /**
     * getPaymentStatus
     *
     * - 方法用途：查詢付款會話或付款單在第三方的即時狀態，回傳 Medusa 可理解的狀態值。
     * - 參數說明：
     *   - `input`: 內含 Session/Payment `data`，用以在第三方查詢狀態。
     * - 回傳值說明：
     *   - 回傳 `{ status, data? }`；`status` 可能為 `pending`、`authorized`、`captured`、`canceled` 等。
     */
    async getPaymentStatus(input) {
        throw new Error("ECPayCreditProviderService.getPaymentStatus 尚未實作");
    }
    /**
     * getWebhookActionAndData
     * route: http://localhost:9000/hooks/payment/ecpay_credit_card_ecpay_credit_card
     * - 方法用途：處理第三方金流的 Webhook，並回傳應由 Medusa 採取的動作與所需資料。
     * - 參數說明：
     *   - `payload`: Webhook 原始負載（headers、rawData、解析後資料等）。
     * - 回傳值說明：
     *   - 回傳 `{ action, data }`；`action` 可為 `authorized`、`captured`、`failed`、`not_supported`。
     */
    async getWebhookActionAndData(payload) {
        throw new Error("ECPayCreditProviderService.getWebhookActionAndData 尚未實作");
        // const data = payload.data
        // let paymentSessionID: string = ""
        // if (!data){
        //   throw new Error("payload.data is empty")
        // }
        // if (!data["CustomField4"]){
        //   throw new Error("Payment Session ID is missing")
        // }else if (typeof data["CustomField4"] === "string") {
        //   paymentSessionID = data["CustomField4"]
        // } else {
        //   paymentSessionID = `${data["CustomField4"]}`
        // }
        // if (!data["RtnCode"]){
        //   throw new Error("RtnCode is missing")
        // }
        // // 除了成功以外，都不要更新訂單狀態
        // switch (data["RtnCode"]) {
        //   case "1":
        //     break;
        //   case "10300066":
        //     // 「交易付款結果待確認中，請勿出貨」，請至廠商管理後台確認已付款完成再出貨。
        //     throw new Error("交易付款結果待確認中，請勿出貨")
        //   case "10100248":
        //     // 「拒絕交易，請客戶聯繫發卡行確認原因」
        //     throw new Error("拒絕交易，請客戶聯繫發卡行確認原因")
        //   case "10100252":
        //     // 「額度不足，請客戶檢查卡片額度或餘額」
        //     throw new Error("額度不足，請客戶檢查卡片額度或餘額")
        //   case "10100254":
        //     // 「交易失敗，請客戶聯繫發卡行確認交易限制」
        //     throw new Error("交易失敗，請客戶聯繫發卡行確認交易限制")
        //   case "10100251":
        //     // 「卡片過期，請客戶檢查卡片重新交易」
        //     throw new Error("卡片過期，請客戶檢查卡片重新交易")
        //   case "10100255":
        //     // 「報失卡，請客戶更換卡片重新交易」
        //     throw new Error("報失卡，請客戶更換卡片重新交易")
        //   case "10100256":
        //     // 「停用卡，請客戶更換卡片重新交易」
        //     throw new Error("停用卡，請客戶更換卡片重新交易")
        //   default:
        //     // 其他錯誤代碼
        //     throw new Error("未知錯誤，請聯繫客服")
        // }
        // return {
        //   action: "captured",
        //   data: {
        //     // assuming the session_id is stored in the metadata of the payment
        //     // in the third-party provider
        //     session_id: paymentSessionID,
        //     amount: data["TradeAmt"]?new BigNumber(data["TradeAmt"] as number):0
        //   }
        // }
    }
}
ECPayCreditProviderService.identifier = "ecpay_credit_card";
exports.default = ECPayCreditProviderService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWNwYXljcmVkaXRwcm92aWRlcnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvc3JjL21vZHVsZXMvZWNwYXltZW50cy9lY3BheWNyZWRpdHByb3ZpZGVyc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHFEQUFtRTtBQXdCbkUsK0JBQW1DO0FBQ25DLG1DQUF5QztBQUN6Qzs7Ozs7R0FLRztBQUNILE1BQXFCLDBCQUEyQixTQUFRLCtCQUF1QjtJQUk3RTs7Ozs7Ozs7T0FRRztJQUNILFlBQ3FCLFNBQWtDLEVBQ2xDLFNBQWtDLEVBQUU7UUFFdkQsS0FBSyxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQTtRQUhMLGNBQVMsR0FBVCxTQUFTLENBQXlCO1FBQ2xDLFdBQU0sR0FBTixNQUFNLENBQThCO0lBR3pELENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILEtBQUssQ0FBQyxlQUFlLENBQUMsS0FBMkI7UUFDL0MsT0FBTztZQUNMLEVBQUUsRUFBRSxJQUFBLFNBQU0sR0FBRTtZQUNaLElBQUksRUFBRTtnQkFDSixRQUFRLEVBQUUsSUFBQSx1QkFBZSxHQUFFO2FBQzVCO1NBQ0YsQ0FBQTtJQUNILENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxLQUE0QjtRQUNqRCxPQUFNO1lBQ0osTUFBTSxFQUFDLFlBQW9DO1lBQzNDLElBQUksRUFBQyxFQUFFO1NBQ1IsQ0FBQTtJQUNILENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILEtBQUssQ0FBQyxjQUFjLENBQUMsS0FBMEI7UUFDN0MsT0FBTztZQUNMLElBQUksRUFBQyxLQUFLLENBQUMsSUFBSTtTQUNoQixDQUFBO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUF5QjtRQUMzQyxNQUFNLElBQUksS0FBSyxDQUFDLCtDQUErQyxDQUFDLENBQUE7SUFDbEUsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsS0FBSyxDQUFDLGVBQWUsQ0FBQyxLQUEyQjtRQUMvQyxNQUFNLElBQUksS0FBSyxDQUFDLGlEQUFpRCxDQUFDLENBQUE7SUFDcEUsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUF5QjtRQUMzQyxNQUFNLElBQUksS0FBSyxDQUFDLCtDQUErQyxDQUFDLENBQUE7SUFDbEUsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUF5QjtRQUMzQyxNQUFNLElBQUksS0FBSyxDQUFDLCtDQUErQyxDQUFDLENBQUE7SUFDbEUsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUF5QjtRQUMzQyxPQUFPO1lBQ0wsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJO1NBQ2pCLENBQUE7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxLQUFLLENBQUMsZ0JBQWdCLENBQUMsS0FBNEI7UUFDakQsTUFBTSxJQUFJLEtBQUssQ0FBQyxrREFBa0QsQ0FBQyxDQUFBO0lBQ3JFLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILEtBQUssQ0FBQyx1QkFBdUIsQ0FDM0IsT0FBMEM7UUFHMUMsTUFBTSxJQUFJLEtBQUssQ0FBQyx5REFBeUQsQ0FBQyxDQUFBO1FBQzFFLDRCQUE0QjtRQUM1QixvQ0FBb0M7UUFFcEMsY0FBYztRQUNkLDZDQUE2QztRQUM3QyxJQUFJO1FBRUosOEJBQThCO1FBQzlCLHFEQUFxRDtRQUNyRCx3REFBd0Q7UUFDeEQsNENBQTRDO1FBQzVDLFdBQVc7UUFDWCxpREFBaUQ7UUFDakQsSUFBSTtRQUVKLHlCQUF5QjtRQUN6QiwwQ0FBMEM7UUFDMUMsSUFBSTtRQUVKLHNCQUFzQjtRQUN0Qiw2QkFBNkI7UUFDN0IsY0FBYztRQUNkLGFBQWE7UUFDYixxQkFBcUI7UUFDckIsK0NBQStDO1FBQy9DLHlDQUF5QztRQUN6QyxxQkFBcUI7UUFDckIsNkJBQTZCO1FBQzdCLDJDQUEyQztRQUMzQyxxQkFBcUI7UUFDckIsNkJBQTZCO1FBQzdCLDJDQUEyQztRQUMzQyxxQkFBcUI7UUFDckIsK0JBQStCO1FBQy9CLDZDQUE2QztRQUM3QyxxQkFBcUI7UUFDckIsNEJBQTRCO1FBQzVCLDBDQUEwQztRQUMxQyxxQkFBcUI7UUFDckIsMkJBQTJCO1FBQzNCLHlDQUF5QztRQUN6QyxxQkFBcUI7UUFDckIsMkJBQTJCO1FBQzNCLHlDQUF5QztRQUN6QyxhQUFhO1FBQ2IsZ0JBQWdCO1FBQ2hCLG9DQUFvQztRQUNwQyxJQUFJO1FBR0osV0FBVztRQUNYLHdCQUF3QjtRQUN4QixZQUFZO1FBQ1osMEVBQTBFO1FBQzFFLHFDQUFxQztRQUNyQyxvQ0FBb0M7UUFDcEMsMkVBQTJFO1FBQzNFLE1BQU07UUFDTixJQUFJO0lBRU4sQ0FBQzs7QUE3Tk0scUNBQVUsR0FBRyxtQkFBbUIsQ0FBQTtrQkFGcEIsMEJBQTBCIn0=