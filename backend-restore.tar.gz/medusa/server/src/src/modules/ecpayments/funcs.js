"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getECPayFormURL = getECPayFormURL;
const environment_1 = require("../../internal/configs/environment");
/**
 * getECPayFormURL
 *
 * - 方法用途：根據環境模式回傳對應的 ECPay 付款表單 URL。
 * - 參數說明：無。
 * - 回傳值說明：
 *   - 生產環境回傳正式環境 URL，否則回傳測試環境 URL。
 * - 備註：
 *   - 測試環境：https://payment-stage.ecpay.com.tw/Cashier/AioCheckOut/V5
 *   - 正式環境：https://payment.ecpay.com.tw/Cashier/AioCheckOut/V5
 */
function getECPayFormURL() {
    if ((0, environment_1.isEnvironmentModeProd)()) {
        return "https://payment.ecpay.com.tw/Cashier/AioCheckOut/V5";
    }
    return "https://payment-stage.ecpay.com.tw/Cashier/AioCheckOut/V5";
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnVuY3MuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvc3JjL21vZHVsZXMvZWNwYXltZW50cy9mdW5jcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQW9CUywwQ0FBZTtBQXBCeEIsb0VBQTBFO0FBRTFFOzs7Ozs7Ozs7O0dBVUc7QUFDSCxTQUFTLGVBQWU7SUFDdEIsSUFBSSxJQUFBLG1DQUFxQixHQUFFLEVBQUUsQ0FBQztRQUM1QixPQUFPLHFEQUFxRCxDQUFBO0lBQzlELENBQUM7SUFDRCxPQUFPLDJEQUEyRCxDQUFBO0FBQ3BFLENBQUMifQ==