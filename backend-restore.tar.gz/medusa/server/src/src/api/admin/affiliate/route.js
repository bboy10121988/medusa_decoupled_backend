"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
// GET /admin/affiliate - 獲取聯盟申請列表
async function GET(req, res) {
    try {
        // 讀取 affiliate.json 檔案
        const jsonFilePath = path.join(process.cwd(), 'src/data/affiliate.json');
        let affiliateData = { applications: [], affiliates: [] };
        try {
            if (fs.existsSync(jsonFilePath)) {
                const fileContent = fs.readFileSync(jsonFilePath, 'utf8');
                affiliateData = JSON.parse(fileContent);
            }
        }
        catch (readError) {
            console.error('Error reading affiliate.json:', readError);
        }
        // 獲取查詢參數
        const { status = 'pending', limit = 20, offset = 0 } = req.query;
        // 過濾申請
        let applications = affiliateData.applications || [];
        if (status && status !== 'all') {
            applications = applications.filter((app) => app.status === status);
        }
        // 分頁
        const total = applications.length;
        const paginatedApplications = applications.slice(Number(offset), Number(offset) + Number(limit));
        res.json({
            applications: paginatedApplications,
            affiliates: affiliateData.affiliates || [],
            count: total,
            offset: Number(offset),
            limit: Number(limit)
        });
    }
    catch (error) {
        console.error("Admin affiliate GET error:", error);
        res.status(500).json({
            error: "Internal server error",
            message: "獲取聯盟申請列表失敗"
        });
    }
}
// POST /admin/affiliate - 審核聯盟申請 (批准/拒絕)
async function POST(req, res) {
    try {
        const body = req.body;
        const { applicationId, action, commissionRate = 0.05, referralCode } = body;
        if (!applicationId || !action) {
            res.status(400).json({
                error: "Missing required fields",
                message: "Application ID and action are required"
            });
            return;
        }
        // 讀取現有資料
        const jsonFilePath = path.join(process.cwd(), 'src/data/affiliate.json');
        let affiliateData = { applications: [], affiliates: [] };
        try {
            if (fs.existsSync(jsonFilePath)) {
                const fileContent = fs.readFileSync(jsonFilePath, 'utf8');
                affiliateData = JSON.parse(fileContent);
            }
        }
        catch (readError) {
            console.error('Error reading affiliate.json:', readError);
            res.status(500).json({
                error: "Internal server error",
                message: "讀取資料失敗"
            });
            return;
        }
        // 找到對應申請
        const applicationIndex = affiliateData.applications.findIndex((app) => app.id === applicationId);
        if (applicationIndex === -1) {
            res.status(404).json({
                error: "Application not found",
                message: "找不到對應的申請"
            });
            return;
        }
        const application = affiliateData.applications[applicationIndex];
        if (action === 'approve') {
            // 批准申請 - 移動到聯盟夥伴列表
            const newAffiliate = {
                id: `aff_partner_${Date.now()}`,
                name: application.name,
                email: application.email,
                referral_code: referralCode || `REF${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
                commission_rate: commissionRate,
                status: "active",
                total_earnings: 0,
                pending_earnings: 0,
                website: application.website,
                social_media: application.socialMedia ? { description: application.socialMedia } : {},
                created_at: application.created_at,
                updated_at: new Date().toISOString()
            };
            // 添加到聯盟夥伴列表
            if (!affiliateData.affiliates) {
                affiliateData.affiliates = [];
            }
            affiliateData.affiliates.push(newAffiliate);
            // 更新申請狀態
            affiliateData.applications[applicationIndex].status = 'approved';
            affiliateData.applications[applicationIndex].updated_at = new Date().toISOString();
        }
        else if (action === 'reject') {
            // 拒絕申請
            affiliateData.applications[applicationIndex].status = 'rejected';
            affiliateData.applications[applicationIndex].updated_at = new Date().toISOString();
        }
        // 寫回檔案
        try {
            fs.writeFileSync(jsonFilePath, JSON.stringify(affiliateData, null, 2));
        }
        catch (writeError) {
            console.error('Error writing affiliate.json:', writeError);
            res.status(500).json({
                error: "Internal server error",
                message: "更新資料失敗"
            });
            return;
        }
        res.json({
            success: true,
            message: action === 'approve' ? '申請已批准' : '申請已拒絕',
            application: affiliateData.applications[applicationIndex]
        });
    }
    catch (error) {
        console.error("Admin affiliate POST error:", error);
        res.status(500).json({
            error: "Internal server error",
            message: "處理申請失敗"
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvc3JjL2FwaS9hZG1pbi9hZmZpbGlhdGUvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFRQSxrQkE4Q0M7QUFHRCxvQkE4R0M7QUFuS0QsdUNBQXdCO0FBQ3hCLDJDQUE0QjtBQUU1QixrQ0FBa0M7QUFDM0IsS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsSUFBSSxDQUFDO1FBQ0gsdUJBQXVCO1FBQ3ZCLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxFQUFFLHlCQUF5QixDQUFDLENBQUE7UUFDeEUsSUFBSSxhQUFhLEdBQVEsRUFBRSxZQUFZLEVBQUUsRUFBRSxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsQ0FBQTtRQUU3RCxJQUFJLENBQUM7WUFDSCxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztnQkFDaEMsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLENBQUE7Z0JBQ3pELGFBQWEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFBO1lBQ3pDLENBQUM7UUFDSCxDQUFDO1FBQUMsT0FBTyxTQUFTLEVBQUUsQ0FBQztZQUNuQixPQUFPLENBQUMsS0FBSyxDQUFDLCtCQUErQixFQUFFLFNBQVMsQ0FBQyxDQUFBO1FBQzNELENBQUM7UUFFRCxTQUFTO1FBQ1QsTUFBTSxFQUFFLE1BQU0sR0FBRyxTQUFTLEVBQUUsS0FBSyxHQUFHLEVBQUUsRUFBRSxNQUFNLEdBQUcsQ0FBQyxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtRQUVoRSxPQUFPO1FBQ1AsSUFBSSxZQUFZLEdBQUcsYUFBYSxDQUFDLFlBQVksSUFBSSxFQUFFLENBQUE7UUFDbkQsSUFBSSxNQUFNLElBQUksTUFBTSxLQUFLLEtBQUssRUFBRSxDQUFDO1lBQy9CLFlBQVksR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBUSxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxLQUFLLE1BQU0sQ0FBQyxDQUFBO1FBQ3pFLENBQUM7UUFFRCxLQUFLO1FBQ0wsTUFBTSxLQUFLLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQTtRQUNqQyxNQUFNLHFCQUFxQixHQUFHLFlBQVksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQTtRQUVoRyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ1AsWUFBWSxFQUFFLHFCQUFxQjtZQUNuQyxVQUFVLEVBQUUsYUFBYSxDQUFDLFVBQVUsSUFBSSxFQUFFO1lBQzFDLEtBQUssRUFBRSxLQUFLO1lBQ1osTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7WUFDdEIsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUM7U0FDckIsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDRCQUE0QixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQ2xELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRSx1QkFBdUI7WUFDOUIsT0FBTyxFQUFFLFlBQVk7U0FDdEIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUM7QUFFRCx5Q0FBeUM7QUFDbEMsS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsSUFBSSxDQUFDO1FBQ0gsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLElBS2hCLENBQUE7UUFFRCxNQUFNLEVBQUUsYUFBYSxFQUFFLE1BQU0sRUFBRSxjQUFjLEdBQUcsSUFBSSxFQUFFLFlBQVksRUFBRSxHQUFHLElBQUksQ0FBQTtRQUUzRSxJQUFJLENBQUMsYUFBYSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDOUIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ25CLEtBQUssRUFBRSx5QkFBeUI7Z0JBQ2hDLE9BQU8sRUFBRSx3Q0FBd0M7YUFDbEQsQ0FBQyxDQUFBO1lBQ0YsT0FBTTtRQUNSLENBQUM7UUFFRCxTQUFTO1FBQ1QsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEVBQUUseUJBQXlCLENBQUMsQ0FBQTtRQUN4RSxJQUFJLGFBQWEsR0FBUSxFQUFFLFlBQVksRUFBRSxFQUFFLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxDQUFBO1FBRTdELElBQUksQ0FBQztZQUNILElBQUksRUFBRSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO2dCQUNoQyxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLFlBQVksRUFBRSxNQUFNLENBQUMsQ0FBQTtnQkFDekQsYUFBYSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUE7WUFDekMsQ0FBQztRQUNILENBQUM7UUFBQyxPQUFPLFNBQVMsRUFBRSxDQUFDO1lBQ25CLE9BQU8sQ0FBQyxLQUFLLENBQUMsK0JBQStCLEVBQUUsU0FBUyxDQUFDLENBQUE7WUFDekQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ25CLEtBQUssRUFBRSx1QkFBdUI7Z0JBQzlCLE9BQU8sRUFBRSxRQUFRO2FBQ2xCLENBQUMsQ0FBQTtZQUNGLE9BQU07UUFDUixDQUFDO1FBRUQsU0FBUztRQUNULE1BQU0sZ0JBQWdCLEdBQUcsYUFBYSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFRLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssYUFBYSxDQUFDLENBQUE7UUFDckcsSUFBSSxnQkFBZ0IsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQzVCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNuQixLQUFLLEVBQUUsdUJBQXVCO2dCQUM5QixPQUFPLEVBQUUsVUFBVTthQUNwQixDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1IsQ0FBQztRQUVELE1BQU0sV0FBVyxHQUFHLGFBQWEsQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtRQUVoRSxJQUFJLE1BQU0sS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUN6QixtQkFBbUI7WUFDbkIsTUFBTSxZQUFZLEdBQUc7Z0JBQ25CLEVBQUUsRUFBRSxlQUFlLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtnQkFDL0IsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJO2dCQUN0QixLQUFLLEVBQUUsV0FBVyxDQUFDLEtBQUs7Z0JBQ3hCLGFBQWEsRUFBRSxZQUFZLElBQUksTUFBTSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLEVBQUU7Z0JBQzVGLGVBQWUsRUFBRSxjQUFjO2dCQUMvQixNQUFNLEVBQUUsUUFBUTtnQkFDaEIsY0FBYyxFQUFFLENBQUM7Z0JBQ2pCLGdCQUFnQixFQUFFLENBQUM7Z0JBQ25CLE9BQU8sRUFBRSxXQUFXLENBQUMsT0FBTztnQkFDNUIsWUFBWSxFQUFFLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUUsV0FBVyxFQUFFLFdBQVcsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDckYsVUFBVSxFQUFFLFdBQVcsQ0FBQyxVQUFVO2dCQUNsQyxVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7YUFDckMsQ0FBQTtZQUVELFlBQVk7WUFDWixJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUM5QixhQUFhLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQTtZQUMvQixDQUFDO1lBQ0QsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUE7WUFFM0MsU0FBUztZQUNULGFBQWEsQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFBO1lBQ2hFLGFBQWEsQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQTtRQUVwRixDQUFDO2FBQU0sSUFBSSxNQUFNLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDL0IsT0FBTztZQUNQLGFBQWEsQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFBO1lBQ2hFLGFBQWEsQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQTtRQUNwRixDQUFDO1FBRUQsT0FBTztRQUNQLElBQUksQ0FBQztZQUNILEVBQUUsQ0FBQyxhQUFhLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ3hFLENBQUM7UUFBQyxPQUFPLFVBQVUsRUFBRSxDQUFDO1lBQ3BCLE9BQU8sQ0FBQyxLQUFLLENBQUMsK0JBQStCLEVBQUUsVUFBVSxDQUFDLENBQUE7WUFDMUQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ25CLEtBQUssRUFBRSx1QkFBdUI7Z0JBQzlCLE9BQU8sRUFBRSxRQUFRO2FBQ2xCLENBQUMsQ0FBQTtZQUNGLE9BQU07UUFDUixDQUFDO1FBRUQsR0FBRyxDQUFDLElBQUksQ0FBQztZQUNQLE9BQU8sRUFBRSxJQUFJO1lBQ2IsT0FBTyxFQUFFLE1BQU0sS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTztZQUNqRCxXQUFXLEVBQUUsYUFBYSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQztTQUMxRCxDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsNkJBQTZCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDbkQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFLHVCQUF1QjtZQUM5QixPQUFPLEVBQUUsUUFBUTtTQUNsQixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9