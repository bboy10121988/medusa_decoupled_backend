"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
// POST /affiliate/applications - 提交聯盟申請
async function POST(req, res) {
    try {
        const body = req.body;
        const { name, email, website, description, social_media } = body;
        if (!name || !email) {
            res.status(400).json({
                error: "Missing required fields",
                message: "Name and email are required"
            });
            return;
        }
        // 這裡應該保存申請到資料庫
        const application = {
            id: `app_${Date.now()}`,
            name,
            email,
            website: website || "",
            description: description || "",
            social_media: social_media || "",
            status: "pending",
            created_at: new Date(),
            updated_at: new Date()
        };
        res.status(201).json({
            application,
            message: "Application submitted successfully"
        });
    }
    catch (error) {
        res.status(500).json({
            error: "Internal server error",
            message: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvc3JjL2FwaS9hZmZpbGlhdGUvYXBwbGljYXRpb25zL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBTUEsb0JBNkNDO0FBOUNELHdDQUF3QztBQUNqQyxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixJQUFJLENBQUM7UUFDSCxNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsSUFNaEIsQ0FBQTtRQUNELE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLEdBQUcsSUFBSSxDQUFBO1FBRWhFLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNwQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkIsS0FBSyxFQUFFLHlCQUF5QjtnQkFDaEMsT0FBTyxFQUFFLDZCQUE2QjthQUN2QyxDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1IsQ0FBQztRQUVELGVBQWU7UUFDZixNQUFNLFdBQVcsR0FBRztZQUNsQixFQUFFLEVBQUUsT0FBTyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUU7WUFDdkIsSUFBSTtZQUNKLEtBQUs7WUFDTCxPQUFPLEVBQUUsT0FBTyxJQUFJLEVBQUU7WUFDdEIsV0FBVyxFQUFFLFdBQVcsSUFBSSxFQUFFO1lBQzlCLFlBQVksRUFBRSxZQUFZLElBQUksRUFBRTtZQUNoQyxNQUFNLEVBQUUsU0FBUztZQUNqQixVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7WUFDdEIsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1NBQ3ZCLENBQUE7UUFFRCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixXQUFXO1lBQ1gsT0FBTyxFQUFFLG9DQUFvQztTQUM5QyxDQUFDLENBQUE7SUFDSixDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUUsdUJBQXVCO1lBQzlCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztTQUN2QixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9