"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
// GET /affiliate/admin/affiliate/applications - 管理員獲取聯盟申請
async function GET(req, res) {
    try {
        // 這裡應該驗證管理員權限
        // 暫時返回模擬資料
        const applications = [
            {
                id: "app_1",
                name: "聯盟夥伴A",
                email: "partner-a@example.com",
                website: "https://example-a.com",
                status: "pending",
                created_at: new Date("2024-01-15"),
                updated_at: new Date("2024-01-15")
            },
            {
                id: "app_2",
                name: "聯盟夥伴B",
                email: "partner-b@example.com",
                website: "https://example-b.com",
                status: "approved",
                created_at: new Date("2024-01-10"),
                updated_at: new Date("2024-01-12")
            }
        ];
        res.json({
            applications,
            count: applications.length,
            offset: 0,
            limit: 20
        });
    }
    catch (error) {
        res.status(500).json({
            error: "Internal server error",
            message: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvc3JjL2FwaS9hZmZpbGlhdGUvYWRtaW4vYWZmaWxpYXRlL2FwcGxpY2F0aW9ucy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU1BLGtCQXdDQztBQXpDRCwwREFBMEQ7QUFDbkQsS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsSUFBSSxDQUFDO1FBQ0gsY0FBYztRQUNkLFdBQVc7UUFDWCxNQUFNLFlBQVksR0FBRztZQUNuQjtnQkFDRSxFQUFFLEVBQUUsT0FBTztnQkFDWCxJQUFJLEVBQUUsT0FBTztnQkFDYixLQUFLLEVBQUUsdUJBQXVCO2dCQUM5QixPQUFPLEVBQUUsdUJBQXVCO2dCQUNoQyxNQUFNLEVBQUUsU0FBUztnQkFDakIsVUFBVSxFQUFFLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDbEMsVUFBVSxFQUFFLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQzthQUNuQztZQUNEO2dCQUNFLEVBQUUsRUFBRSxPQUFPO2dCQUNYLElBQUksRUFBRSxPQUFPO2dCQUNiLEtBQUssRUFBRSx1QkFBdUI7Z0JBQzlCLE9BQU8sRUFBRSx1QkFBdUI7Z0JBQ2hDLE1BQU0sRUFBRSxVQUFVO2dCQUNsQixVQUFVLEVBQUUsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDO2dCQUNsQyxVQUFVLEVBQUUsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDO2FBQ25DO1NBQ0YsQ0FBQTtRQUVELEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxZQUFZO1lBQ1osS0FBSyxFQUFFLFlBQVksQ0FBQyxNQUFNO1lBQzFCLE1BQU0sRUFBRSxDQUFDO1lBQ1QsS0FBSyxFQUFFLEVBQUU7U0FDVixDQUFDLENBQUE7SUFDSixDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUUsdUJBQXVCO1lBQzlCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztTQUN2QixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9