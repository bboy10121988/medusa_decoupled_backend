"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
// POST /affiliate-apply - 聯盟註冊申請
async function POST(req, res) {
    try {
        const body = req.body;
        const { name, email, phone, website, socialMedia, experience, description } = body;
        // 基本驗證
        if (!name || !email) {
            res.status(400).json({
                error: "Missing required fields",
                message: "Name and email are required"
            });
            return;
        }
        // 電子郵件格式驗證
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            res.status(400).json({
                error: "Invalid email format",
                message: "Please provide a valid email address"
            });
            return;
        }
        // 讀取現有的 affiliate.json 檔案
        const jsonFilePath = path.join(process.cwd(), 'src/data/affiliate.json');
        let affiliateData = {};
        try {
            if (fs.existsSync(jsonFilePath)) {
                const fileContent = fs.readFileSync(jsonFilePath, 'utf8');
                affiliateData = JSON.parse(fileContent);
            }
        }
        catch (readError) {
            console.error('Error reading affiliate.json:', readError);
            // 如果讀取失敗，使用預設結構
            affiliateData = { affiliates: [], applications: [] };
        }
        // 確保 applications 陣列存在
        if (!affiliateData.applications) {
            affiliateData.applications = [];
        }
        // 檢查是否已有相同 email 的申請
        const existingApplication = affiliateData.applications.find((app) => app.email === email);
        if (existingApplication) {
            res.status(400).json({
                error: "Application exists",
                message: "此電子郵件地址已經提交過申請"
            });
            return;
        }
        // 生成新申請
        const applicationId = `app_${Date.now()}`;
        const newApplication = {
            id: applicationId,
            name,
            email,
            phone: phone || null,
            website: website || null,
            socialMedia: socialMedia || null,
            experience: experience || null,
            description: description || null,
            status: "pending",
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
        };
        // 添加新申請到陣列
        affiliateData.applications.push(newApplication);
        // 將更新後的資料寫回檔案
        try {
            fs.writeFileSync(jsonFilePath, JSON.stringify(affiliateData, null, 2));
        }
        catch (writeError) {
            console.error('Error writing affiliate.json:', writeError);
            res.status(500).json({
                error: "Internal server error",
                message: "申請提交失敗，請稍後再試"
            });
            return;
        }
        res.status(201).json({
            success: true,
            message: "聯盟申請提交成功",
            data: {
                ...newApplication,
                message: "申請已提交，我們會在 3-5 個工作天內審核您的申請。"
            }
        });
    }
    catch (error) {
        console.error("Affiliate application error:", error);
        res.status(500).json({
            error: "Internal server error",
            message: "申請提交失敗，請稍後再試"
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvc3JjL2FwaS9hZmZpbGlhdGUtYXBwbHkvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFRQSxvQkFpSEM7QUFySEQsdUNBQXdCO0FBQ3hCLDJDQUE0QjtBQUU1QixpQ0FBaUM7QUFDMUIsS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsSUFBSSxDQUFDO1FBQ0gsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLElBUWhCLENBQUE7UUFFRCxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsV0FBVyxFQUFFLEdBQUcsSUFBSSxDQUFBO1FBRWxGLE9BQU87UUFDUCxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDcEIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ25CLEtBQUssRUFBRSx5QkFBeUI7Z0JBQ2hDLE9BQU8sRUFBRSw2QkFBNkI7YUFDdkMsQ0FBQyxDQUFBO1lBQ0YsT0FBTTtRQUNSLENBQUM7UUFFRCxXQUFXO1FBQ1gsTUFBTSxVQUFVLEdBQUcsNEJBQTRCLENBQUE7UUFDL0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUM1QixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkIsS0FBSyxFQUFFLHNCQUFzQjtnQkFDN0IsT0FBTyxFQUFFLHNDQUFzQzthQUNoRCxDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1IsQ0FBQztRQUVELDBCQUEwQjtRQUMxQixNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsRUFBRSx5QkFBeUIsQ0FBQyxDQUFBO1FBQ3hFLElBQUksYUFBYSxHQUFRLEVBQUUsQ0FBQTtRQUUzQixJQUFJLENBQUM7WUFDSCxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztnQkFDaEMsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLENBQUE7Z0JBQ3pELGFBQWEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFBO1lBQ3pDLENBQUM7UUFDSCxDQUFDO1FBQUMsT0FBTyxTQUFTLEVBQUUsQ0FBQztZQUNuQixPQUFPLENBQUMsS0FBSyxDQUFDLCtCQUErQixFQUFFLFNBQVMsQ0FBQyxDQUFBO1lBQ3pELGdCQUFnQjtZQUNoQixhQUFhLEdBQUcsRUFBRSxVQUFVLEVBQUUsRUFBRSxFQUFFLFlBQVksRUFBRSxFQUFFLEVBQUUsQ0FBQTtRQUN0RCxDQUFDO1FBRUQsdUJBQXVCO1FBQ3ZCLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDaEMsYUFBYSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUE7UUFDakMsQ0FBQztRQUVELHFCQUFxQjtRQUNyQixNQUFNLG1CQUFtQixHQUFHLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBUSxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSyxLQUFLLEtBQUssQ0FBQyxDQUFBO1FBQzlGLElBQUksbUJBQW1CLEVBQUUsQ0FBQztZQUN4QixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkIsS0FBSyxFQUFFLG9CQUFvQjtnQkFDM0IsT0FBTyxFQUFFLGdCQUFnQjthQUMxQixDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1IsQ0FBQztRQUVELFFBQVE7UUFDUixNQUFNLGFBQWEsR0FBRyxPQUFPLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFBO1FBQ3pDLE1BQU0sY0FBYyxHQUFHO1lBQ3JCLEVBQUUsRUFBRSxhQUFhO1lBQ2pCLElBQUk7WUFDSixLQUFLO1lBQ0wsS0FBSyxFQUFFLEtBQUssSUFBSSxJQUFJO1lBQ3BCLE9BQU8sRUFBRSxPQUFPLElBQUksSUFBSTtZQUN4QixXQUFXLEVBQUUsV0FBVyxJQUFJLElBQUk7WUFDaEMsVUFBVSxFQUFFLFVBQVUsSUFBSSxJQUFJO1lBQzlCLFdBQVcsRUFBRSxXQUFXLElBQUksSUFBSTtZQUNoQyxNQUFNLEVBQUUsU0FBUztZQUNqQixVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUU7WUFDcEMsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO1NBQ3JDLENBQUE7UUFFRCxXQUFXO1FBQ1gsYUFBYSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUE7UUFFL0MsY0FBYztRQUNkLElBQUksQ0FBQztZQUNILEVBQUUsQ0FBQyxhQUFhLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ3hFLENBQUM7UUFBQyxPQUFPLFVBQVUsRUFBRSxDQUFDO1lBQ3BCLE9BQU8sQ0FBQyxLQUFLLENBQUMsK0JBQStCLEVBQUUsVUFBVSxDQUFDLENBQUE7WUFDMUQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ25CLEtBQUssRUFBRSx1QkFBdUI7Z0JBQzlCLE9BQU8sRUFBRSxjQUFjO2FBQ3hCLENBQUMsQ0FBQTtZQUNGLE9BQU07UUFDUixDQUFDO1FBRUQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsT0FBTyxFQUFFLElBQUk7WUFDYixPQUFPLEVBQUUsVUFBVTtZQUNuQixJQUFJLEVBQUU7Z0JBQ0osR0FBRyxjQUFjO2dCQUNqQixPQUFPLEVBQUUsNkJBQTZCO2FBQ3ZDO1NBQ0YsQ0FBQyxDQUFBO0lBRUosQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDhCQUE4QixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQ3BELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRSx1QkFBdUI7WUFDOUIsT0FBTyxFQUFFLGNBQWM7U0FDeEIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==