"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendEmailWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const core_flows_1 = require("@medusajs/medusa/core-flows");
/**
 * 電子郵件發送工作流程
 * 可用於發送各種類型的電子郵件通知
 */
exports.sendEmailWorkflow = (0, workflows_sdk_1.createWorkflow)("send-email-workflow", ({ id, email, template }) => {
    // 根據不同的範本類型查詢不同的資料
    let entityData;
    if (template === "product-created") {
        entityData = (0, core_flows_1.useQueryGraphStep)({
            entity: "product",
            fields: [
                "*",
                "images.*",
            ],
            filters: {
                id,
            },
        });
    }
    else if (template === "order-confirmation") {
        entityData = (0, core_flows_1.useQueryGraphStep)({
            entity: "order",
            fields: [
                "*",
                "customer.*",
                "items.*",
                "items.product.*",
                "shipping_address.*",
                "billing_address.*"
            ],
            filters: {
                id,
            },
        });
    }
    const { data } = entityData || { data: [] };
    // 根據範本類型準備不同的資料
    const emailData = (() => {
        if (template === "product-created" && data[0]) {
            const product = data[0];
            return {
                to: email || "admin@timsfantasyworld.com",
                channel: "email",
                template: "product-created",
                data: {
                    product_title: product.title,
                    product_description: product.description,
                    product_image: product.images?.[0]?.url || '',
                    product_url: `${process.env.FRONTEND_URL || 'https://timsfantasyworld.com'}/products/${product.handle}`,
                    admin_url: `${process.env.MEDUSA_ADMIN_BACKEND_URL || 'https://admin.timsfantasyworld.com'}/products/${product.id}`,
                },
            };
        }
        else if (template === "order-confirmation" && data[0]) {
            const order = data[0];
            const items = order.items?.filter((item) => item !== null).map((item) => ({
                title: item.product?.title || item.title || '未知商品',
                quantity: item.quantity || 0,
                unit_price: item.unit_price || 0,
                total: (item.unit_price || 0) * (item.quantity || 0)
            })) || [];
            return {
                to: email || order.customer?.email,
                channel: "email",
                template: "order-confirmation",
                data: {
                    customer_name: `${order.customer?.first_name || ''} ${order.customer?.last_name || ''}`.trim() || order.customer?.email,
                    order_id: order.id,
                    order_date: new Date().toLocaleDateString('zh-TW'),
                    total_amount: order.total || 0,
                    currency: order.currency_code?.toUpperCase() || 'TWD',
                    items: items,
                    shipping_address: order.shipping_address ? {
                        company: order.shipping_address.company,
                        first_name: order.shipping_address.first_name,
                        last_name: order.shipping_address.last_name,
                        address_1: order.shipping_address.address_1,
                        address_2: order.shipping_address.address_2,
                        city: order.shipping_address.city,
                        country_code: order.shipping_address.country_code,
                        postal_code: order.shipping_address.postal_code,
                    } : null,
                    store_name: "Tim's Fantasy World",
                    store_url: process.env.FRONTEND_URL || 'https://timsfantasyworld.com',
                    order_url: `${process.env.FRONTEND_URL || 'https://timsfantasyworld.com'}/account/orders/${order.id}`,
                },
            };
        }
        // 預設情況
        return {
            to: email || "admin@timsfantasyworld.com",
            channel: "email",
            template: template,
            data: {
                message: "這是一個測試通知",
                timestamp: new Date().toISOString(),
            },
        };
    })();
    (0, core_flows_1.sendNotificationsStep)([emailData]);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VuZC1lbWFpbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc2VuZC1lbWFpbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFBa0U7QUFDbEUsNERBR29DO0FBUXBDOzs7R0FHRztBQUNVLFFBQUEsaUJBQWlCLEdBQUcsSUFBQSw4QkFBYyxFQUM3QyxxQkFBcUIsRUFDckIsQ0FBQyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFpQixFQUFFLEVBQUU7SUFFekMsbUJBQW1CO0lBQ25CLElBQUksVUFBVSxDQUFBO0lBRWQsSUFBSSxRQUFRLEtBQUssaUJBQWlCLEVBQUUsQ0FBQztRQUNuQyxVQUFVLEdBQUcsSUFBQSw4QkFBaUIsRUFBQztZQUM3QixNQUFNLEVBQUUsU0FBUztZQUNqQixNQUFNLEVBQUU7Z0JBQ04sR0FBRztnQkFDSCxVQUFVO2FBQ1g7WUFDRCxPQUFPLEVBQUU7Z0JBQ1AsRUFBRTthQUNIO1NBQ0YsQ0FBQyxDQUFBO0lBQ0osQ0FBQztTQUFNLElBQUksUUFBUSxLQUFLLG9CQUFvQixFQUFFLENBQUM7UUFDN0MsVUFBVSxHQUFHLElBQUEsOEJBQWlCLEVBQUM7WUFDN0IsTUFBTSxFQUFFLE9BQU87WUFDZixNQUFNLEVBQUU7Z0JBQ04sR0FBRztnQkFDSCxZQUFZO2dCQUNaLFNBQVM7Z0JBQ1QsaUJBQWlCO2dCQUNqQixvQkFBb0I7Z0JBQ3BCLG1CQUFtQjthQUNwQjtZQUNELE9BQU8sRUFBRTtnQkFDUCxFQUFFO2FBQ0g7U0FDRixDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHLFVBQVUsSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQTtJQUUzQyxnQkFBZ0I7SUFDaEIsTUFBTSxTQUFTLEdBQUcsQ0FBQyxHQUFHLEVBQUU7UUFDdEIsSUFBSSxRQUFRLEtBQUssaUJBQWlCLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDOUMsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFBO1lBQ3ZCLE9BQU87Z0JBQ0wsRUFBRSxFQUFFLEtBQUssSUFBSSw0QkFBNEI7Z0JBQ3pDLE9BQU8sRUFBRSxPQUFnQjtnQkFDekIsUUFBUSxFQUFFLGlCQUFpQjtnQkFDM0IsSUFBSSxFQUFFO29CQUNKLGFBQWEsRUFBRSxPQUFPLENBQUMsS0FBSztvQkFDNUIsbUJBQW1CLEVBQUUsT0FBTyxDQUFDLFdBQVc7b0JBQ3hDLGFBQWEsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxJQUFJLEVBQUU7b0JBQzdDLFdBQVcsRUFBRSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxJQUFJLDhCQUE4QixhQUFhLE9BQU8sQ0FBQyxNQUFNLEVBQUU7b0JBQ3ZHLFNBQVMsRUFBRSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLElBQUksb0NBQW9DLGFBQWEsT0FBTyxDQUFDLEVBQUUsRUFBRTtpQkFDcEg7YUFDRixDQUFBO1FBQ0gsQ0FBQzthQUFNLElBQUksUUFBUSxLQUFLLG9CQUFvQixJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQ3hELE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUNyQixNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDLElBQVMsRUFBRSxFQUFFLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDbEYsS0FBSyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksTUFBTTtnQkFDbEQsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQztnQkFDNUIsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQztnQkFDaEMsS0FBSyxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxDQUFDO2FBQ3JELENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtZQUVULE9BQU87Z0JBQ0wsRUFBRSxFQUFFLEtBQUssSUFBSSxLQUFLLENBQUMsUUFBUSxFQUFFLEtBQUs7Z0JBQ2xDLE9BQU8sRUFBRSxPQUFnQjtnQkFDekIsUUFBUSxFQUFFLG9CQUFvQjtnQkFDOUIsSUFBSSxFQUFFO29CQUNKLGFBQWEsRUFBRSxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQUUsVUFBVSxJQUFJLEVBQUUsSUFBSSxLQUFLLENBQUMsUUFBUSxFQUFFLFNBQVMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxLQUFLLENBQUMsUUFBUSxFQUFFLEtBQUs7b0JBQ3ZILFFBQVEsRUFBRSxLQUFLLENBQUMsRUFBRTtvQkFDbEIsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDO29CQUNsRCxZQUFZLEVBQUUsS0FBSyxDQUFDLEtBQUssSUFBSSxDQUFDO29CQUM5QixRQUFRLEVBQUUsS0FBSyxDQUFDLGFBQWEsRUFBRSxXQUFXLEVBQUUsSUFBSSxLQUFLO29CQUNyRCxLQUFLLEVBQUUsS0FBSztvQkFDWixnQkFBZ0IsRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO3dCQUN6QyxPQUFPLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLE9BQU87d0JBQ3ZDLFVBQVUsRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsVUFBVTt3QkFDN0MsU0FBUyxFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTO3dCQUMzQyxTQUFTLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLFNBQVM7d0JBQzNDLFNBQVMsRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsU0FBUzt3QkFDM0MsSUFBSSxFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJO3dCQUNqQyxZQUFZLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLFlBQVk7d0JBQ2pELFdBQVcsRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsV0FBVztxQkFDaEQsQ0FBQyxDQUFDLENBQUMsSUFBSTtvQkFDUixVQUFVLEVBQUUscUJBQXFCO29CQUNqQyxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLElBQUksOEJBQThCO29CQUNyRSxTQUFTLEVBQUUsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksSUFBSSw4QkFBOEIsbUJBQW1CLEtBQUssQ0FBQyxFQUFFLEVBQUU7aUJBQ3RHO2FBQ0YsQ0FBQTtRQUNILENBQUM7UUFFRCxPQUFPO1FBQ1AsT0FBTztZQUNMLEVBQUUsRUFBRSxLQUFLLElBQUksNEJBQTRCO1lBQ3pDLE9BQU8sRUFBRSxPQUFnQjtZQUN6QixRQUFRLEVBQUUsUUFBUTtZQUNsQixJQUFJLEVBQUU7Z0JBQ0osT0FBTyxFQUFFLFVBQVU7Z0JBQ25CLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTthQUNwQztTQUNGLENBQUE7SUFDSCxDQUFDLENBQUMsRUFBRSxDQUFBO0lBRUosSUFBQSxrQ0FBcUIsRUFBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUE7QUFDcEMsQ0FBQyxDQUNGLENBQUEifQ==