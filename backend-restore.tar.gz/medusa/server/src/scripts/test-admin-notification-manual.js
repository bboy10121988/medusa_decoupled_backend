"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const admin_order_notification_1 = __importDefault(require("../subscribers/admin-order-notification"));
async function default_1({ container }) {
    const query = container.resolve("query");
    console.log("🔍 Searching for the most recent order...");
    let { data: orders } = await query.graph({
        entity: "order",
        fields: ["id", "created_at"],
        pagination: {
            take: 1,
            order: {
                created_at: "DESC"
            }
        }
    });
    // Use existing order logic (same as before)
    if (!orders || orders.length === 0) {
        console.log("❌ No orders found.");
        return;
    }
    const order = orders[0];
    console.log(`✅ Using order: ${order.id} (Created: ${order.created_at})`);
    // Test 1: Customer Notification (Should be sent to original customer email, as we reverted changes)
    // We can skip this if we only want to test Admin, but testing both ensures no regression.
    // console.log("📧 Invoking Customer orderPlacedHandler...")
    // await orderPlacedHandler({
    //   event: {
    //     name: "order.placed",
    //     data: { id: order.id },
    //     time: new Date(),
    //     metadata: {},
    //   } as any,
    //   container,
    //   pluginOptions: {}
    // } as any)
    // Test 2: Admin Notification
    console.log("📧 Invoking Admin adminOrderNotificationHandler...");
    await (0, admin_order_notification_1.default)({
        event: {
            name: "order.placed",
            data: { id: order.id },
            time: new Date(),
            metadata: {},
        },
        container,
        pluginOptions: {}
    });
    console.log("⏳ Waiting 10 seconds to allow async email logic to execute...");
    await new Promise(resolve => setTimeout(resolve, 10000));
    console.log("🏁 Test script finished.");
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVzdC1hZG1pbi1ub3RpZmljYXRpb24tbWFudWFsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NjcmlwdHMvdGVzdC1hZG1pbi1ub3RpZmljYXRpb24tbWFudWFsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBTUEsNEJBeURDO0FBM0RELHVHQUFtRjtBQUVwRSxLQUFLLG9CQUFXLEVBQUUsU0FBUyxFQUFZO0lBQ2xELE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUE7SUFFeEMsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQ0FBMkMsQ0FBQyxDQUFBO0lBRXhELElBQUksRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQ3JDLE1BQU0sRUFBRSxPQUFPO1FBQ2YsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLFlBQVksQ0FBQztRQUM1QixVQUFVLEVBQUU7WUFDUixJQUFJLEVBQUUsQ0FBQztZQUNQLEtBQUssRUFBRTtnQkFDSCxVQUFVLEVBQUUsTUFBTTthQUNyQjtTQUNKO0tBQ0osQ0FBQyxDQUFBO0lBRUYsNENBQTRDO0lBQzVDLElBQUksQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztRQUNqQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUE7UUFDakMsT0FBTTtJQUNWLENBQUM7SUFFRCxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDdkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsS0FBSyxDQUFDLEVBQUUsY0FBYyxLQUFLLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQTtJQUV4RSxvR0FBb0c7SUFDcEcsMEZBQTBGO0lBQzFGLDREQUE0RDtJQUM1RCw2QkFBNkI7SUFDN0IsYUFBYTtJQUNiLDRCQUE0QjtJQUM1Qiw4QkFBOEI7SUFDOUIsd0JBQXdCO0lBQ3hCLG9CQUFvQjtJQUNwQixjQUFjO0lBQ2QsZUFBZTtJQUNmLHNCQUFzQjtJQUN0QixZQUFZO0lBR1osNkJBQTZCO0lBQzdCLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0RBQW9ELENBQUMsQ0FBQTtJQUNqRSxNQUFNLElBQUEsa0NBQTZCLEVBQUM7UUFDaEMsS0FBSyxFQUFFO1lBQ0gsSUFBSSxFQUFFLGNBQWM7WUFDcEIsSUFBSSxFQUFFLEVBQUUsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUU7WUFDdEIsSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFO1lBQ2hCLFFBQVEsRUFBRSxFQUFFO1NBQ1I7UUFDUixTQUFTO1FBQ1QsYUFBYSxFQUFFLEVBQUU7S0FDYixDQUFDLENBQUE7SUFFVCxPQUFPLENBQUMsR0FBRyxDQUFDLCtEQUErRCxDQUFDLENBQUE7SUFDNUUsTUFBTSxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQTtJQUV4RCxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixDQUFDLENBQUE7QUFDM0MsQ0FBQyJ9