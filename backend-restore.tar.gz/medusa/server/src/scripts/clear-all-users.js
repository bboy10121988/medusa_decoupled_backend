"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = clearAllUsers;
const utils_1 = require("@medusajs/framework/utils");
/**
 * 清除所有用戶和認證資料的腳本
 * 注意：這將刪除所有客戶、認證身份和相關資料
 */
async function clearAllUsers({ container }) {
    console.log('🗑️  開始清除所有用戶和認證資料...');
    console.log('⚠️  注意：這將刪除所有客戶資料!');
    try {
        console.log('✅ 已連接到 Medusa 容器');
        // 獲取 Medusa 服務
        const customerModuleService = container.resolve(utils_1.Modules.CUSTOMER);
        const authModuleService = container.resolve(utils_1.Modules.AUTH);
        const cartModuleService = container.resolve(utils_1.Modules.CART);
        const orderModuleService = container.resolve(utils_1.Modules.ORDER);
        // 1. 先獲取所有客戶
        console.log('👤 獲取所有客戶資料...');
        const customers = await customerModuleService.listCustomers();
        console.log(`📊 找到 ${customers.length} 個客戶`);
        if (customers.length === 0) {
            console.log('ℹ️  沒有找到任何客戶資料');
            return;
        }
        // 2. 刪除所有購物車
        console.log('🛒 刪除所有購物車...');
        const carts = await cartModuleService.listCarts();
        const cartIds = carts.map(cart => cart.id);
        if (cartIds.length > 0) {
            await cartModuleService.deleteCarts(cartIds);
        }
        console.log(`✅ 已刪除 ${carts.length} 個購物車`);
        // 3. 刪除所有訂單
        console.log('📦 刪除所有訂單...');
        const orders = await orderModuleService.listOrders();
        const orderIds = orders.map(order => order.id);
        if (orderIds.length > 0) {
            await orderModuleService.deleteOrders(orderIds);
        }
        console.log(`✅ 已刪除 ${orders.length} 個訂單`);
        // 4. 刪除所有認證身份
        console.log('🔐 刪除所有認證身份...');
        const authIdentities = await authModuleService.listAuthIdentities();
        const identityIds = authIdentities.map(identity => identity.id);
        if (identityIds.length > 0) {
            await authModuleService.deleteAuthIdentities(identityIds);
        }
        console.log(`✅ 已刪除 ${authIdentities.length} 個認證身份`);
        // 5. 最後刪除所有客戶
        console.log('👤 刪除所有客戶...');
        const customerIds = customers.map(customer => customer.id);
        if (customerIds.length > 0) {
            await customerModuleService.deleteCustomers(customerIds);
        }
        console.log('✅ 所有用戶和認證資料已成功刪除');
        console.log(`📊 統計資訊:`);
        console.log(`   - 刪除客戶數量: ${customers.length}`);
        console.log(`   - 刪除購物車數量: ${carts.length}`);
        console.log(`   - 刪除訂單數量: ${orders.length}`);
        console.log(`   - 刪除認證身份數量: ${authIdentities.length}`);
        // 驗證刪除結果
        const remainingCustomers = await customerModuleService.listCustomers();
        if (remainingCustomers.length === 0) {
            console.log('✅ 驗證成功：所有客戶已被刪除');
        }
        else {
            console.log(`⚠️  警告：仍有 ${remainingCustomers.length} 個客戶記錄存在`);
        }
    }
    catch (error) {
        console.error('❌ 刪除用戶資料時發生錯誤:', error);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xlYXItYWxsLXVzZXJzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NjcmlwdHMvY2xlYXItYWxsLXVzZXJzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBT0EsZ0NBMkVDO0FBakZELHFEQUFtRDtBQUVuRDs7O0dBR0c7QUFDWSxLQUFLLFVBQVUsYUFBYSxDQUFDLEVBQUUsU0FBUyxFQUFZO0lBQ2pFLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQTtJQUNwQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUE7SUFFakMsSUFBSSxDQUFDO1FBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFBO1FBRS9CLGVBQWU7UUFDZixNQUFNLHFCQUFxQixHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO1FBQ2pFLE1BQU0saUJBQWlCLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDekQsTUFBTSxpQkFBaUIsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUN6RCxNQUFNLGtCQUFrQixHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBRTNELGFBQWE7UUFDYixPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUE7UUFDN0IsTUFBTSxTQUFTLEdBQUcsTUFBTSxxQkFBcUIsQ0FBQyxhQUFhLEVBQUUsQ0FBQTtRQUM3RCxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsU0FBUyxDQUFDLE1BQU0sTUFBTSxDQUFDLENBQUE7UUFFNUMsSUFBSSxTQUFTLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQzNCLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtZQUM3QixPQUFNO1FBQ1IsQ0FBQztRQUVELGFBQWE7UUFDYixPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO1FBQzVCLE1BQU0sS0FBSyxHQUFHLE1BQU0saUJBQWlCLENBQUMsU0FBUyxFQUFFLENBQUE7UUFDakQsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUMxQyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDdkIsTUFBTSxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUE7UUFDOUMsQ0FBQztRQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxLQUFLLENBQUMsTUFBTSxPQUFPLENBQUMsQ0FBQTtRQUV6QyxZQUFZO1FBQ1osT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQTtRQUMzQixNQUFNLE1BQU0sR0FBRyxNQUFNLGtCQUFrQixDQUFDLFVBQVUsRUFBRSxDQUFBO1FBQ3BELE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUE7UUFDOUMsSUFBSSxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQ3hCLE1BQU0sa0JBQWtCLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFBO1FBQ2pELENBQUM7UUFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsTUFBTSxDQUFDLE1BQU0sTUFBTSxDQUFDLENBQUE7UUFFekMsY0FBYztRQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtRQUM3QixNQUFNLGNBQWMsR0FBRyxNQUFNLGlCQUFpQixDQUFDLGtCQUFrQixFQUFFLENBQUE7UUFDbkUsTUFBTSxXQUFXLEdBQUcsY0FBYyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUMvRCxJQUFJLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDM0IsTUFBTSxpQkFBaUIsQ0FBQyxvQkFBb0IsQ0FBQyxXQUFXLENBQUMsQ0FBQTtRQUMzRCxDQUFDO1FBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLGNBQWMsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxDQUFBO1FBRW5ELGNBQWM7UUFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFBO1FBQzNCLE1BQU0sV0FBVyxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUE7UUFDMUQsSUFBSSxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQzNCLE1BQU0scUJBQXFCLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxDQUFBO1FBQzFELENBQUM7UUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUE7UUFDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQTtRQUN2QixPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQTtRQUMvQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQTtRQUM1QyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQTtRQUM1QyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixjQUFjLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQTtRQUV0RCxTQUFTO1FBQ1QsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLHFCQUFxQixDQUFDLGFBQWEsRUFBRSxDQUFBO1FBQ3RFLElBQUksa0JBQWtCLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3BDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQTtRQUNoQyxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxrQkFBa0IsQ0FBQyxNQUFNLFVBQVUsQ0FBQyxDQUFBO1FBQy9ELENBQUM7SUFFSCxDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUE7SUFDeEMsQ0FBQztBQUNILENBQUMifQ==