"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = setupTaiwanShippingHandler;
const utils_1 = require("@medusajs/framework/utils");
/**
 * 台灣地區配送設置檢查器
 * 檢查並創建必要的配送設置
 */
async function setupTaiwanShippingHandler({ event: { data }, container, }) {
    const fulfillmentModuleService = container.resolve(utils_1.Modules.FULFILLMENT);
    const logger = container.resolve("logger");
    try {
        logger.info("檢查台灣配送設置...");
        // 檢查是否已有台灣配送區域
        const existingServiceZones = await fulfillmentModuleService.listServiceZones({
            name: "Taiwan"
        });
        if (existingServiceZones.length > 0) {
            logger.info("台灣配送區域已存在");
            return;
        }
        logger.info("創建台灣配送設置...");
        // 創建台灣配送設定
        const fulfillmentSet = await fulfillmentModuleService.createFulfillmentSets({
            name: "Taiwan delivery",
            type: "shipping",
            service_zones: [
                {
                    name: "Taiwan",
                    geo_zones: [
                        {
                            country_code: "tw",
                            type: "country",
                        },
                    ],
                },
            ],
        });
        logger.info(`✅ 台灣配送設置已創建: ${fulfillmentSet.id}`);
    }
    catch (error) {
        logger.error("❌ 台灣配送設置失敗:", error);
    }
}
exports.config = {
    event: "store.updated", // 當商店更新時觸發檢查
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2V0dXAtdGFpd2FuLXNoaXBwaW5nLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3N1YnNjcmliZXJzL3NldHVwLXRhaXdhbi1zaGlwcGluZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFVQSw2Q0E0Q0M7QUFsREQscURBQW1EO0FBRW5EOzs7R0FHRztBQUNZLEtBQUssVUFBVSwwQkFBMEIsQ0FBQyxFQUN2RCxLQUFLLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFDZixTQUFTLEdBQ1U7SUFDbkIsTUFBTSx3QkFBd0IsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQTtJQUN2RSxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBRTFDLElBQUksQ0FBQztRQUNILE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUE7UUFFMUIsZUFBZTtRQUNmLE1BQU0sb0JBQW9CLEdBQUcsTUFBTSx3QkFBd0IsQ0FBQyxnQkFBZ0IsQ0FBQztZQUMzRSxJQUFJLEVBQUUsUUFBUTtTQUNmLENBQUMsQ0FBQTtRQUVGLElBQUksb0JBQW9CLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQ3BDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUE7WUFDeEIsT0FBTTtRQUNSLENBQUM7UUFFRCxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFBO1FBRTFCLFdBQVc7UUFDWCxNQUFNLGNBQWMsR0FBRyxNQUFNLHdCQUF3QixDQUFDLHFCQUFxQixDQUFDO1lBQzFFLElBQUksRUFBRSxpQkFBaUI7WUFDdkIsSUFBSSxFQUFFLFVBQVU7WUFDaEIsYUFBYSxFQUFFO2dCQUNiO29CQUNFLElBQUksRUFBRSxRQUFRO29CQUNkLFNBQVMsRUFBRTt3QkFDVDs0QkFDRSxZQUFZLEVBQUUsSUFBSTs0QkFDbEIsSUFBSSxFQUFFLFNBQVM7eUJBQ2hCO3FCQUNGO2lCQUNGO2FBQ0Y7U0FDRixDQUFDLENBQUE7UUFFRixNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixjQUFjLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQTtJQUVsRCxDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFBO0lBQ3BDLENBQUM7QUFDSCxDQUFDO0FBRVksUUFBQSxNQUFNLEdBQXFCO0lBQ3RDLEtBQUssRUFBRSxlQUFlLEVBQUUsYUFBYTtDQUN0QyxDQUFBIn0=