"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = productUpdatedRevalidationHandler;
/**
 * 產品更新時清除前端快取的訂閱者
 * 監聽產品更新事件，呼叫前端的 revalidation API
 */
async function productUpdatedRevalidationHandler({ event: { data }, container, }) {
    // 使用 setImmediate 避免阻塞產品更新流程
    setImmediate(async () => {
        try {
            console.log('Product updated, triggering frontend cache revalidation:', data.id);
            const frontendUrl = process.env.FRONTEND_URL || 'https://timsfantasyworld.com';
            const revalidationToken = process.env.REVALIDATION_TOKEN || 'medusa-revalidation-secret-2024';
            const revalidationUrl = frontendUrl + '/api/revalidate?token=' + revalidationToken;
            // 呼叫前端 revalidation API
            const response = await fetch(revalidationUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    type: 'product-status-changed',
                    productId: data.id,
                }),
            });
            if (response.ok) {
                const result = await response.json();
                console.log('Frontend cache cleared successfully:', result.timestamp);
            }
            else {
                console.error('Failed to clear frontend cache:', response.status, response.statusText);
            }
        }
        catch (error) {
            console.error('Error clearing frontend cache for product update:', error);
        }
    });
}
exports.config = {
    event: "product.updated",
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZHVjdC11cGRhdGVkLXJldmFsaWRhdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zdWJzY3JpYmVycy9wcm9kdWN0LXVwZGF0ZWQtcmV2YWxpZGF0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQVNBLG9EQXFDQztBQXpDRDs7O0dBR0c7QUFDWSxLQUFLLFVBQVUsaUNBQWlDLENBQUMsRUFDOUQsS0FBSyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQ2YsU0FBUyxHQUNzQjtJQUMvQiw2QkFBNkI7SUFDN0IsWUFBWSxDQUFDLEtBQUssSUFBSSxFQUFFO1FBQ3RCLElBQUksQ0FBQztZQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsMERBQTBELEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1lBRWhGLE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxJQUFJLDhCQUE4QixDQUFBO1lBQzlFLE1BQU0saUJBQWlCLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsSUFBSSxpQ0FBaUMsQ0FBQTtZQUU3RixNQUFNLGVBQWUsR0FBRyxXQUFXLEdBQUcsd0JBQXdCLEdBQUcsaUJBQWlCLENBQUE7WUFFbEYsd0JBQXdCO1lBQ3hCLE1BQU0sUUFBUSxHQUFHLE1BQU0sS0FBSyxDQUFDLGVBQWUsRUFBRTtnQkFDNUMsTUFBTSxFQUFFLE1BQU07Z0JBQ2QsT0FBTyxFQUFFO29CQUNQLGNBQWMsRUFBRSxrQkFBa0I7aUJBQ25DO2dCQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUNuQixJQUFJLEVBQUUsd0JBQXdCO29CQUM5QixTQUFTLEVBQUUsSUFBSSxDQUFDLEVBQUU7aUJBQ25CLENBQUM7YUFDSCxDQUFDLENBQUE7WUFFRixJQUFJLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQztnQkFDaEIsTUFBTSxNQUFNLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUE7Z0JBQ3BDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0NBQXNDLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFBO1lBQ3ZFLENBQUM7aUJBQU0sQ0FBQztnQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLGlDQUFpQyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFBO1lBQ3hGLENBQUM7UUFFSCxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsbURBQW1ELEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDM0UsQ0FBQztJQUNILENBQUMsQ0FBQyxDQUFBO0FBQ0osQ0FBQztBQUVZLFFBQUEsTUFBTSxHQUFxQjtJQUN0QyxLQUFLLEVBQUUsaUJBQWlCO0NBQ3pCLENBQUEifQ==