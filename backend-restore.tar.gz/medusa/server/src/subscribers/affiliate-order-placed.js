"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = affiliateOrderPlaced;
const affiliate_1 = require("../modules/affiliate");
async function affiliateOrderPlaced({ event: { data }, container, }) {
    const query = container.resolve("query");
    const affiliateService = container.resolve(affiliate_1.AFFILIATE_MODULE);
    try {
        const { data: [order] } = await query.graph({
            entity: "order",
            fields: ["id", "display_id", "total", "metadata"],
            filters: {
                id: data.id,
            },
        });
        if (!order)
            return;
        // Check if order has affiliate info in metadata
        // Assuming frontend sets metadata: { affiliate_link_id: "..." }
        const linkId = order.metadata?.affiliate_link_id;
        if (linkId) {
            // Try to find by ID first
            let links = await affiliateService.listAffiliateLinks({ id: linkId }, { relations: ["affiliate"] });
            // If not found, try to find by code
            if (links.length === 0) {
                links = await affiliateService.listAffiliateLinks({ code: linkId }, { relations: ["affiliate"] });
            }
            if (links.length > 0) {
                const link = links[0];
                // Use affiliate's specific commission rate or default to 10%
                const commissionRate = link.affiliate.commission_rate !== null && link.affiliate.commission_rate !== undefined
                    ? Number(link.affiliate.commission_rate)
                    : 0.1;
                const commissionAmount = Number(order.total) * commissionRate;
                await affiliateService.createAffiliateConversions({
                    affiliate_id: link.affiliate.id,
                    link_id: link.id,
                    order_id: order.id,
                    amount: order.total,
                    commission: commissionAmount,
                    status: "pending",
                    metadata: {
                        order_display_id: order.display_id
                    }
                });
                // Update affiliate stats
                await affiliateService.updateAffiliates({
                    id: link.affiliate.id,
                    total_earnings: Number(link.affiliate.total_earnings) + commissionAmount,
                    balance: Number(link.affiliate.balance) + commissionAmount
                });
                // Update link stats
                await affiliateService.updateAffiliateLinks({
                    id: link.id,
                    conversions: (link.conversions || 0) + 1
                });
                console.log(`✅ Affiliate commission recorded for order ${order.id}`);
            }
        }
    }
    catch (error) {
        console.error("❌ Error processing affiliate commission:", error);
    }
}
exports.config = {
    event: "order.placed",
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWZmaWxpYXRlLW9yZGVyLXBsYWNlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zdWJzY3JpYmVycy9hZmZpbGlhdGUtb3JkZXItcGxhY2VkLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUlBLHVDQXVFQztBQTFFRCxvREFBdUQ7QUFHeEMsS0FBSyxVQUFVLG9CQUFvQixDQUFDLEVBQ2pELEtBQUssRUFBRSxFQUFFLElBQUksRUFBRSxFQUNmLFNBQVMsR0FDc0I7SUFDL0IsTUFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQTtJQUN4QyxNQUFNLGdCQUFnQixHQUFxQixTQUFTLENBQUMsT0FBTyxDQUFDLDRCQUFnQixDQUFDLENBQUE7SUFFOUUsSUFBSSxDQUFDO1FBQ0gsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1lBQzFDLE1BQU0sRUFBRSxPQUFPO1lBQ2YsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLFlBQVksRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDO1lBQ2pELE9BQU8sRUFBRTtnQkFDUCxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7YUFDWjtTQUNGLENBQUMsQ0FBQTtRQUVGLElBQUksQ0FBQyxLQUFLO1lBQUUsT0FBTTtRQUVsQixnREFBZ0Q7UUFDaEQsZ0VBQWdFO1FBQ2hFLE1BQU0sTUFBTSxHQUFJLEtBQUssQ0FBQyxRQUFnQixFQUFFLGlCQUFpQixDQUFBO1FBRXpELElBQUksTUFBTSxFQUFFLENBQUM7WUFDWCwwQkFBMEI7WUFDMUIsSUFBSSxLQUFLLEdBQUcsTUFBTSxnQkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQTtZQUVuRyxvQ0FBb0M7WUFDcEMsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN2QixLQUFLLEdBQUcsTUFBTSxnQkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQTtZQUNuRyxDQUFDO1lBRUQsSUFBSSxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUNyQixNQUFNLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUE7Z0JBQ3JCLDZEQUE2RDtnQkFDN0QsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxLQUFLLFNBQVM7b0JBQzVHLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUM7b0JBQ3hDLENBQUMsQ0FBQyxHQUFHLENBQUE7Z0JBRVAsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLGNBQWMsQ0FBQTtnQkFFN0QsTUFBTSxnQkFBZ0IsQ0FBQywwQkFBMEIsQ0FBQztvQkFDaEQsWUFBWSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtvQkFDL0IsT0FBTyxFQUFFLElBQUksQ0FBQyxFQUFFO29CQUNoQixRQUFRLEVBQUUsS0FBSyxDQUFDLEVBQUU7b0JBQ2xCLE1BQU0sRUFBRSxLQUFLLENBQUMsS0FBSztvQkFDbkIsVUFBVSxFQUFFLGdCQUFnQjtvQkFDNUIsTUFBTSxFQUFFLFNBQVM7b0JBQ2pCLFFBQVEsRUFBRTt3QkFDUixnQkFBZ0IsRUFBRyxLQUFhLENBQUMsVUFBVTtxQkFDNUM7aUJBQ0YsQ0FBQyxDQUFBO2dCQUVGLHlCQUF5QjtnQkFDekIsTUFBTSxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQztvQkFDdEMsRUFBRSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtvQkFDckIsY0FBYyxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxHQUFHLGdCQUFnQjtvQkFDeEUsT0FBTyxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxHQUFHLGdCQUFnQjtpQkFDM0QsQ0FBQyxDQUFBO2dCQUVGLG9CQUFvQjtnQkFDcEIsTUFBTSxnQkFBZ0IsQ0FBQyxvQkFBb0IsQ0FBQztvQkFDMUMsRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFO29CQUNYLFdBQVcsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQztpQkFDekMsQ0FBQyxDQUFBO2dCQUVGLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkNBQTZDLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFBO1lBQ3RFLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDBDQUEwQyxFQUFFLEtBQUssQ0FBQyxDQUFBO0lBQ2xFLENBQUM7QUFDSCxDQUFDO0FBRVksUUFBQSxNQUFNLEdBQXFCO0lBQ3RDLEtBQUssRUFBRSxjQUFjO0NBQ3RCLENBQUEifQ==