"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = authEventLogger;
// 測試訂閱者：監聽所有認證相關事件
async function authEventLogger({ event, container }) {
    const logger = container.resolve('logger');
    // 記錄所有接收到的事件
    logger.info('🔍 EVENT RECEIVED:', {
        eventName: event.name,
        data: event.data,
        timestamp: new Date().toISOString()
    });
    // 如果是認證相關事件，提供更詳細的日誌
    if (event.name.includes('auth') || event.name.includes('identity') || event.name.includes('google')) {
        logger.info('🎯 AUTH EVENT DETAILS:', JSON.stringify(event, null, 2));
    }
}
exports.config = {
    event: [
        // 嘗試所有可能的事件名稱
        'provider_identity.created',
        'auth_identity.created',
        'auth.identity.created',
        'auth.provider_identity.created',
        'medusa.auth.identity.created',
        'medusa.auth.provider_identity.created',
        'customer.created',
        'user.created',
        // 監聽所有事件（萬用字符）
        '*'
    ]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0aC1ldmVudC1sb2dnZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvc3Vic2NyaWJlcnMvYXV0aC1ldmVudC1sb2dnZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBR0Esa0NBaUJDO0FBbEJELG1CQUFtQjtBQUNKLEtBQUssVUFBVSxlQUFlLENBQUMsRUFDNUMsS0FBSyxFQUNMLFNBQVMsRUFDVztJQUNwQixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBUSxDQUFBO0lBRWpELGFBQWE7SUFDYixNQUFNLENBQUMsSUFBSSxDQUFDLG9CQUFvQixFQUFFO1FBQ2hDLFNBQVMsRUFBRSxLQUFLLENBQUMsSUFBSTtRQUNyQixJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7UUFDaEIsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO0tBQ3BDLENBQUMsQ0FBQTtJQUVGLHFCQUFxQjtJQUNyQixJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7UUFDcEcsTUFBTSxDQUFDLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUN2RSxDQUFDO0FBQ0gsQ0FBQztBQUVZLFFBQUEsTUFBTSxHQUFxQjtJQUN0QyxLQUFLLEVBQUU7UUFDTCxjQUFjO1FBQ2QsMkJBQTJCO1FBQzNCLHVCQUF1QjtRQUN2Qix1QkFBdUI7UUFDdkIsZ0NBQWdDO1FBQ2hDLDhCQUE4QjtRQUM5Qix1Q0FBdUM7UUFDdkMsa0JBQWtCO1FBQ2xCLGNBQWM7UUFDZCxlQUFlO1FBQ2YsR0FBRztLQUNKO0NBQ0YsQ0FBQSJ9