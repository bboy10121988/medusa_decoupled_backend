"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = testEventHandler;
/**
 * 測試訂閱者 - 監聽任何事件
 */
async function testEventHandler({ event, }) {
    console.log(`🧪 測試訂閱者收到事件:`, event.name);
    console.log(`📧 事件數據:`, JSON.stringify(event.data, null, 2));
}
exports.config = {
    event: "*", // 監聽所有事件
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVzdC1ldmVudHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvc3Vic2NyaWJlcnMvdGVzdC1ldmVudHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBUUEsbUNBS0M7QUFSRDs7R0FFRztBQUNZLEtBQUssVUFBVSxnQkFBZ0IsQ0FBQyxFQUM3QyxLQUFLLEdBQ2U7SUFDcEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFBO0lBQ3hDLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUM5RCxDQUFDO0FBRVksUUFBQSxNQUFNLEdBQXFCO0lBQ3RDLEtBQUssRUFBRSxHQUFHLEVBQUUsU0FBUztDQUN0QixDQUFBIn0=