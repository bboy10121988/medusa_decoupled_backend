import{j as e}from"./index-BvrsWkgf.js";var s=()=>e.jsx("div",{className:"flex h-full w-full items-center",children:e.jsx("span",{className:"text-ui-fg-muted",children:"-"})});export{s as P};
