"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = adminOrderNotificationHandler;
const utils_1 = require("@medusajs/framework/utils");
/**
 * 管理員訂單通知訂閱者
 * 當有新訂單時發送通知給管理員
 *
 * ⚠️ 非同步執行，不阻塞訂單創建流程
 */
async function adminOrderNotificationHandler({ event: { data }, container, }) {
    // 🚀 使用 setImmediate 讓郵件發送在下一個事件循環執行，不阻塞訂單創建
    setImmediate(async () => {
        const notificationModuleService = container.resolve(utils_1.Modules.NOTIFICATION);
        const query = container.resolve("query");
        try {
            // 查詢訂單詳細資訊
            const { data: [order] } = await query.graph({
                entity: "order",
                fields: [
                    "*",
                    "customer.*",
                    "items.*",
                    "items.product.*",
                    "shipping_address.*",
                    "billing_address.*"
                ],
                filters: {
                    id: data.id,
                },
            });
            if (!order) {
                console.error(`Order with ID ${data.id} not found`);
                return;
            }
            // 管理員郵件地址
            const adminEmail = process.env.ADMIN_EMAIL || 'timsfantasyworld@gmail.com';
            console.log(`📧 發送新訂單通知給管理員: ${order.id}`);
            // 計算訂單總金額
            const totalAmount = order.total || 0;
            const currency = order.currency_code?.toUpperCase() || 'TWD';
            // 格式化商品列表
            const items = order.items?.filter(item => item !== null).map(item => ({
                title: item.product?.title || item.title || '未知商品',
                quantity: item.quantity || 0,
                unit_price: item.unit_price || 0,
                total: (item.unit_price || 0) * (item.quantity || 0)
            })) || [];
            // 優先使用 Resend 發送
            const resendApiKey = process.env.RESEND_API_KEY;
            if (resendApiKey) {
                console.log(`📧 使用 Resend API 發送管理員訂單通知`);
                const { Resend } = await import("resend");
                const resend = new Resend(resendApiKey);
                const fromEmail = process.env.RESEND_FROM_EMAIL || "onboarding@resend.dev";
                const htmlContent = generateAdminNotificationTemplate({
                    order_id: order.id,
                    order_date: new Date().toLocaleDateString('zh-TW'),
                    customer_name: `${order.customer?.first_name || ''} ${order.customer?.last_name || ''}`.trim() || order.customer?.email || '匿名客戶',
                    customer_email: order.customer?.email || '無',
                    total_amount: totalAmount,
                    currency: currency,
                    items: items,
                    items_count: items.length,
                    shipping_address: order.shipping_address ? {
                        full_name: `${order.shipping_address.first_name || ''} ${order.shipping_address.last_name || ''}`.trim(),
                        company: order.shipping_address.company,
                        address_1: order.shipping_address.address_1,
                        address_2: order.shipping_address.address_2,
                        city: order.shipping_address.city,
                        country_code: order.shipping_address.country_code,
                        postal_code: order.shipping_address.postal_code,
                    } : null,
                    admin_url: `${process.env.BACKEND_URL || 'https://admin.timsfantasyworld.com'}/admin/orders/${order.id}`,
                });
                const result = await resend.emails.send({
                    from: fromEmail,
                    to: adminEmail,
                    subject: `[新訂單] #${order.id} - ${currency} ${totalAmount}`,
                    html: htmlContent,
                });
                if (result.error) {
                    console.error("❌ Resend 發送失敗:", result.error);
                    throw result.error;
                }
                console.log(`✅ Resend 管理員通知發送成功: ${result.data?.id}`);
            }
            else {
                console.log(`⚠️ 未設定 RESEND_API_KEY，使用 Notification Module (Local)`);
                // 發送管理員通知
                await notificationModuleService.createNotifications({
                    to: adminEmail,
                    channel: "email",
                    template: "admin-new-order",
                    data: {
                        order_id: order.id,
                        order_date: new Date().toLocaleDateString('zh-TW'),
                        customer_name: `${order.customer?.first_name || ''} ${order.customer?.last_name || ''}`.trim() || order.customer?.email || '匿名客戶',
                        customer_email: order.customer?.email || '無',
                        total_amount: totalAmount,
                        currency: currency,
                        items: items,
                        items_count: items.length,
                        shipping_address: order.shipping_address ? {
                            full_name: `${order.shipping_address.first_name || ''} ${order.shipping_address.last_name || ''}`.trim(),
                            company: order.shipping_address.company,
                            address_1: order.shipping_address.address_1,
                            address_2: order.shipping_address.address_2,
                            city: order.shipping_address.city,
                            country_code: order.shipping_address.country_code,
                            postal_code: order.shipping_address.postal_code,
                        } : null,
                        admin_url: `${process.env.BACKEND_URL || 'https://admin.timsfantasyworld.com'}/admin/orders/${order.id}`,
                    },
                });
                console.log(`✅ 管理員訂單通知已發送至 ${adminEmail}`);
            }
        }
        catch (error) {
            console.error("❌ 發送管理員訂單通知失敗:", error);
        }
    });
    // 立即返回，不等待郵件發送完成
}
exports.config = {
    event: "order.placed",
};
function generateAdminNotificationTemplate(data) {
    const itemsList = data.items?.map((item) => `<li>${item.title} x ${item.quantity} - $${(item.total / 100).toFixed(2)}</li>`).join('') || '<li>無商品資訊</li>';
    const address2Line = data.shipping_address?.address_2 ? `<p>${data.shipping_address.address_2}</p>` : '';
    const shippingSection = data.shipping_address ? `
    <div style="margin: 20px 0;">
      <h3>收件地址</h3>
      <p>${data.shipping_address.full_name}</p>
      <p>${data.shipping_address.address_1}</p>
      ${address2Line}
      <p>${data.shipping_address.city}, ${data.shipping_address.postal_code}</p>
    </div>
  ` : '';
    return `
    <html>
      <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #d32f2f;">[新訂單通知] Tim's Fantasy World</h2>
        
        <div style="background-color: #fff3e0; padding: 20px; margin: 20px 0; border-radius: 8px; border-left: 5px solid #ff9800;">
          <h3 style="margin: 0 0 10px 0;">訂單摘要</h3>
          <p><strong>訂單編號：</strong> ${data.order_id}</p>
          <p><strong>訂單日期：</strong> ${data.order_date}</p>
          <p><strong>客戶名稱：</strong> ${data.customer_name}</p>
          <p><strong>訂單總額：</strong> ${data.currency} $${(data.total_amount / 100).toFixed(2)}</p>
        </div>
        
        <div style="margin: 20px 0;">
          <h3>商品清單 (${data.items_count} 項)</h3>
          <ul>${itemsList}</ul>
        </div>
        
        ${shippingSection}
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${data.admin_url}" 
             style="background-color: #d32f2f; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">
            前往後台查看訂單
          </a>
        </div>
        
        <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
        <p style="color: #999; font-size: 12px;">
          此為系統自動發送的內部通知，請勿回覆。
        </p>
      </body>
    </html>
  `;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWRtaW4tb3JkZXItbm90aWZpY2F0aW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3N1YnNjcmliZXJzL2FkbWluLW9yZGVyLW5vdGlmaWNhdGlvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFZQSxnREE4SEM7QUF0SUQscURBQW1EO0FBRW5EOzs7OztHQUtHO0FBQ1ksS0FBSyxVQUFVLDZCQUE2QixDQUFDLEVBQzFELEtBQUssRUFBRSxFQUFFLElBQUksRUFBRSxFQUNmLFNBQVMsR0FDc0I7SUFDL0IsNkNBQTZDO0lBQzdDLFlBQVksQ0FBQyxLQUFLLElBQUksRUFBRTtRQUN0QixNQUFNLHlCQUF5QixHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLFlBQVksQ0FBQyxDQUFBO1FBQ3pFLE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUE7UUFFeEMsSUFBSSxDQUFDO1lBQ0gsV0FBVztZQUNYLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDMUMsTUFBTSxFQUFFLE9BQU87Z0JBQ2YsTUFBTSxFQUFFO29CQUNOLEdBQUc7b0JBQ0gsWUFBWTtvQkFDWixTQUFTO29CQUNULGlCQUFpQjtvQkFDakIsb0JBQW9CO29CQUNwQixtQkFBbUI7aUJBQ3BCO2dCQUNELE9BQU8sRUFBRTtvQkFDUCxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7aUJBQ1o7YUFDRixDQUFDLENBQUE7WUFFRixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQ1gsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsSUFBSSxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUE7Z0JBQ25ELE9BQU07WUFDUixDQUFDO1lBRUQsVUFBVTtZQUNWLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxJQUFJLDRCQUE0QixDQUFBO1lBRTFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFBO1lBRTFDLFVBQVU7WUFDVixNQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQTtZQUNwQyxNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsYUFBYSxFQUFFLFdBQVcsRUFBRSxJQUFJLEtBQUssQ0FBQTtZQUU1RCxVQUFVO1lBQ1YsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDcEUsS0FBSyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksTUFBTTtnQkFDbEQsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQztnQkFDNUIsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQztnQkFDaEMsS0FBSyxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxDQUFDO2FBQ3JELENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtZQUVULGlCQUFpQjtZQUNqQixNQUFNLFlBQVksR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQTtZQUMvQyxJQUFJLFlBQVksRUFBRSxDQUFDO2dCQUNqQixPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixDQUFDLENBQUE7Z0JBQ3pDLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQTtnQkFDekMsTUFBTSxNQUFNLEdBQUcsSUFBSSxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUE7Z0JBQ3ZDLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLElBQUksdUJBQXVCLENBQUE7Z0JBRTFFLE1BQU0sV0FBVyxHQUFHLGlDQUFpQyxDQUFDO29CQUNwRCxRQUFRLEVBQUUsS0FBSyxDQUFDLEVBQUU7b0JBQ2xCLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQztvQkFDbEQsYUFBYSxFQUFFLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBRSxVQUFVLElBQUksRUFBRSxJQUFJLEtBQUssQ0FBQyxRQUFRLEVBQUUsU0FBUyxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksRUFBRSxJQUFJLEtBQUssQ0FBQyxRQUFRLEVBQUUsS0FBSyxJQUFJLE1BQU07b0JBQ2pJLGNBQWMsRUFBRSxLQUFLLENBQUMsUUFBUSxFQUFFLEtBQUssSUFBSSxHQUFHO29CQUM1QyxZQUFZLEVBQUUsV0FBVztvQkFDekIsUUFBUSxFQUFFLFFBQVE7b0JBQ2xCLEtBQUssRUFBRSxLQUFLO29CQUNaLFdBQVcsRUFBRSxLQUFLLENBQUMsTUFBTTtvQkFDekIsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQzt3QkFDekMsU0FBUyxFQUFFLEdBQUcsS0FBSyxDQUFDLGdCQUFnQixDQUFDLFVBQVUsSUFBSSxFQUFFLElBQUksS0FBSyxDQUFDLGdCQUFnQixDQUFDLFNBQVMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEVBQUU7d0JBQ3hHLE9BQU8sRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsT0FBTzt3QkFDdkMsU0FBUyxFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTO3dCQUMzQyxTQUFTLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLFNBQVM7d0JBQzNDLElBQUksRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsSUFBSTt3QkFDakMsWUFBWSxFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZO3dCQUNqRCxXQUFXLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLFdBQVc7cUJBQ2hELENBQUMsQ0FBQyxDQUFDLElBQUk7b0JBQ1IsU0FBUyxFQUFFLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLElBQUksb0NBQW9DLGlCQUFpQixLQUFLLENBQUMsRUFBRSxFQUFFO2lCQUN6RyxDQUFDLENBQUE7Z0JBRUYsTUFBTSxNQUFNLEdBQUcsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztvQkFDdEMsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsRUFBRSxFQUFFLFVBQVU7b0JBQ2QsT0FBTyxFQUFFLFVBQVUsS0FBSyxDQUFDLEVBQUUsTUFBTSxRQUFRLElBQUksV0FBVyxFQUFFO29CQUMxRCxJQUFJLEVBQUUsV0FBVztpQkFDbEIsQ0FBQyxDQUFBO2dCQUVGLElBQUksTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUNqQixPQUFPLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQTtvQkFDN0MsTUFBTSxNQUFNLENBQUMsS0FBSyxDQUFBO2dCQUNwQixDQUFDO2dCQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLE1BQU0sQ0FBQyxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQTtZQUN2RCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sT0FBTyxDQUFDLEdBQUcsQ0FBQyxzREFBc0QsQ0FBQyxDQUFBO2dCQUNuRSxVQUFVO2dCQUNWLE1BQU0seUJBQXlCLENBQUMsbUJBQW1CLENBQUM7b0JBQ2xELEVBQUUsRUFBRSxVQUFVO29CQUNkLE9BQU8sRUFBRSxPQUFPO29CQUNoQixRQUFRLEVBQUUsaUJBQWlCO29CQUMzQixJQUFJLEVBQUU7d0JBQ0osUUFBUSxFQUFFLEtBQUssQ0FBQyxFQUFFO3dCQUNsQixVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUM7d0JBQ2xELGFBQWEsRUFBRSxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQUUsVUFBVSxJQUFJLEVBQUUsSUFBSSxLQUFLLENBQUMsUUFBUSxFQUFFLFNBQVMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxLQUFLLENBQUMsUUFBUSxFQUFFLEtBQUssSUFBSSxNQUFNO3dCQUNqSSxjQUFjLEVBQUUsS0FBSyxDQUFDLFFBQVEsRUFBRSxLQUFLLElBQUksR0FBRzt3QkFDNUMsWUFBWSxFQUFFLFdBQVc7d0JBQ3pCLFFBQVEsRUFBRSxRQUFRO3dCQUNsQixLQUFLLEVBQUUsS0FBSzt3QkFDWixXQUFXLEVBQUUsS0FBSyxDQUFDLE1BQU07d0JBQ3pCLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7NEJBQ3pDLFNBQVMsRUFBRSxHQUFHLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLElBQUksRUFBRSxJQUFJLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxFQUFFOzRCQUN4RyxPQUFPLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLE9BQU87NEJBQ3ZDLFNBQVMsRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsU0FBUzs0QkFDM0MsU0FBUyxFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTOzRCQUMzQyxJQUFJLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLElBQUk7NEJBQ2pDLFlBQVksRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsWUFBWTs0QkFDakQsV0FBVyxFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXO3lCQUNoRCxDQUFDLENBQUMsQ0FBQyxJQUFJO3dCQUNSLFNBQVMsRUFBRSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxJQUFJLG9DQUFvQyxpQkFBaUIsS0FBSyxDQUFDLEVBQUUsRUFBRTtxQkFDekc7aUJBQ0YsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLFVBQVUsRUFBRSxDQUFDLENBQUE7WUFDNUMsQ0FBQztRQUNILENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUN4QyxDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUE7SUFFRixpQkFBaUI7QUFDbkIsQ0FBQztBQUVZLFFBQUEsTUFBTSxHQUFxQjtJQUN0QyxLQUFLLEVBQUUsY0FBYztDQUN0QixDQUFBO0FBRUQsU0FBUyxpQ0FBaUMsQ0FBQyxJQUFTO0lBQ2xELE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUMsSUFBUyxFQUFFLEVBQUUsQ0FDOUMsT0FBTyxJQUFJLENBQUMsS0FBSyxNQUFNLElBQUksQ0FBQyxRQUFRLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUNoRixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxnQkFBZ0IsQ0FBQTtJQUU5QixNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO0lBQ3hHLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7OztXQUd2QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUztXQUMvQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUztRQUNsQyxZQUFZO1dBQ1QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVzs7R0FFeEUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO0lBRU4sT0FBTzs7Ozs7OztzQ0FPNkIsSUFBSSxDQUFDLFFBQVE7c0NBQ2IsSUFBSSxDQUFDLFVBQVU7c0NBQ2YsSUFBSSxDQUFDLGFBQWE7c0NBQ2xCLElBQUksQ0FBQyxRQUFRLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxHQUFHLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Ozs7c0JBSXRFLElBQUksQ0FBQyxXQUFXO2dCQUN0QixTQUFTOzs7VUFHZixlQUFlOzs7cUJBR0osSUFBSSxDQUFDLFNBQVM7Ozs7Ozs7Ozs7OztHQVloQyxDQUFBO0FBQ0gsQ0FBQyJ9