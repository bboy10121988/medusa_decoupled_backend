"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
// GET /affiliate/check - 檢查聯盟夥伴狀態
async function GET(req, res) {
    try {
        const { token } = req.query;
        if (!token) {
            res.status(400).json({
                error: "Missing token",
                message: "Affiliate token is required"
            });
            return;
        }
        // 這裡應該驗證token並獲取聯盟夥伴資訊
        // 暫時返回模擬資料
        const affiliate = {
            id: "aff_partner_1",
            name: "測試聯盟夥伴",
            email: "partner@example.com",
            commission_rate: 0.05,
            status: "active",
            total_earnings: 1250.00,
            pending_earnings: 350.00
        };
        res.json({
            affiliate,
            is_valid: true
        });
    }
    catch (error) {
        res.status(500).json({
            error: "Internal server error",
            message: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FmZmlsaWF0ZS9jaGVjay9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU1BLGtCQXFDQztBQXRDRCxrQ0FBa0M7QUFDM0IsS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsSUFBSSxDQUFDO1FBQ0gsTUFBTSxFQUFFLEtBQUssRUFBRSxHQUFHLEdBQUcsQ0FBQyxLQUEyQixDQUFBO1FBRWpELElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNYLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNuQixLQUFLLEVBQUUsZUFBZTtnQkFDdEIsT0FBTyxFQUFFLDZCQUE2QjthQUN2QyxDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1IsQ0FBQztRQUVELHVCQUF1QjtRQUN2QixXQUFXO1FBQ1gsTUFBTSxTQUFTLEdBQUc7WUFDaEIsRUFBRSxFQUFFLGVBQWU7WUFDbkIsSUFBSSxFQUFFLFFBQVE7WUFDZCxLQUFLLEVBQUUscUJBQXFCO1lBQzVCLGVBQWUsRUFBRSxJQUFJO1lBQ3JCLE1BQU0sRUFBRSxRQUFRO1lBQ2hCLGNBQWMsRUFBRSxPQUFPO1lBQ3ZCLGdCQUFnQixFQUFFLE1BQU07U0FDekIsQ0FBQTtRQUVELEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxTQUFTO1lBQ1QsUUFBUSxFQUFFLElBQUk7U0FDZixDQUFDLENBQUE7SUFDSixDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUUsdUJBQXVCO1lBQzlCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztTQUN2QixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9