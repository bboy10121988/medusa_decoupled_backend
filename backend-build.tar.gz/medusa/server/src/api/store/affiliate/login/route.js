"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
// POST /store/affiliate/login - 聯盟夥伴登入
async function POST(req, res) {
    try {
        const body = req.body;
        const { email, password } = body;
        if (!email || !password) {
            res.status(400).json({
                error: "Missing credentials",
                message: "Email and password are required"
            });
            return;
        }
        // 這裡應該驗證聯盟夥伴登入資訊
        // 暫時返回模擬成功響應
        const affiliatePartner = {
            id: "aff_partner_1",
            email,
            name: "測試聯盟夥伴",
            commission_rate: 0.05, // 5%
            status: "active"
        };
        res.json({
            partner: affiliatePartner,
            token: `aff_token_${Date.now()}`,
            message: "Login successful"
        });
    }
    catch (error) {
        res.status(500).json({
            error: "Internal server error",
            message: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2FmZmlsaWF0ZS9sb2dpbi9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU1BLG9CQXFDQztBQXRDRCx1Q0FBdUM7QUFDaEMsS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsSUFBSSxDQUFDO1FBQ0gsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLElBQTZDLENBQUE7UUFDOUQsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsR0FBRyxJQUFJLENBQUE7UUFFaEMsSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3hCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNuQixLQUFLLEVBQUUscUJBQXFCO2dCQUM1QixPQUFPLEVBQUUsaUNBQWlDO2FBQzNDLENBQUMsQ0FBQTtZQUNGLE9BQU07UUFDUixDQUFDO1FBRUQsaUJBQWlCO1FBQ2pCLGFBQWE7UUFDYixNQUFNLGdCQUFnQixHQUFHO1lBQ3ZCLEVBQUUsRUFBRSxlQUFlO1lBQ25CLEtBQUs7WUFDTCxJQUFJLEVBQUUsUUFBUTtZQUNkLGVBQWUsRUFBRSxJQUFJLEVBQUUsS0FBSztZQUM1QixNQUFNLEVBQUUsUUFBUTtTQUNqQixDQUFBO1FBRUQsR0FBRyxDQUFDLElBQUksQ0FBQztZQUNQLE9BQU8sRUFBRSxnQkFBZ0I7WUFDekIsS0FBSyxFQUFFLGFBQWEsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO1lBQ2hDLE9BQU8sRUFBRSxrQkFBa0I7U0FDNUIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFLHVCQUF1QjtZQUM5QixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDdkIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==