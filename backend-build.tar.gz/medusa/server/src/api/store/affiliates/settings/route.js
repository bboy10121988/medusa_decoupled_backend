"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.PUT = PUT;
const affiliate_1 = require("../../../../modules/affiliate");
const affiliate_auth_1 = require("../../../../utils/affiliate-auth");
async function GET(req, res) {
    const affiliateAuth = (0, affiliate_auth_1.getAffiliateFromRequest)(req);
    if (!affiliateAuth) {
        return res.status(401).json({ message: "Unauthorized" });
    }
    const affiliateService = req.scope.resolve(affiliate_1.AFFILIATE_MODULE);
    const affiliate = await affiliateService.retrieveAffiliate(affiliateAuth.id);
    const currentSettings = affiliate.settings || {};
    // Map to frontend expected format with default values
    const settings = {
        displayName: affiliate.first_name ? `${affiliate.first_name} ${affiliate.last_name || ''}`.trim() : affiliate.email,
        website: affiliate.metadata?.website || '',
        payoutMethod: currentSettings.payoutMethod || 'bank_transfer',
        paypalEmail: currentSettings.paypalEmail || '',
        bankAccount: {
            bankName: currentSettings.bankAccount?.bankName || '',
            accountName: currentSettings.bankAccount?.accountName || '',
            accountNumber: currentSettings.bankAccount?.accountNumber || '',
            branch: currentSettings.bankAccount?.branch || ''
        },
        notifications: {
            emailOnNewOrder: currentSettings.notifications?.emailOnNewOrder ?? true,
            emailOnPayment: currentSettings.notifications?.emailOnPayment ?? true,
            emailOnCommissionUpdate: currentSettings.notifications?.emailOnCommissionUpdate ?? false
        },
        profile: {
            company: currentSettings.profile?.company || '',
            phone: currentSettings.profile?.phone || '',
            address: currentSettings.profile?.address || '',
            taxId: currentSettings.profile?.taxId || ''
        },
        ...currentSettings
    };
    res.json(settings);
}
async function PUT(req, res) {
    const affiliateAuth = (0, affiliate_auth_1.getAffiliateFromRequest)(req);
    if (!affiliateAuth) {
        return res.status(401).json({ message: "Unauthorized" });
    }
    const affiliateService = req.scope.resolve(affiliate_1.AFFILIATE_MODULE);
    const updates = req.body;
    // Separate standard fields from settings JSON
    const standardUpdates = {};
    if (updates.displayName) {
        const parts = updates.displayName.split(' ');
        standardUpdates.first_name = parts[0];
        standardUpdates.last_name = parts.slice(1).join(' ');
    }
    const currentAffiliate = await affiliateService.retrieveAffiliate(affiliateAuth.id);
    const currentSettings = currentAffiliate.settings || {};
    const currentMetadata = currentAffiliate.metadata || {};
    if (updates.website) {
        currentMetadata.website = updates.website;
    }
    // Merge settings
    const newSettings = {
        ...currentSettings,
        ...updates,
        // Remove fields that are stored elsewhere or shouldn't be in settings
        displayName: undefined,
        website: undefined
    };
    await affiliateService.updateAffiliates({
        id: affiliateAuth.id,
        ...standardUpdates,
        settings: newSettings,
        metadata: currentMetadata
    });
    res.json({ success: true });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2FmZmlsaWF0ZXMvc2V0dGluZ3Mvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFLQSxrQkF5Q0M7QUFFRCxrQkE2Q0M7QUE1RkQsNkRBQWdFO0FBRWhFLHFFQUEwRTtBQUVuRSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLGFBQWEsR0FBRyxJQUFBLHdDQUF1QixFQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQ2xELElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNuQixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLGNBQWMsRUFBRSxDQUFDLENBQUE7SUFDMUQsQ0FBQztJQUVELE1BQU0sZ0JBQWdCLEdBQXFCLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLDRCQUFnQixDQUFDLENBQUE7SUFDOUUsTUFBTSxTQUFTLEdBQUcsTUFBTSxnQkFBZ0IsQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUE7SUFFNUUsTUFBTSxlQUFlLEdBQUksU0FBUyxDQUFDLFFBQWdCLElBQUksRUFBRSxDQUFBO0lBRXpELHNEQUFzRDtJQUN0RCxNQUFNLFFBQVEsR0FBRztRQUNmLFdBQVcsRUFBRSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxVQUFVLElBQUksU0FBUyxDQUFDLFNBQVMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUs7UUFDbkgsT0FBTyxFQUFHLFNBQVMsQ0FBQyxRQUFnQixFQUFFLE9BQU8sSUFBSSxFQUFFO1FBQ25ELFlBQVksRUFBRSxlQUFlLENBQUMsWUFBWSxJQUFJLGVBQWU7UUFDN0QsV0FBVyxFQUFFLGVBQWUsQ0FBQyxXQUFXLElBQUksRUFBRTtRQUM5QyxXQUFXLEVBQUU7WUFDWCxRQUFRLEVBQUUsZUFBZSxDQUFDLFdBQVcsRUFBRSxRQUFRLElBQUksRUFBRTtZQUNyRCxXQUFXLEVBQUUsZUFBZSxDQUFDLFdBQVcsRUFBRSxXQUFXLElBQUksRUFBRTtZQUMzRCxhQUFhLEVBQUUsZUFBZSxDQUFDLFdBQVcsRUFBRSxhQUFhLElBQUksRUFBRTtZQUMvRCxNQUFNLEVBQUUsZUFBZSxDQUFDLFdBQVcsRUFBRSxNQUFNLElBQUksRUFBRTtTQUNsRDtRQUNELGFBQWEsRUFBRTtZQUNiLGVBQWUsRUFBRSxlQUFlLENBQUMsYUFBYSxFQUFFLGVBQWUsSUFBSSxJQUFJO1lBQ3ZFLGNBQWMsRUFBRSxlQUFlLENBQUMsYUFBYSxFQUFFLGNBQWMsSUFBSSxJQUFJO1lBQ3JFLHVCQUF1QixFQUFFLGVBQWUsQ0FBQyxhQUFhLEVBQUUsdUJBQXVCLElBQUksS0FBSztTQUN6RjtRQUNELE9BQU8sRUFBRTtZQUNQLE9BQU8sRUFBRSxlQUFlLENBQUMsT0FBTyxFQUFFLE9BQU8sSUFBSSxFQUFFO1lBQy9DLEtBQUssRUFBRSxlQUFlLENBQUMsT0FBTyxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQzNDLE9BQU8sRUFBRSxlQUFlLENBQUMsT0FBTyxFQUFFLE9BQU8sSUFBSSxFQUFFO1lBQy9DLEtBQUssRUFBRSxlQUFlLENBQUMsT0FBTyxFQUFFLEtBQUssSUFBSSxFQUFFO1NBQzVDO1FBQ0QsR0FBRyxlQUFlO0tBQ25CLENBQUE7SUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQ3BCLENBQUM7QUFFTSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLGFBQWEsR0FBRyxJQUFBLHdDQUF1QixFQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQ2xELElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNuQixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLGNBQWMsRUFBRSxDQUFDLENBQUE7SUFDMUQsQ0FBQztJQUVELE1BQU0sZ0JBQWdCLEdBQXFCLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLDRCQUFnQixDQUFDLENBQUE7SUFDOUUsTUFBTSxPQUFPLEdBQUcsR0FBRyxDQUFDLElBQVcsQ0FBQTtJQUUvQiw4Q0FBOEM7SUFDOUMsTUFBTSxlQUFlLEdBQVEsRUFBRSxDQUFBO0lBQy9CLElBQUksT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3hCLE1BQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFBO1FBQzVDLGVBQWUsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ3JDLGVBQWUsQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7SUFDdEQsQ0FBQztJQUVELE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxnQkFBZ0IsQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUE7SUFDbkYsTUFBTSxlQUFlLEdBQUksZ0JBQWdCLENBQUMsUUFBZ0IsSUFBSSxFQUFFLENBQUE7SUFDaEUsTUFBTSxlQUFlLEdBQUksZ0JBQWdCLENBQUMsUUFBZ0IsSUFBSSxFQUFFLENBQUE7SUFFaEUsSUFBSSxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDcEIsZUFBZSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFBO0lBQzNDLENBQUM7SUFFRCxpQkFBaUI7SUFDakIsTUFBTSxXQUFXLEdBQUc7UUFDbEIsR0FBRyxlQUFlO1FBQ2xCLEdBQUcsT0FBTztRQUNWLHNFQUFzRTtRQUN0RSxXQUFXLEVBQUUsU0FBUztRQUN0QixPQUFPLEVBQUUsU0FBUztLQUNuQixDQUFBO0lBRUQsTUFBTSxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQztRQUN0QyxFQUFFLEVBQUUsYUFBYSxDQUFDLEVBQUU7UUFDcEIsR0FBRyxlQUFlO1FBQ2xCLFFBQVEsRUFBRSxXQUFXO1FBQ3JCLFFBQVEsRUFBRSxlQUFlO0tBQzFCLENBQUMsQ0FBQTtJQUVGLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtBQUM3QixDQUFDIn0=