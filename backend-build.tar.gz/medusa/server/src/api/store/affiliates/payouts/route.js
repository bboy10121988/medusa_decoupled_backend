"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const affiliate_1 = require("../../../../modules/affiliate");
const affiliate_auth_1 = require("../../../../utils/affiliate-auth");
async function GET(req, res) {
    const affiliateAuth = (0, affiliate_auth_1.getAffiliateFromRequest)(req);
    if (!affiliateAuth) {
        return res.status(401).json({ message: "Unauthorized" });
    }
    const affiliateService = req.scope.resolve(affiliate_1.AFFILIATE_MODULE);
    const settlements = await affiliateService.listAffiliateSettlements({
        affiliate_id: affiliateAuth.id
    });
    const affiliate = await affiliateService.retrieveAffiliate(affiliateAuth.id);
    const summary = {
        totalEarned: affiliate.total_earnings,
        totalSettled: settlements.filter(s => s.status === 'paid').reduce((sum, s) => sum + (Number(s.amount) || 0), 0),
        pendingSettlement: affiliate.balance,
        nextSettlementDate: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 25).toISOString() // Simplified
    };
    res.json({
        summary,
        settlements
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2FmZmlsaWF0ZXMvcGF5b3V0cy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUtBLGtCQTRCQztBQWhDRCw2REFBZ0U7QUFFaEUscUVBQTBFO0FBRW5FLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sYUFBYSxHQUFHLElBQUEsd0NBQXVCLEVBQUMsR0FBRyxDQUFDLENBQUE7SUFDbEQsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ25CLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsY0FBYyxFQUFFLENBQUMsQ0FBQTtJQUMxRCxDQUFDO0lBRUQsTUFBTSxnQkFBZ0IsR0FBcUIsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsNEJBQWdCLENBQUMsQ0FBQTtJQUU5RSxNQUFNLFdBQVcsR0FBRyxNQUFNLGdCQUFnQixDQUFDLHdCQUF3QixDQUFDO1FBQ2xFLFlBQVksRUFBRSxhQUFhLENBQUMsRUFBRTtLQUMvQixDQUFDLENBQUE7SUFFRixNQUFNLFNBQVMsR0FBRyxNQUFNLGdCQUFnQixDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUU1RSxNQUFNLE9BQU8sR0FBRztRQUNkLFdBQVcsRUFBRSxTQUFTLENBQUMsY0FBYztRQUNyQyxZQUFZLEVBQUUsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLEtBQUssTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDL0csaUJBQWlCLEVBQUUsU0FBUyxDQUFDLE9BQU87UUFDcEMsa0JBQWtCLEVBQUUsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxhQUFhO0tBQ2xILENBQUE7SUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsT0FBTztRQUNQLFdBQVc7S0FDWixDQUFDLENBQUE7QUFDSixDQUFDIn0=