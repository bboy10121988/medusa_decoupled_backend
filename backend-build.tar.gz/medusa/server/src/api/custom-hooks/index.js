"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ecpayCallBack = void 0;
var ecpay_callback_1 = require("./ecpay-callback");
Object.defineProperty(exports, "ecpayCallBack", { enumerable: true, get: function () { return ecpay_callback_1.ecpayCallBack; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2N1c3RvbS1ob29rcy9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxtREFBZ0Q7QUFBdkMsK0dBQUEsYUFBYSxPQUFBIn0=