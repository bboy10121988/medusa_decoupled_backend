"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// src/api/middlewares.ts
const http_1 = require("@medusajs/framework/http");
const customHooks = __importStar(require("./custom-hooks"));
const express_1 = __importDefault(require("express"));
const path_1 = __importDefault(require("path"));
const originalErrorHandler = (0, http_1.errorHandler)();
exports.default = (0, http_1.defineMiddlewares)({
    errorHandler: (error, req, res, next) => {
        console.log("middleware catched error:", error);
        console.log("error path:", req.path);
        // order退款錯誤：
        // 攔截 Admin API 的退款請求
        // Admin API 路徑通常是 /admin/payments/{id}/refund
        // const adminPaymentRefundPattern = /^\/admin\/payments\/pay_[A-Z0-9]{26}\/refund$/
        if (req.path.match(/^\/admin\/payments\/pay_[A-Z0-9]{26}\/refund$/)) {
            console.log("捕捉到退款路由的錯誤處理：", error);
            switch (error.message) {
                case "信用卡退款查詢無法取得訂單狀態":
                    console.log("信用卡退款查詢無法取得訂單狀態");
                    res.status(500).json({
                        code: "'api_error'",
                        type: "not_found",
                        error: "退款處理失敗",
                        message: "退款處理失敗，根據綠界文件：請過30分鐘後再試",
                    });
                    return;
                case "Order does not have an outstanding balance to refund":
                    console.log("訂單未執行完畢");
                    res.status(500).json({
                        code: "'api_error'",
                        type: "not_found",
                        error: "訂單未執行完畢",
                        message: "訂單未執行完畢，無法退款：請先執行退貨或是取消訂單才能進行退款",
                    });
                    return;
            }
            // if (error.message === '信用卡退款查詢無法取得訂單狀態'){
            //   console.log("捕捉到退款時的 unknown_error 錯誤，回傳自定義訊息給前端")
            //   res.status(500).json({
            //     code: "'api_error'",
            //     type: "not_found",
            //     error: "退款處理失敗",
            //     message: "退款處理失敗，根據綠界文件：請過30分鐘後再試",
            //   })
            //   return
            // }
        }
        // if (req.path.includes('/refund')) {
        //   if (error.type === "unknown_error"){
        //     console.log("捕捉到退款時的 unknown_error 錯誤，回傳自定義訊息給前端")
        //     res.status(500).json({
        //       code: "'api_error'",
        //       type: "not_found",
        //       error: "退款處理失敗",
        //       message: "退款處理失敗，根據綠界文件：請過30分鐘後再試",
        //     })
        //     return
        //   }
        // }
        // const refundRoutePattern = /\/orders\/[^/]+\/refund/
        // if (refundRoutePattern.test(req.path)) {
        //   if (error.type === "unknown_error"){
        //     console.log("捕捉到退款時的 unknown_error 錯誤，回傳自定義訊息給前端")
        //     res.status(500).json({
        //       code: "'api_error'",
        //       type: "not_found",
        //       error: "退款處理失敗",
        //       message: "退款處理失敗，根據綠界文件：請過30分鐘後再試",
        //     })
        //     return
        //   }
        // }
        // 對於其他錯誤,使用原始的錯誤處理器
        return originalErrorHandler(error, req, res, next);
    },
    routes: [
        {
            matcher: "/custom-hooks/ecpay-callback",
            bodyParser: { preserveRawBody: true },
            method: ["POST"],
            middlewares: [
                customHooks.ecpayCallBack,
            ],
        },
        {
            matcher: "/static/*",
            method: ["GET"],
            middlewares: [
                express_1.default.static(path_1.default.join(process.cwd(), "static"), {
                    fallthrough: false,
                    index: false,
                }),
            ],
        },
    ],
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWlkZGxld2FyZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvYXBpL21pZGRsZXdhcmVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEseUJBQXlCO0FBQ3pCLG1EQUtpQztBQUNqQyw0REFBNkM7QUFDN0Msc0RBQTZCO0FBQzdCLGdEQUF1QjtBQUl2QixNQUFNLG9CQUFvQixHQUFHLElBQUEsbUJBQVksR0FBRSxDQUFBO0FBRTNDLGtCQUFlLElBQUEsd0JBQWlCLEVBQUM7SUFDL0IsWUFBWSxFQUFFLENBQ1osS0FBd0IsRUFDeEIsR0FBa0IsRUFDbEIsR0FBbUIsRUFDbkIsSUFBd0IsRUFDeEIsRUFBRTtRQUVGLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEVBQUMsS0FBSyxDQUFDLENBQUE7UUFDOUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFBO1FBSW5DLGFBQWE7UUFDYixxQkFBcUI7UUFDckIsOENBQThDO1FBQzlDLG9GQUFvRjtRQUNwRixJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLCtDQUErQyxDQUFDLEVBQUUsQ0FBQztZQUVwRSxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBQyxLQUFLLENBQUMsQ0FBQTtZQUVsQyxRQUFPLEtBQUssQ0FBQyxPQUFPLEVBQUMsQ0FBQztnQkFFcEIsS0FBSyxpQkFBaUI7b0JBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQTtvQkFDOUIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7d0JBQ25CLElBQUksRUFBRSxhQUFhO3dCQUNuQixJQUFJLEVBQUUsV0FBVzt3QkFDakIsS0FBSyxFQUFFLFFBQVE7d0JBQ2YsT0FBTyxFQUFFLHlCQUF5QjtxQkFDbkMsQ0FBQyxDQUFBO29CQUVGLE9BQU07Z0JBQ1IsS0FBSyxzREFBc0Q7b0JBQ3pELE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUE7b0JBQ3RCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO3dCQUNuQixJQUFJLEVBQUUsYUFBYTt3QkFDbkIsSUFBSSxFQUFFLFdBQVc7d0JBQ2pCLEtBQUssRUFBRSxTQUFTO3dCQUNoQixPQUFPLEVBQUUsaUNBQWlDO3FCQUMzQyxDQUFDLENBQUE7b0JBRUYsT0FBTTtZQUVWLENBQUM7WUFFRCw0Q0FBNEM7WUFFNUMsdURBQXVEO1lBRXZELDJCQUEyQjtZQUMzQiwyQkFBMkI7WUFDM0IseUJBQXlCO1lBQ3pCLHVCQUF1QjtZQUN2QiwwQ0FBMEM7WUFDMUMsT0FBTztZQUVQLFdBQVc7WUFDWCxJQUFJO1FBQ04sQ0FBQztRQUlELHNDQUFzQztRQUN0Qyx5Q0FBeUM7UUFFekMseURBQXlEO1FBRXpELDZCQUE2QjtRQUM3Qiw2QkFBNkI7UUFDN0IsMkJBQTJCO1FBQzNCLHlCQUF5QjtRQUN6Qiw0Q0FBNEM7UUFDNUMsU0FBUztRQUVULGFBQWE7UUFDYixNQUFNO1FBRU4sSUFBSTtRQUlKLHVEQUF1RDtRQUN2RCwyQ0FBMkM7UUFFM0MseUNBQXlDO1FBRXpDLHlEQUF5RDtRQUV6RCw2QkFBNkI7UUFDN0IsNkJBQTZCO1FBQzdCLDJCQUEyQjtRQUMzQix5QkFBeUI7UUFDekIsNENBQTRDO1FBQzVDLFNBQVM7UUFDVCxhQUFhO1FBQ2IsTUFBTTtRQUVOLElBQUk7UUFHSixvQkFBb0I7UUFDcEIsT0FBTyxvQkFBb0IsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQTtJQUNwRCxDQUFDO0lBRUQsTUFBTSxFQUFFO1FBQ047WUFDRSxPQUFPLEVBQUUsOEJBQThCO1lBQ3ZDLFVBQVUsRUFBRSxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUU7WUFDckMsTUFBTSxFQUFFLENBQUMsTUFBTSxDQUFDO1lBQ2hCLFdBQVcsRUFBQztnQkFDVixXQUFXLENBQUMsYUFBYTthQUMxQjtTQUNGO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsV0FBVztZQUNwQixNQUFNLEVBQUUsQ0FBQyxLQUFLLENBQUM7WUFDZixXQUFXLEVBQUU7Z0JBQ1gsaUJBQU8sQ0FBQyxNQUFNLENBQUMsY0FBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEVBQUUsUUFBUSxDQUFDLEVBQUU7b0JBQ2pELFdBQVcsRUFBRSxLQUFLO29CQUNsQixLQUFLLEVBQUUsS0FBSztpQkFDYixDQUFDO2FBQ0g7U0FDRjtLQUNGO0NBQ0YsQ0FBQyxDQUFBIn0=