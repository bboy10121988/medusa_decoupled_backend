"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const store_1 = __importDefault(require("./routes/store"));
// 設置所有API路由
exports.default = (app, rootDirectory, config) => {
    const router = (0, express_1.Router)();
    // 添加商店路由
    router.use("/store", (0, store_1.default)(app, rootDirectory, config));
    // 如果需要，可以添加更多路由組...
    // router.use("/admin", adminRoutes())
    return router;
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvYXBpL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEscUNBQWdDO0FBQ2hDLDJEQUF3QztBQUV4QyxZQUFZO0FBQ1osa0JBQWUsQ0FBQyxHQUFHLEVBQUUsYUFBYSxFQUFFLE1BQU0sRUFBRSxFQUFFO0lBQzVDLE1BQU0sTUFBTSxHQUFHLElBQUEsZ0JBQU0sR0FBRSxDQUFBO0lBRXZCLFNBQVM7SUFDVCxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFBLGVBQVcsRUFBQyxHQUFHLEVBQUUsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUE7SUFFN0Qsb0JBQW9CO0lBQ3BCLHNDQUFzQztJQUV0QyxPQUFPLE1BQU0sQ0FBQTtBQUNmLENBQUMsQ0FBQSJ9