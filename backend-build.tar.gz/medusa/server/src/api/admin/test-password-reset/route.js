"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = void 0;
const utils_1 = require("@medusajs/framework/utils");
/**
 * 測試密碼重設通知的 API 端點
 * POST /admin/test-password-reset
 */
const POST = async (req, res) => {
    const body = req.body;
    const { email, actor_type = 'customer', token } = body;
    if (!email) {
        return res.status(400).json({
            error: "Missing required field: 'email'"
        });
    }
    try {
        const notificationModuleService = req.scope.resolve(utils_1.Modules.NOTIFICATION);
        // 生成測試 token（如果未提供）
        const testToken = token || `test_reset_token_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        let urlPrefix = "";
        let templateId = "password-reset";
        let storeName = "Tim's Fantasy World";
        // 根據用戶類型設定不同的重設 URL 和範本
        if (actor_type === "customer") {
            urlPrefix = process.env.FRONTEND_URL || process.env.NEXT_PUBLIC_SITE_URL || "https://timsfantasyworld.com";
            templateId = "customer-password-reset";
        }
        else {
            const backendUrl = process.env.MEDUSA_ADMIN_BACKEND_URL || process.env.MEDUSA_BACKEND_URL || "https://admin.timsfantasyworld.com";
            urlPrefix = `${backendUrl}/app`;
            templateId = "admin-password-reset";
        }
        // 建構重設密碼的完整 URL
        const resetUrl = `${urlPrefix}/reset-password?token=${testToken}&email=${encodeURIComponent(email)}`;
        console.log(`🧪 測試密碼重設通知`);
        console.log(`📧 收件人: ${email}`);
        console.log(`👤 用戶類型: ${actor_type}`);
        console.log(`📋 使用範本: ${templateId}`);
        console.log(`🔗 重設連結: ${resetUrl}`);
        await notificationModuleService.createNotifications({
            to: email,
            channel: "email",
            template: templateId,
            data: {
                email: email,
                reset_url: resetUrl,
                token: testToken,
                actor_type: actor_type,
                store_name: storeName,
                expiry_message: "此連結將在 24 小時後失效",
                security_notice: "如果您沒有要求重設密碼，請忽略此郵件。",
                support_email: "support@timsfantasyworld.com",
                site_url: process.env.FRONTEND_URL || "https://timsfantasyworld.com",
                current_year: new Date().getFullYear(),
                user_type_display: actor_type === "customer" ? "客戶" : "管理員",
            },
        });
        console.log(`✅ 測試密碼重設郵件已發送到: ${email}`);
        res.status(200).json({
            success: true,
            message: `Test password reset email sent to ${email}`,
            details: {
                email,
                actor_type,
                template: templateId,
                reset_url: resetUrl,
                provider: process.env.SENDGRID_API_KEY ? 'SendGrid' : 'Local',
            },
        });
    }
    catch (error) {
        console.error("❌ 測試密碼重設郵件發送失敗:", error);
        res.status(500).json({
            error: "Failed to send test password reset email",
            details: error instanceof Error ? error.message : String(error),
        });
    }
};
exports.POST = POST;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3Rlc3QtcGFzc3dvcmQtcmVzZXQvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBSUEscURBQW1EO0FBRW5EOzs7R0FHRztBQUNJLE1BQU0sSUFBSSxHQUFHLEtBQUssRUFDdkIsR0FBK0IsRUFDL0IsR0FBbUIsRUFDbkIsRUFBRTtJQUNGLE1BQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxJQUloQixDQUFBO0lBQ0QsTUFBTSxFQUFFLEtBQUssRUFBRSxVQUFVLEdBQUcsVUFBVSxFQUFFLEtBQUssRUFBRSxHQUFHLElBQUksQ0FBQTtJQUV0RCxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDWCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLEtBQUssRUFBRSxpQ0FBaUM7U0FDekMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELElBQUksQ0FBQztRQUNILE1BQU0seUJBQXlCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLFlBQVksQ0FBQyxDQUFBO1FBRXpFLG9CQUFvQjtRQUNwQixNQUFNLFNBQVMsR0FBRyxLQUFLLElBQUksb0JBQW9CLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtRQUV0RyxJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUE7UUFDbEIsSUFBSSxVQUFVLEdBQUcsZ0JBQWdCLENBQUE7UUFDakMsSUFBSSxTQUFTLEdBQUcscUJBQXFCLENBQUE7UUFFckMsd0JBQXdCO1FBQ3hCLElBQUksVUFBVSxLQUFLLFVBQVUsRUFBRSxDQUFDO1lBQzlCLFNBQVMsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixJQUFJLDhCQUE4QixDQUFBO1lBQzFHLFVBQVUsR0FBRyx5QkFBeUIsQ0FBQTtRQUN4QyxDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsSUFBSSxvQ0FBb0MsQ0FBQTtZQUNqSSxTQUFTLEdBQUcsR0FBRyxVQUFVLE1BQU0sQ0FBQTtZQUMvQixVQUFVLEdBQUcsc0JBQXNCLENBQUE7UUFDckMsQ0FBQztRQUVELGdCQUFnQjtRQUNoQixNQUFNLFFBQVEsR0FBRyxHQUFHLFNBQVMseUJBQXlCLFNBQVMsVUFBVSxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFBO1FBRXBHLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUE7UUFDMUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEtBQUssRUFBRSxDQUFDLENBQUE7UUFDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLFVBQVUsRUFBRSxDQUFDLENBQUE7UUFDckMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLFVBQVUsRUFBRSxDQUFDLENBQUE7UUFDckMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLFFBQVEsRUFBRSxDQUFDLENBQUE7UUFFbkMsTUFBTSx5QkFBeUIsQ0FBQyxtQkFBbUIsQ0FBQztZQUNsRCxFQUFFLEVBQUUsS0FBSztZQUNULE9BQU8sRUFBRSxPQUFPO1lBQ2hCLFFBQVEsRUFBRSxVQUFVO1lBQ3BCLElBQUksRUFBRTtnQkFDSixLQUFLLEVBQUUsS0FBSztnQkFDWixTQUFTLEVBQUUsUUFBUTtnQkFDbkIsS0FBSyxFQUFFLFNBQVM7Z0JBQ2hCLFVBQVUsRUFBRSxVQUFVO2dCQUN0QixVQUFVLEVBQUUsU0FBUztnQkFDckIsY0FBYyxFQUFFLGdCQUFnQjtnQkFDaEMsZUFBZSxFQUFFLHFCQUFxQjtnQkFDdEMsYUFBYSxFQUFFLDhCQUE4QjtnQkFDN0MsUUFBUSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxJQUFJLDhCQUE4QjtnQkFDcEUsWUFBWSxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO2dCQUN0QyxpQkFBaUIsRUFBRSxVQUFVLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUs7YUFDNUQ7U0FDRixDQUFDLENBQUE7UUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixLQUFLLEVBQUUsQ0FBQyxDQUFBO1FBRXZDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLE9BQU8sRUFBRSxJQUFJO1lBQ2IsT0FBTyxFQUFFLHFDQUFxQyxLQUFLLEVBQUU7WUFDckQsT0FBTyxFQUFFO2dCQUNQLEtBQUs7Z0JBQ0wsVUFBVTtnQkFDVixRQUFRLEVBQUUsVUFBVTtnQkFDcEIsU0FBUyxFQUFFLFFBQVE7Z0JBQ25CLFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLE9BQU87YUFDOUQ7U0FDRixDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDdkMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFLDBDQUEwQztZQUNqRCxPQUFPLEVBQUUsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztTQUNoRSxDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyxDQUFBO0FBdEZZLFFBQUEsSUFBSSxRQXNGaEIifQ==