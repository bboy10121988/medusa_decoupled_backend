"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AUTHENTICATE = void 0;
exports.POST = POST;
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
exports.AUTHENTICATE = true;
async function POST(req, res) {
    const { id } = req.params;
    const { detail_content, detail_images } = req.body;
    try {
        const productModuleService = req.scope.resolve(utils_1.Modules.PRODUCT);
        // 獲取產品
        const product = await productModuleService.retrieveProduct(id);
        if (!product) {
            res.status(404).json({
                message: "Product not found"
            });
            return;
        }
        // 更新 metadata，保留其他現有的 metadata
        const updatedMetadata = {
            ...product.metadata,
            detail_content: detail_content || '',
            detail_images: JSON.stringify(detail_images || [])
        };
        // 更新產品 metadata
        await productModuleService.updateProducts(id, {
            metadata: updatedMetadata
        });
        res.json({
            success: true,
            message: "Product detail content updated successfully"
        });
    }
    catch (error) {
        console.error("Error updating product detail content:", error);
        res.status(400).json({
            message: "Failed to update product detail content",
            error: error.message
        });
    }
}
async function GET(req, res) {
    const { id } = req.params;
    try {
        const productModuleService = req.scope.resolve(utils_1.Modules.PRODUCT);
        // 獲取產品
        const product = await productModuleService.retrieveProduct(id);
        if (!product) {
            res.status(404).json({
                message: "Product not found"
            });
            return;
        }
        const detailContent = product.metadata?.detail_content || '';
        const detailImages = product.metadata?.detail_images
            ? JSON.parse(product.metadata.detail_images)
            : [];
        res.json({
            detail_content: detailContent,
            detail_images: detailImages
        });
    }
    catch (error) {
        console.error("Error retrieving product detail content:", error);
        res.status(404).json({
            message: "Product not found",
            error: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3Byb2R1Y3RzL1tpZF0vZGV0YWlsLWNvbnRlbnQvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBU0Esb0JBOENDO0FBRUQsa0JBbUNDO0FBdkZELHFEQUFtRDtBQUV0QyxRQUFBLFlBQVksR0FBRyxJQUFJLENBQUM7QUFFMUIsS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBK0IsRUFDL0IsR0FBbUI7SUFFbkIsTUFBTSxFQUFFLEVBQUUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFDekIsTUFBTSxFQUFFLGNBQWMsRUFBRSxhQUFhLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFHN0MsQ0FBQTtJQUVELElBQUksQ0FBQztRQUNILE1BQU0sb0JBQW9CLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLE9BQU8sQ0FBQyxDQUFBO1FBRS9ELE9BQU87UUFDUCxNQUFNLE9BQU8sR0FBRyxNQUFNLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUU5RCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDYixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkIsT0FBTyxFQUFFLG1CQUFtQjthQUM3QixDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1IsQ0FBQztRQUVELCtCQUErQjtRQUMvQixNQUFNLGVBQWUsR0FBRztZQUN0QixHQUFHLE9BQU8sQ0FBQyxRQUFRO1lBQ25CLGNBQWMsRUFBRSxjQUFjLElBQUksRUFBRTtZQUNwQyxhQUFhLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLElBQUksRUFBRSxDQUFDO1NBQ25ELENBQUE7UUFFRCxnQkFBZ0I7UUFDaEIsTUFBTSxvQkFBb0IsQ0FBQyxjQUFjLENBQUMsRUFBRSxFQUFFO1lBQzVDLFFBQVEsRUFBRSxlQUFlO1NBQzFCLENBQUMsQ0FBQTtRQUVGLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxPQUFPLEVBQUUsSUFBSTtZQUNiLE9BQU8sRUFBRSw2Q0FBNkM7U0FDdkQsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLHdDQUF3QyxFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQzlELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLE9BQU8sRUFBRSx5Q0FBeUM7WUFDbEQsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDO0FBRU0sS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxFQUFFLEVBQUUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFFekIsSUFBSSxDQUFDO1FBQ0gsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsT0FBTyxDQUFDLENBQUE7UUFFL0QsT0FBTztRQUNQLE1BQU0sT0FBTyxHQUFHLE1BQU0sb0JBQW9CLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBRTlELElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNiLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNuQixPQUFPLEVBQUUsbUJBQW1CO2FBQzdCLENBQUMsQ0FBQTtZQUNGLE9BQU07UUFDUixDQUFDO1FBRUQsTUFBTSxhQUFhLEdBQUcsT0FBTyxDQUFDLFFBQVEsRUFBRSxjQUFjLElBQUksRUFBRSxDQUFBO1FBQzVELE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyxRQUFRLEVBQUUsYUFBYTtZQUNsRCxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLGFBQXVCLENBQUM7WUFDdEQsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtRQUVOLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxjQUFjLEVBQUUsYUFBYTtZQUM3QixhQUFhLEVBQUUsWUFBWTtTQUM1QixDQUFDLENBQUE7SUFDSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsMENBQTBDLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDaEUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsT0FBTyxFQUFFLG1CQUFtQjtZQUM1QixLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDckIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==