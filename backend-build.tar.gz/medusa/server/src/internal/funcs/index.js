"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isInTaipeiTimeRangeIntl = exports.isInTaipeiTimeRangeCustom = exports.isInTaipeiTimeRange = void 0;
var is_in_taipei_ime_range_intl_1 = require("./is_in_taipei_ime_range_intl");
Object.defineProperty(exports, "isInTaipeiTimeRange", { enumerable: true, get: function () { return is_in_taipei_ime_range_intl_1.isInTaipeiTimeRange; } });
Object.defineProperty(exports, "isInTaipeiTimeRangeCustom", { enumerable: true, get: function () { return is_in_taipei_ime_range_intl_1.isInTaipeiTimeRangeCustom; } });
Object.defineProperty(exports, "isInTaipeiTimeRangeIntl", { enumerable: true, get: function () { return is_in_taipei_ime_range_intl_1.isInTaipeiTimeRangeIntl; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvaW50ZXJuYWwvZnVuY3MvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsNkVBSXVDO0FBSHJDLGtJQUFBLG1CQUFtQixPQUFBO0FBQ25CLHdJQUFBLHlCQUF5QixPQUFBO0FBQ3pCLHNJQUFBLHVCQUF1QixPQUFBIn0=