"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ENV_MODE_PROD = exports.ENV_MODE_DEV = exports.ENV_MODE_LOCALHOST = void 0;
/**
 * 環境模式常數
 *
 * - 用途：集中管理 ENVIRONMENT_MODE 可用值，避免魔法字串散落各處。
 * - 匯出：以 named export 匯出，import 目錄即可使用（index.ts）。
 */
exports.ENV_MODE_LOCALHOST = "localhost";
exports.ENV_MODE_DEV = "dev";
exports.ENV_MODE_PROD = "prod";
exports.default = {
    ENV_MODE_LOCALHOST: exports.ENV_MODE_LOCALHOST,
    ENV_MODE_DEV: exports.ENV_MODE_DEV,
    ENV_MODE_PROD: exports.ENV_MODE_PROD,
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvaW50ZXJuYWwvY29uc3RhbnRzL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBOzs7OztHQUtHO0FBQ1UsUUFBQSxrQkFBa0IsR0FBRyxXQUFXLENBQUE7QUFDaEMsUUFBQSxZQUFZLEdBQUcsS0FBSyxDQUFBO0FBQ3BCLFFBQUEsYUFBYSxHQUFHLE1BQU0sQ0FBQTtBQUVuQyxrQkFBZTtJQUNiLGtCQUFrQixFQUFsQiwwQkFBa0I7SUFDbEIsWUFBWSxFQUFaLG9CQUFZO0lBQ1osYUFBYSxFQUFiLHFCQUFhO0NBQ2QsQ0FBQSJ9