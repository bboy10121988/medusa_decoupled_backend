"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const { describe, it, expect } = require('@jest/globals');
const service_1 = __importDefault(require("./service"));
describe('ECPay Service', () => {
    console.log("123");
    it('should return correct response', async () => {
        const service = new service_1.default('testMerchantID', 'http://localhost:8080', 'testHashKey', 'testHashIV');
        const response = await service.getCreditDetail({
            CreditCheckCode: 12345678,
            CreditRefundId: 87654321,
            CreditAmount: 1000
        });
        describe('Response Structure', () => {
            console.log(response);
            console.log(response.RtnValue.close_data);
        });
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS50ZXN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL2ludGVybmFsL2VjcGF5cy9zZXJ2aWNlLnRlc3QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxNQUFNLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDMUQsd0RBQWdDO0FBR2hDLFFBQVEsQ0FBQyxlQUFlLEVBQUUsR0FBRyxFQUFFO0lBQzNCLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDbEIsRUFBRSxDQUFDLGdDQUFnQyxFQUFFLEtBQUssSUFBSyxFQUFFO1FBRTdDLE1BQU0sT0FBTyxHQUFZLElBQUksaUJBQU8sQ0FDaEMsZ0JBQWdCLEVBQ2hCLHVCQUF1QixFQUN2QixhQUFhLEVBQ2IsWUFBWSxDQUNmLENBQUM7UUFFRixNQUFNLFFBQVEsR0FBRyxNQUFNLE9BQU8sQ0FBQyxlQUFlLENBQUM7WUFDM0MsZUFBZSxFQUFDLFFBQVE7WUFDeEIsY0FBYyxFQUFFLFFBQVE7WUFDeEIsWUFBWSxFQUFFLElBQUk7U0FDckIsQ0FBQyxDQUFDO1FBRUgsUUFBUSxDQUFDLG9CQUFvQixFQUFFLEdBQUUsRUFBRTtZQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3RCLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM5QyxDQUFDLENBQUMsQ0FBQTtJQUlOLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMifQ==