"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// src/api/middlewares.ts
const http_1 = require("@medusajs/framework/http");
// import * as customHooks from "./custom-hooks"
exports.default = (0, http_1.defineMiddlewares)({
    routes: [
        {
            matcher: "/custom-hooks/ecpay-callback",
            bodyParser: { preserveRawBody: true },
            method: ["POST"],
            middlewares: [
            // customHooks.ecpayCallBack,
            ],
        },
    ],
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWlkZGxld2FyZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvc3JjL2FwaS9taWRkbGV3YXJlcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHlCQUF5QjtBQUN6QixtREFBNEQ7QUFDNUQsZ0RBQWdEO0FBRWhELGtCQUFlLElBQUEsd0JBQWlCLEVBQUM7SUFDL0IsTUFBTSxFQUFFO1FBQ047WUFDRSxPQUFPLEVBQUUsOEJBQThCO1lBQ3ZDLFVBQVUsRUFBRSxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUU7WUFDckMsTUFBTSxFQUFFLENBQUMsTUFBTSxDQUFDO1lBQ2hCLFdBQVcsRUFBQztZQUNWLDZCQUE2QjthQUM5QjtTQUNGO0tBQ0Y7Q0FDRixDQUFDLENBQUEifQ==