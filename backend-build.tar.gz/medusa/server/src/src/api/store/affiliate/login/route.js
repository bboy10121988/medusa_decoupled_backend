"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
// POST /store/affiliate/login - 聯盟夥伴登入
async function POST(req, res) {
    try {
        const body = req.body;
        const { email, password } = body;
        if (!email || !password) {
            res.status(400).json({
                error: "Missing credentials",
                message: "Email and password are required"
            });
            return;
        }
        // 這裡應該驗證聯盟夥伴登入資訊
        // 暫時返回模擬成功響應
        const affiliatePartner = {
            id: "aff_partner_1",
            email,
            name: "測試聯盟夥伴",
            commission_rate: 0.05, // 5%
            status: "active"
        };
        res.json({
            partner: affiliatePartner,
            token: `aff_token_${Date.now()}`,
            message: "Login successful"
        });
    }
    catch (error) {
        res.status(500).json({
            error: "Internal server error",
            message: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvc3JjL2FwaS9zdG9yZS9hZmZpbGlhdGUvbG9naW4vcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFNQSxvQkFxQ0M7QUF0Q0QsdUNBQXVDO0FBQ2hDLEtBQUssVUFBVSxJQUFJLENBQ3hCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLElBQUksQ0FBQztRQUNILE1BQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxJQUE2QyxDQUFBO1FBQzlELE1BQU0sRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFBO1FBRWhDLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUN4QixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkIsS0FBSyxFQUFFLHFCQUFxQjtnQkFDNUIsT0FBTyxFQUFFLGlDQUFpQzthQUMzQyxDQUFDLENBQUE7WUFDRixPQUFNO1FBQ1IsQ0FBQztRQUVELGlCQUFpQjtRQUNqQixhQUFhO1FBQ2IsTUFBTSxnQkFBZ0IsR0FBRztZQUN2QixFQUFFLEVBQUUsZUFBZTtZQUNuQixLQUFLO1lBQ0wsSUFBSSxFQUFFLFFBQVE7WUFDZCxlQUFlLEVBQUUsSUFBSSxFQUFFLEtBQUs7WUFDNUIsTUFBTSxFQUFFLFFBQVE7U0FDakIsQ0FBQTtRQUVELEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxPQUFPLEVBQUUsZ0JBQWdCO1lBQ3pCLEtBQUssRUFBRSxhQUFhLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUNoQyxPQUFPLEVBQUUsa0JBQWtCO1NBQzVCLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRSx1QkFBdUI7WUFDOUIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3ZCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=