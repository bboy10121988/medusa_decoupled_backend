"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
// POST /affiliate/affiliate/login - 聯盟夥伴登入 (備用路由)
async function POST(req, res) {
    try {
        const body = req.body;
        const { email, password } = body;
        if (!email || !password) {
            res.status(400).json({
                error: "Missing credentials",
                message: "Email and password are required"
            });
            return;
        }
        // 這裡應該驗證聯盟夥伴登入資訊
        const affiliatePartner = {
            id: "aff_partner_1",
            email,
            name: "測試聯盟夥伴",
            commission_rate: 0.05,
            status: "active",
            referral_code: "TEST123"
        };
        res.json({
            partner: affiliatePartner,
            token: `aff_token_${Date.now()}`,
            message: "Login successful"
        });
    }
    catch (error) {
        res.status(500).json({
            error: "Internal server error",
            message: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvc3JjL2FwaS9hZmZpbGlhdGUvYWZmaWxpYXRlL2xvZ2luL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBTUEsb0JBcUNDO0FBdENELGtEQUFrRDtBQUMzQyxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixJQUFJLENBQUM7UUFDSCxNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsSUFBNkMsQ0FBQTtRQUM5RCxNQUFNLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxHQUFHLElBQUksQ0FBQTtRQUVoQyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDeEIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ25CLEtBQUssRUFBRSxxQkFBcUI7Z0JBQzVCLE9BQU8sRUFBRSxpQ0FBaUM7YUFDM0MsQ0FBQyxDQUFBO1lBQ0YsT0FBTTtRQUNSLENBQUM7UUFFRCxpQkFBaUI7UUFDakIsTUFBTSxnQkFBZ0IsR0FBRztZQUN2QixFQUFFLEVBQUUsZUFBZTtZQUNuQixLQUFLO1lBQ0wsSUFBSSxFQUFFLFFBQVE7WUFDZCxlQUFlLEVBQUUsSUFBSTtZQUNyQixNQUFNLEVBQUUsUUFBUTtZQUNoQixhQUFhLEVBQUUsU0FBUztTQUN6QixDQUFBO1FBRUQsR0FBRyxDQUFDLElBQUksQ0FBQztZQUNQLE9BQU8sRUFBRSxnQkFBZ0I7WUFDekIsS0FBSyxFQUFFLGFBQWEsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO1lBQ2hDLE9BQU8sRUFBRSxrQkFBa0I7U0FDNUIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFLHVCQUF1QjtZQUM5QixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDdkIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==