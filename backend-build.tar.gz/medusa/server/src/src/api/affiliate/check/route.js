"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
// GET /affiliate/check - 檢查聯盟夥伴狀態
async function GET(req, res) {
    try {
        const { token } = req.query;
        if (!token) {
            res.status(400).json({
                error: "Missing token",
                message: "Affiliate token is required"
            });
            return;
        }
        // 這裡應該驗證token並獲取聯盟夥伴資訊
        // 暫時返回模擬資料
        const affiliate = {
            id: "aff_partner_1",
            name: "測試聯盟夥伴",
            email: "partner@example.com",
            commission_rate: 0.05,
            status: "active",
            total_earnings: 1250.00,
            pending_earnings: 350.00
        };
        res.json({
            affiliate,
            is_valid: true
        });
    }
    catch (error) {
        res.status(500).json({
            error: "Internal server error",
            message: error.message
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvc3JjL2FwaS9hZmZpbGlhdGUvY2hlY2svcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFNQSxrQkFxQ0M7QUF0Q0Qsa0NBQWtDO0FBQzNCLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLElBQUksQ0FBQztRQUNILE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBMkIsQ0FBQTtRQUVqRCxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDWCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkIsS0FBSyxFQUFFLGVBQWU7Z0JBQ3RCLE9BQU8sRUFBRSw2QkFBNkI7YUFDdkMsQ0FBQyxDQUFBO1lBQ0YsT0FBTTtRQUNSLENBQUM7UUFFRCx1QkFBdUI7UUFDdkIsV0FBVztRQUNYLE1BQU0sU0FBUyxHQUFHO1lBQ2hCLEVBQUUsRUFBRSxlQUFlO1lBQ25CLElBQUksRUFBRSxRQUFRO1lBQ2QsS0FBSyxFQUFFLHFCQUFxQjtZQUM1QixlQUFlLEVBQUUsSUFBSTtZQUNyQixNQUFNLEVBQUUsUUFBUTtZQUNoQixjQUFjLEVBQUUsT0FBTztZQUN2QixnQkFBZ0IsRUFBRSxNQUFNO1NBQ3pCLENBQUE7UUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ1AsU0FBUztZQUNULFFBQVEsRUFBRSxJQUFJO1NBQ2YsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFLHVCQUF1QjtZQUM5QixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDdkIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==