"use strict";
// import type { MedusaRequest, MedusaResponse, MedusaNextFunction } from "@medusajs/framework/http"
// import { IncomingForm } from 'formidable'
// import { Readable } from 'stream'
// import * as querystring from 'querystring'
// import { completeCartWorkflow,markPaymentCollectionAsPaid,capturePaymentWorkflow,cancelOrderWorkflow,updateOrderWorkflow } from "@medusajs/medusa/core-flows"
// import { ConstraintViolationException, t } from "@mikro-orm/core"
// import { resourceLimits } from "worker_threads"
Object.defineProperty(exports, "__esModule", { value: true });
// // Define strong type interface for ECPay callback
// interface EcpayCallbackBody {
//     MerchantID?: string
//     MerchantTradeNo?: string
//     StoreID?: string
//     RtnCode?: number
//     RtnMsg?: string
//     TradeNo?: string
//     TradeAmt?: string
//     PaymentDate?: string
//     PaymentType?: string
//     PaymentTypeChargeFee?: string
//     TradeDate?: string
//     PlatformID?: string
//     SimulatePaid?: string
//     CustomField1?: string
//     CustomField2?: string
//     CustomField3?: string
//     CustomField4?: string
//     CheckMacValue?: string
// }
// const ecpayCallBack = async (req: MedusaRequest, res: MedusaResponse,next: MedusaNextFunction) => {
//     const action: string = "ecpayCallBack"
//     console.log(action,"Received ECPay callback",req.body)
//     try {
//         const body = req.body
//         if (!body) {
//             throw new Error("Request body is empty")
//         }
//         const data = body as EcpayCallbackBody
//         let cartID: string = ""
//         if (!data.CustomField4){
//             throw new Error("CustomField4 (cart_id) is missing")
//         }else{
//             cartID = data.CustomField4
//         }
//         const { result } = await completeCartWorkflow(req.scope).run({
//             input: { id:cartID }, // 只需要 cart 的 ID
//         })
//         console.log(action,"excute completeCartWorkflow, and get orderID result:",result)
//         const orderID = result.id
//         // 正確：直接拿到 query 實例，呼叫 graph
//         const query = req.scope.resolve("query")
//         const { data: orders } = await query.graph({
//             entity: "order",
//             fields: ["id", "payment_collections.id"],
//             filters: { id: orderID },
//         })
//         console.log(action,"get order by orderID, orders:",orders)
//         const theOrder = orders?.[0]
//         console.log(action,"theOrder:",theOrder)
//         if (!theOrder){
//             throw new Error("Order not found for orderID: " + orderID)
//         }
//         const thePaymentCollections = theOrder?.payment_collections
//         console.log(action,"get paymentCollections by orderID, paymentCollections:",thePaymentCollections)
//         const paymentCollectionID = thePaymentCollections?.[0]?.id
//         if (!paymentCollectionID){
//             res.status(200).send("1|OK")
//             return
//         }
//         const { data: paymentCollections } = await query.graph({
//             entity: "payment_collection",
//             fields: ["id", "payments.id"],
//             filters: { id: paymentCollectionID },
//         })
//         const thePaymentCollection = paymentCollections?.[0]
//         console.log(action,"thePaymentCollection:",thePaymentCollection)
//         const thePayments = thePaymentCollection?.payments
//         console.log(action,"thePaymens:",thePayments)
//         const thePayment = thePayments?.[0]
//         console.log(action,"thePayment:",thePayment)
//         const paymentID = thePayment?.id
//         console.log(action,"paymentID",paymentID)
//         if (paymentID){
//             let theMetadata = {
//                 payment_type: "ecpayment",
//                 payment_code: data.RtnCode,
//                 payment_msg: data.RtnMsg,
//                 payment_status: "unknown",
//             }
//             if (data.RtnCode === 1){
//                 console.log(action,"excute capturePaymentWorkflow, paymentID:",paymentID)
//                 await capturePaymentWorkflow(req.scope).run({
//                         input: {
//                         payment_id: paymentID,
//                         amount: data.TradeAmt ? parseInt(data.TradeAmt) : undefined,
//                     },
//                 })
//                 theMetadata.payment_status = "success"
//             }else{
//                 theMetadata.payment_status = "failed"
//             }
//             console.log(action,"excute cancelOrderWorkflow, paymentID:",paymentID)
//             await updateOrderWorkflow(req.scope).run({
//                 input:{
//                     id: orderID,
//                     user_id: "ecpayment callback",
//                     metadata:theMetadata
//                 }
//             })
//         }
//     } catch (error) {
//         console.error(action,"Error parsing request body:", error)
//         res.status(400).send("0|Error")
//         return
//     }
//     res.status(200).send("1|OK")
// }
// export { ecpayCallBack }
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWNwYXktY2FsbGJhY2suanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvc3JjL2FwaS9jdXN0b20taG9va3MvZWNwYXktY2FsbGJhY2sudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLG9HQUFvRztBQUNwRyw0Q0FBNEM7QUFDNUMsb0NBQW9DO0FBQ3BDLDZDQUE2QztBQUM3QyxnS0FBZ0s7QUFDaEssb0VBQW9FO0FBQ3BFLGtEQUFrRDs7QUFFbEQscURBQXFEO0FBQ3JELGdDQUFnQztBQUNoQywwQkFBMEI7QUFDMUIsK0JBQStCO0FBQy9CLHVCQUF1QjtBQUN2Qix1QkFBdUI7QUFDdkIsc0JBQXNCO0FBQ3RCLHVCQUF1QjtBQUN2Qix3QkFBd0I7QUFDeEIsMkJBQTJCO0FBQzNCLDJCQUEyQjtBQUMzQixvQ0FBb0M7QUFDcEMseUJBQXlCO0FBQ3pCLDBCQUEwQjtBQUMxQiw0QkFBNEI7QUFDNUIsNEJBQTRCO0FBQzVCLDRCQUE0QjtBQUM1Qiw0QkFBNEI7QUFDNUIsNEJBQTRCO0FBQzVCLDZCQUE2QjtBQUM3QixJQUFJO0FBRUosc0dBQXNHO0FBRXRHLDZDQUE2QztBQUU3Qyw2REFBNkQ7QUFFN0QsWUFBWTtBQUNaLGdDQUFnQztBQUVoQyx1QkFBdUI7QUFDdkIsdURBQXVEO0FBQ3ZELFlBQVk7QUFFWixpREFBaUQ7QUFDakQsa0NBQWtDO0FBRWxDLG1DQUFtQztBQUNuQyxtRUFBbUU7QUFDbkUsaUJBQWlCO0FBQ2pCLHlDQUF5QztBQUN6QyxZQUFZO0FBS1oseUVBQXlFO0FBQ3pFLHFEQUFxRDtBQUNyRCxhQUFhO0FBRWIsNEZBQTRGO0FBRTVGLG9DQUFvQztBQUVwQyx1Q0FBdUM7QUFDdkMsbURBQW1EO0FBRW5ELHVEQUF1RDtBQUN2RCwrQkFBK0I7QUFDL0Isd0RBQXdEO0FBQ3hELHdDQUF3QztBQUN4QyxhQUFhO0FBRWIscUVBQXFFO0FBRXJFLHVDQUF1QztBQUV2QyxtREFBbUQ7QUFFbkQsMEJBQTBCO0FBQzFCLHlFQUF5RTtBQUN6RSxZQUFZO0FBSVosc0VBQXNFO0FBRXRFLDZHQUE2RztBQUU3RyxxRUFBcUU7QUFFckUscUNBQXFDO0FBQ3JDLDJDQUEyQztBQUMzQyxxQkFBcUI7QUFDckIsWUFBWTtBQUVaLG1FQUFtRTtBQUNuRSw0Q0FBNEM7QUFDNUMsNkNBQTZDO0FBQzdDLG9EQUFvRDtBQUNwRCxhQUFhO0FBRWIsK0RBQStEO0FBRS9ELDJFQUEyRTtBQUUzRSw2REFBNkQ7QUFFN0Qsd0RBQXdEO0FBRXhELDhDQUE4QztBQUU5Qyx1REFBdUQ7QUFFdkQsMkNBQTJDO0FBRTNDLG9EQUFvRDtBQUVwRCwwQkFBMEI7QUFFMUIsa0NBQWtDO0FBQ2xDLDZDQUE2QztBQUM3Qyw4Q0FBOEM7QUFDOUMsNENBQTRDO0FBQzVDLDZDQUE2QztBQUM3QyxnQkFBZ0I7QUFFaEIsdUNBQXVDO0FBQ3ZDLDRGQUE0RjtBQUM1RixnRUFBZ0U7QUFDaEUsbUNBQW1DO0FBQ25DLGlEQUFpRDtBQUNqRCx1RkFBdUY7QUFDdkYseUJBQXlCO0FBQ3pCLHFCQUFxQjtBQUNyQix5REFBeUQ7QUFDekQscUJBQXFCO0FBQ3JCLHdEQUF3RDtBQUN4RCxnQkFBZ0I7QUFFaEIscUZBQXFGO0FBQ3JGLHlEQUF5RDtBQUN6RCwwQkFBMEI7QUFDMUIsbUNBQW1DO0FBQ25DLHFEQUFxRDtBQUNyRCwyQ0FBMkM7QUFDM0Msb0JBQW9CO0FBQ3BCLGlCQUFpQjtBQUVqQixZQUFZO0FBRVosd0JBQXdCO0FBQ3hCLHFFQUFxRTtBQUNyRSwwQ0FBMEM7QUFDMUMsaUJBQWlCO0FBQ2pCLFFBQVE7QUFFUixtQ0FBbUM7QUFDbkMsSUFBSTtBQUVKLDJCQUEyQiJ9