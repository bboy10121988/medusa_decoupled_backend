"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const uuid_1 = require("uuid");
const funcs_1 = require("./funcs");
const funcs_2 = require("../../internal/funcs");
const ecpays_1 = require("../../internal/ecpays");
/**
 * ECPayCreditProviderService
 *
 * - 提供 Medusa Payment Module 的 ECPay 信用卡支付實作入口
 * - 目前僅提供必要方法的「空實作」與完整註解，方便後續填入實際邏輯
 */
class ECPayCreditProviderService extends utils_1.AbstractPaymentProvider {
    /**
     * 建構子
     *
     * - 方法用途：初始化第三方金流客戶端或連線，並接收框架容器與模組設定。
     * - 參數說明：
     *   - `container`: 由 Medusa 模組提供的 DI 容器（可解析 logger、repositories 等）。
     *   - `config`: 此金流供應商在 `medusa-config.ts` 中註冊時傳入的設定物件。
     * - 回傳值說明：無（建構子不回傳）。
     */
    constructor(container, config = {}) {
        super(container, config);
        this.container = container;
        this.config = config;
    }
    /**
     * initiatePayment
     *
     * - 方法用途：向第三方金流建立/初始化一筆付款會話（payment session），供後續授權/支付流程使用。
     * - 參數說明：
     *   - `input`: 包含金額、幣別與結帳情境（context，如顧客資訊）的初始化輸入。
     * - 回傳值說明：
     *   - 回傳一個物件，至少包含 `data` 欄位（會存入 PaymentSession 的 `data`）。
     */
    async initiatePayment(input) {
        // 
        const action = this.getIdentifier() + " initiatePayment";
        console.log(action, "start initiatePayment with input:", input);
        console.log(action, "initiatePayment input.data:", input.data);
        return {
            id: (0, uuid_1.v4)(),
            data: {
                form_url: (0, funcs_1.getECPayFormURL)(),
                ...input.data
            }
        };
    }
    /**
     * authorizePayment
     *
     * - 方法用途：於下單前授權付款（例如信用卡 3DS 驗證完成後），建立實際 Payment 記錄。
     * - 參數說明：
     *   - `input`: 內含先前 `initiatePayment` 所存於 Session `data` 的資訊，用來在第三方完成授權。
     * - 回傳值說明：
     *   - 回傳 `{ status, data }`；`status` 通常為 `authorized`，`data` 會存入 Payment 的 `data`。
     */
    async authorizePayment(input) {
        const action = this.getIdentifier() + " authorizePayment";
        console.log(action, "start authorizePayment with input:", input);
        console.log(action, "authorizePayment input.data:", input.data);
        return {
            status: "authorized",
            data: input.data
        };
    }
    /**
     * capturePayment
     *
     * - 方法用途：對已授權的付款進行請款（capture）。通常由後台操作或自動流程觸發。
     * - 參數說明：
     *   - `input`: 內含 Payment `data`（通常有第三方的付款識別），用以在第三方執行請款。
     * - 回傳值說明：
     *   - 回傳 `{ data }`；可回存第三方回傳的最新付款資料至 Payment 的 `data`。
     */
    async capturePayment(input) {
        const action = this.getIdentifier() + " capturePayment";
        console.log(action, "start capturePayment with input:", input);
        console.log(action, "capturePayment input.data:", input.data);
        return {
            data: input.data
        };
    }
    /**
     * refundPayment
     *
     * - 方法用途：對已請款成功的付款進行退款（可為部分或全部）。
     * - 參數說明：
     *   - `input`: 內含 Payment `data` 與退款金額 `amount` 等，用以在第三方執行退款。
     * - 回傳值說明：
     *   - 回傳 `{ data }`；可回存第三方回傳的退款結果至 Payment 的 `data`。
     */
    async refundPayment(input) {
        // 由於 input.data不會在放任何有用的資訊，我們需要把這個payment的order.metadata撈出來用
        const action = this.getIdentifier() + " refundPayment";
        console.log(action, "start refundPayment with input:", input);
        console.log(action, "refundPayment input.data:", input.data);
        try {
            // check: 時間不能是20:15 - 20:30
            if ((0, funcs_2.isInTaipeiTimeRange)(new Date())) {
                throw new Error("ECPay 退款 在每日 20:15 - 20:30 之間無法使用，請稍後再試");
            }
            // ecpay api 必要資料：
            // - MarchantID 特店代號: from .env
            // - CreditRefundId 退款交易序號(gwsr) from input.data
            // - CreditAmount 金額 from input.amount
            // - CreditCheckCode 商家檢查碼 from .env
            const creditCheckCode = parseInt(process.env.ECPAY_CREDIT_CHECK_CODE || "0");
            const creditRefundId = parseInt(String(input.data?.credit_refund_id));
            const creditAmount = Number(input.data?.payment_amount);
            if (isNaN(creditCheckCode) || creditCheckCode === 0) {
                console.log("creditCheckCode is invalid:", creditCheckCode);
                throw new Error("ECPAY_CREDIT_CHECK_CODE is not set in environment variables or invalid");
            }
            if (isNaN(creditRefundId) || creditRefundId === 0) {
                console.log("creditRefundId is invalid:", creditRefundId);
                throw new Error("ECPAY_CREDIT_REFUND_ID is not set in environment variables or invalid");
            }
            if (isNaN(creditAmount) || creditAmount === 0) {
                console.log("creditAmount is invalid:", creditAmount);
                throw new Error("ECPAY_CREDIT_AMOUNT is not set in environment variables or invalid");
            }
            console.log("creditCheckCode:", creditCheckCode);
            console.log("creditRefundId:", creditRefundId);
            console.log("creditAmount:", creditAmount);
            if (creditCheckCode === 0) {
                console.log("process.env.ECPAY_CREDIT_CHECK_CODE", process.env.ECPAY_CREDIT_CHECK_CODE);
                throw new Error("ECPAY_CREDIT_CHECK_CODE is not set in environment variables or invalid");
            }
            if (!creditRefundId || creditRefundId == 0 || creditAmount <= 0) {
                console.log("creditRefundId is empty or creditAmount is invalid:", creditRefundId, creditAmount);
                throw new Error("Invalid creditRefundId or creditAmount");
            }
            // 1. 呼叫查詢信用卡單筆明細記錄API取得訂單狀態
            const ecpayService = ecpays_1.Service.createDefault();
            const creditDetail = await ecpayService.getCreditDetail({
                CreditCheckCode: creditCheckCode,
                CreditRefundId: creditRefundId,
                CreditAmount: creditAmount
            });
            console.log("creditDetail:", creditDetail);
            console.log("creditDetail.RtnValue:", creditDetail.RtnValue);
            console.log("creditDetail.RtnValue.status:", creditDetail.RtnValue.status);
            if (creditDetail.RtnValue.status === "已取消") {
                console.log("訂單已經取消，無法再次退款");
                return {
                    data: input.data
                };
            }
            // 2.判斷訂單close_data中最後一筆amout為正向的資料狀態
            // - 狀態為已授權的時候，可能不會有close data資料
            if (creditDetail.RtnValue.status !== "已授權" && creditDetail.RtnValue.close_data.length == 0) {
                console.log("creditDetail.RtnValue.close_data is empty");
                throw new Error("信用卡退款查詢無法取得訂單狀態");
            }
            let closeAmount = 0;
            if (creditDetail.RtnValue.close_data.length > 0) {
                const closeData = creditDetail.RtnValue.close_data[creditDetail.RtnValue.close_data.length - 1];
                closeAmount = parseInt(closeData.amount);
            }
            else {
                closeAmount = parseInt(creditDetail.RtnValue.amount);
            }
            if (closeAmount <= 0) {
                console.log("The order has been fully refunded already.");
                throw new Error("此筆訂單已經全額退款，無法再進行退款");
            }
            // 3. 查詢後，呼叫信用卡請退款API:
            //   - [已授權]階段: 執行[放棄] (Action=N)可釋放信用卡佔額。
            //   - [要關帳]階段:
            //     - 全額退款: 先執行[取消] (Action=E)，接著進行[放棄] (Action=N)。
            //     - 部份退款: 執行[退刷] (Action=R)。
            //   - [已關帳]階段: 執行[退刷] (Action=R)。
            //   - [操作取消]階段: 執行[放棄] (Action=N)可釋放信用卡佔額。
            // ecpay action 必要資料：
            // - MerchantTradeNo
            const merchantTradeNo = input.data?.merchant_trade_no;
            const tradeNo = input.data?.trade_no;
            const totalAmount = closeAmount;
            if (!merchantTradeNo) {
                console.log("merchantTradeNo is empty:", merchantTradeNo);
                throw new Error("Invalid merchantTradeNo");
            }
            if (!tradeNo) {
                console.log("tradeNo is empty:", tradeNo);
                throw new Error("Invalid tradeNo");
            }
            if (totalAmount <= 0) {
                console.log("totalAmount is invalid:", totalAmount);
                throw new Error("Invalid totalAmount");
            }
            let actionParam = {
                MerchantTradeNo: merchantTradeNo,
                TradeNo: tradeNo,
                TotalAmount: totalAmount,
            };
            let doActionResult = null;
            switch (creditDetail.RtnValue.status) {
                case "已授權":
                    actionParam.Action = "N";
                    doActionResult = await ecpayService.doCreditAction(actionParam);
                    break;
                case "要關帳":
                    actionParam.Action = "E";
                    doActionResult = await ecpayService.doCreditAction(actionParam);
                    if (doActionResult.RtnCode !== 1) {
                        console.log("Failed to perform 'Cancel' action:", doActionResult);
                        throw new Error("取消刷卡失敗" + doActionResult.RtnMsg + ",請聯絡ECPay客服");
                    }
                    actionParam.Action = "N";
                    doActionResult = await ecpayService.doCreditAction(actionParam);
                    break;
                case "已關帳":
                    actionParam.Action = "R";
                    doActionResult = await ecpayService.doCreditAction(actionParam);
                    break;
                case "操作取消":
                    actionParam.Action = "N";
                    doActionResult = await ecpayService.doCreditAction(actionParam);
                    break;
                default:
                    console.log("Unknown order status:", creditDetail.RtnValue.status);
                    throw new Error("Unknown order status, please contact customer service");
            }
            console.log("doCreditAction result:", doActionResult);
            if (doActionResult != null && doActionResult.RtnCode !== 1) {
                console.log("Failed to perform action");
                throw new Error("信用卡退款失敗" + doActionResult.RtnMsg + ",請聯絡ECPay客服");
            }
            return { data: input.data };
        }
        catch (error) {
            console.log("refundPayment error:", error);
            return Promise.reject(error);
        }
    }
    /**
     * retrievePayment
     *
     * - 方法用途：向第三方查詢付款詳情，以回傳最新狀態或資料。
     * - 參數說明：
     *   - `input`: 內含 Payment `data`（例如第三方付款編號），用於第三方查詢付款。
     * - 回傳值說明：
     *   - 回傳第三方付款的資料物件。
     */
    async retrievePayment(input) {
        const action = this.getIdentifier() + " retrievePayment";
        let data = input.data;
        console.log(action, "start retrievePayment with input:", input);
        console.log(action, "retrievePayment input.data:", input.data);
        const tradeNo = input.data?.trade_no;
        const creditCheckCode = parseInt(process.env.ECPAY_CREDIT_CHECK_CODE || "0");
        const creditRefundId = parseInt(String(input.data?.credit_refund_id));
        const creditAmount = Number(input.data?.amount);
        if (!tradeNo) {
            throw new Error("ECPayCreditProviderService.retrievePayment trade_no is missing");
        }
        if (!creditCheckCode || creditCheckCode === 0) {
            console.log("process.env.ECPAY_CREDIT_CHECK_CODE", process.env.ECPAY_CREDIT_CHECK_CODE);
            throw new Error("ECPAY_CREDIT_CHECK_CODE is not set in environment variables or invalid");
        }
        if (!creditRefundId || creditRefundId == 0 || creditAmount <= 0) {
            console.log("creditRefundId is empty or creditAmount is invalid:", creditRefundId, creditAmount);
            throw new Error("Invalid creditRefundId or creditAmount");
        }
        if (!creditAmount || creditAmount <= 0) {
            throw new Error("ECPayCreditProviderService.retrievePayment amount is missing or invalid");
        }
        try {
            const ecpayService = ecpays_1.Service.createDefault();
            const creditDetail = await ecpayService.getCreditDetail({
                CreditCheckCode: creditCheckCode,
                CreditRefundId: creditRefundId,
                CreditAmount: creditAmount
            });
            console.log(action, "getCreditDetail result:", creditDetail);
            console.log(action, "creditDetail.RtnValue:", creditDetail.RtnValue);
            console.log(action, "creditDetail.RtnValue.close_data:", creditDetail.RtnValue.close_data);
            let status = "unknown";
            if (creditDetail.RtnValue.close_data.length == 0) {
                switch (creditDetail.RtnValue.status) {
                    case "已取消":
                        status = "canceled";
                        break;
                    case "未授權":
                        status = "requires_more";
                        break;
                    case "已授權":
                        status = "authorized";
                        break;
                }
            }
            else {
                switch (creditDetail.RtnValue.status) {
                    case "已關帳":
                        status = "captured";
                        break;
                    case "已取消":
                        status = "canceled";
                        break;
                    case "操作取消":
                        status = "canceled";
                        break;
                }
            }
            data = {
                ...data,
                status: status,
            };
            console.log(action, "retrievePayment final data:", data);
            return {
                data: data
            };
        }
        catch (error) {
            console.log("retrievePayment error:", error);
            throw error;
        }
    }
    /**
     * cancelPayment
     *
     * - 方法用途：取消尚未請款的付款（通常用於訂單取消）。
     * - 參數說明：
     *   - `input`: 內含 Payment `data`，用以在第三方執行取消。
     * - 回傳值說明：
     *   - 回傳 `{ data }`（如需回存第三方取消結果）。
     */
    async cancelPayment(input) {
        const action = this.getIdentifier() + " cancelPayment";
        console.log(action, "start cancelPayment with input:", input);
        console.log(action, "cancelPayment input.data:", input.data);
        return {
            data: input.data
        };
    }
    /**
     * updatePayment
     *
     * - 方法用途：更新先前以 `initiatePayment` 建立的付款資訊（如金額、顧客資訊等）。
     * - 參數說明：
     *   - `input`: 內含要更新的欄位與既有 Session `data`。
     * - 回傳值說明：
     *   - 回傳最新的付款資料物件，將覆蓋/合併至 Session 的 `data`。
     */
    async updatePayment(input) {
        const action = this.getIdentifier() + " updatePayment";
        console.log(action, "start updatePayment with input:", input);
        console.log(action, "updatePayment input.data:", input.data);
        const existingData = input.data || {};
        const updatedData = {
            ...existingData,
        };
        return {
            data: updatedData
        };
    }
    /**
     * deletePayment
     *
     * - 方法用途：刪除／作廢已建立但未使用的付款會話（若第三方支援）。
     * - 參數說明：
     *   - `input`: 內含 Session `data`，用以在第三方取消/刪除對應會話。
     * - 回傳值說明：
     *   - 回傳 `{ data }`；可原樣回傳或附上第三方回應結果。
     */
    async deletePayment(input) {
        const action = this.getIdentifier() + " deletePayment";
        console.log(action, "start deletePayment with input:", input);
        console.log(action, "deletePayment input.data:", input.data);
        return {
            data: input.data
        };
    }
    /**
     * getPaymentStatus
     *
     * - 方法用途：查詢付款會話或付款單在第三方的即時狀態，回傳 Medusa 可理解的狀態值。
     * - 參數說明：
     *   - `input`: 內含 Session/Payment `data`，用以在第三方查詢狀態。
     * - 回傳值說明：
     *   - 回傳 `{ status, data? }`；`status` 可能為 `pending`、`authorized`、`captured`、`canceled` 等。
     */
    async getPaymentStatus(input) {
        const action = this.getIdentifier() + " getPaymentStatus";
        console.log(action, "start getPaymentStatus with input:", input);
        console.log(action, "getPaymentStatus input.data:", input.data);
        const status = input.data?.status || "pending";
        return {
            status: status,
            data: input.data
        };
    }
    /**
     * getWebhookActionAndData
     * route: http://localhost:9000/hooks/payment/ecpay_credit_card_ecpay_credit_card
     * - 方法用途：處理第三方金流的 Webhook，並回傳應由 Medusa 採取的動作與所需資料。
     * - 參數說明：
     *   - `payload`: Webhook 原始負載（headers、rawData、解析後資料等）。
     * - 回傳值說明：
     *   - 回傳 `{ action, data }`；`action` 可為 `authorized`、`captured`、`failed`、`not_supported`。
     */
    async getWebhookActionAndData(payload) {
        const action = this.getIdentifier() + " getWebhookActionAndData";
        console.log(action, "start getWebhookActionAndData with payload:", payload);
        // const data = payload.data as 
        throw new Error("ECPayCreditProviderService.getWebhookActionAndData medusa 不支援ECPay Post Form格式");
        // const data = payload.data
        // let paymentSessionID: string = ""
        // if (!data){
        //   throw new Error("payload.data is empty")
        // }
        // if (!data["CustomField4"]){
        //   throw new Error("Payment Session ID is missing")
        // }else if (typeof data["CustomField4"] === "string") {
        //   paymentSessionID = data["CustomField4"]
        // } else {
        //   paymentSessionID = `${data["CustomField4"]}`
        // }
        // if (!data["RtnCode"]){
        //   throw new Error("RtnCode is missing")
        // }
        // // 除了成功以外，都不要更新訂單狀態
        // switch (data["RtnCode"]) {
        //   case "1":
        //     break;
        //   case "10300066":
        //     // 「交易付款結果待確認中，請勿出貨」，請至廠商管理後台確認已付款完成再出貨。
        //     throw new Error("交易付款結果待確認中，請勿出貨")
        //   case "10100248":
        //     // 「拒絕交易，請客戶聯繫發卡行確認原因」
        //     throw new Error("拒絕交易，請客戶聯繫發卡行確認原因")
        //   case "10100252":
        //     // 「額度不足，請客戶檢查卡片額度或餘額」
        //     throw new Error("額度不足，請客戶檢查卡片額度或餘額")
        //   case "10100254":
        //     // 「交易失敗，請客戶聯繫發卡行確認交易限制」
        //     throw new Error("交易失敗，請客戶聯繫發卡行確認交易限制")
        //   case "10100251":
        //     // 「卡片過期，請客戶檢查卡片重新交易」
        //     throw new Error("卡片過期，請客戶檢查卡片重新交易")
        //   case "10100255":
        //     // 「報失卡，請客戶更換卡片重新交易」
        //     throw new Error("報失卡，請客戶更換卡片重新交易")
        //   case "10100256":
        //     // 「停用卡，請客戶更換卡片重新交易」
        //     throw new Error("停用卡，請客戶更換卡片重新交易")
        //   default:
        //     // 其他錯誤代碼
        //     throw new Error("未知錯誤，請聯繫客服")
        // }
        // return {
        //   action: "captured",
        //   data: {
        //     // assuming the session_id is stored in the metadata of the payment
        //     // in the third-party provider
        //     session_id: paymentSessionID,
        //     amount: data["TradeAmt"]?new BigNumber(data["TradeAmt"] as number):0
        //   }
        // }
    }
}
ECPayCreditProviderService.identifier = "ecpay_credit_card";
exports.default = ECPayCreditProviderService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWNwYXljcmVkaXRwcm92aWRlcnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9lY3BheW1lbnRzL2VjcGF5Y3JlZGl0cHJvdmlkZXJzZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEscURBQW1FO0FBd0JuRSwrQkFBbUM7QUFDbkMsbUNBQXlDO0FBQ3pDLGdEQUEwRDtBQUMxRCxrREFBK0M7QUFJL0M7Ozs7O0dBS0c7QUFDSCxNQUFxQiwwQkFBMkIsU0FBUSwrQkFBdUI7SUFJN0U7Ozs7Ozs7O09BUUc7SUFDSCxZQUNxQixTQUFrQyxFQUNsQyxTQUFrQyxFQUFFO1FBRXZELEtBQUssQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUE7UUFITCxjQUFTLEdBQVQsU0FBUyxDQUF5QjtRQUNsQyxXQUFNLEdBQU4sTUFBTSxDQUE4QjtJQUd6RCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxLQUFLLENBQUMsZUFBZSxDQUFDLEtBQTJCO1FBRS9DLEdBQUc7UUFDSCxNQUFNLE1BQU0sR0FBVyxJQUFJLENBQUMsYUFBYSxFQUFFLEdBQUcsa0JBQWtCLENBQUE7UUFFaEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsbUNBQW1DLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFOUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsNkJBQTZCLEVBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFBO1FBRTVELE9BQU87WUFDTCxFQUFFLEVBQUUsSUFBQSxTQUFNLEdBQUU7WUFDWixJQUFJLEVBQUU7Z0JBQ0osUUFBUSxFQUFFLElBQUEsdUJBQWUsR0FBRTtnQkFDM0IsR0FBRyxLQUFLLENBQUMsSUFBSTthQUNkO1NBQ0YsQ0FBQTtJQUNILENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxLQUE0QjtRQUVqRCxNQUFNLE1BQU0sR0FBVyxJQUFJLENBQUMsYUFBYSxFQUFFLEdBQUcsbUJBQW1CLENBQUE7UUFFakUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsb0NBQW9DLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFL0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsOEJBQThCLEVBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFBO1FBRTdELE9BQU07WUFDSixNQUFNLEVBQUMsWUFBb0M7WUFDM0MsSUFBSSxFQUFDLEtBQUssQ0FBQyxJQUFJO1NBQ2hCLENBQUE7SUFDSCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxLQUFLLENBQUMsY0FBYyxDQUFDLEtBQTBCO1FBRTdDLE1BQU0sTUFBTSxHQUFXLElBQUksQ0FBQyxhQUFhLEVBQUUsR0FBRyxpQkFBaUIsQ0FBQTtRQUMvRCxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBQyxrQ0FBa0MsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUU3RCxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBQyw0QkFBNEIsRUFBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDM0QsT0FBTztZQUNMLElBQUksRUFBQyxLQUFLLENBQUMsSUFBSTtTQUNoQixDQUFBO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUF5QjtRQUUzQyw2REFBNkQ7UUFFN0QsTUFBTSxNQUFNLEdBQVcsSUFBSSxDQUFDLGFBQWEsRUFBRSxHQUFHLGdCQUFnQixDQUFBO1FBRTlELE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFDLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxDQUFBO1FBRTVELE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFDLDJCQUEyQixFQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUcxRCxJQUFHLENBQUM7WUFFRiw0QkFBNEI7WUFDNUIsSUFBSSxJQUFBLDJCQUFtQixFQUFDLElBQUksSUFBSSxFQUFFLENBQUMsRUFBQyxDQUFDO2dCQUNuQyxNQUFNLElBQUksS0FBSyxDQUFDLHlDQUF5QyxDQUFDLENBQUE7WUFDNUQsQ0FBQztZQUVELGtCQUFrQjtZQUNsQiwrQkFBK0I7WUFDL0IsZ0RBQWdEO1lBQ2hELHNDQUFzQztZQUN0QyxvQ0FBb0M7WUFFcEMsTUFBTSxlQUFlLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLElBQUksR0FBRyxDQUFDLENBQUE7WUFDNUUsTUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLGdCQUFnQixDQUFDLENBQUMsQ0FBQTtZQUNyRSxNQUFNLFlBQVksR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQTtZQUV2RCxJQUFJLEtBQUssQ0FBQyxlQUFlLENBQUMsSUFBSSxlQUFlLEtBQUssQ0FBQyxFQUFDLENBQUM7Z0JBQ25ELE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLEVBQUUsZUFBZSxDQUFDLENBQUE7Z0JBQzNELE1BQU0sSUFBSSxLQUFLLENBQUMsd0VBQXdFLENBQUMsQ0FBQTtZQUMzRixDQUFDO1lBRUQsSUFBSSxLQUFLLENBQUMsY0FBYyxDQUFDLElBQUksY0FBYyxLQUFLLENBQUMsRUFBQyxDQUFDO2dCQUNqRCxPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixFQUFFLGNBQWMsQ0FBQyxDQUFBO2dCQUN6RCxNQUFNLElBQUksS0FBSyxDQUFDLHVFQUF1RSxDQUFDLENBQUE7WUFDMUYsQ0FBQztZQUVELElBQUksS0FBSyxDQUFDLFlBQVksQ0FBQyxJQUFJLFlBQVksS0FBSyxDQUFDLEVBQUMsQ0FBQztnQkFDN0MsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsRUFBRSxZQUFZLENBQUMsQ0FBQTtnQkFDckQsTUFBTSxJQUFJLEtBQUssQ0FBQyxvRUFBb0UsQ0FBQyxDQUFBO1lBQ3ZGLENBQUM7WUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixFQUFFLGVBQWUsQ0FBQyxDQUFBO1lBQ2hELE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEVBQUUsY0FBYyxDQUFDLENBQUE7WUFDOUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUUsWUFBWSxDQUFDLENBQUE7WUFFMUMsSUFBSSxlQUFlLEtBQUssQ0FBQyxFQUFDLENBQUM7Z0JBQ3pCLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQXFDLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFBO2dCQUN2RixNQUFNLElBQUksS0FBSyxDQUFDLHdFQUF3RSxDQUFDLENBQUE7WUFDM0YsQ0FBQztZQUVELElBQUksQ0FBQyxjQUFjLElBQUksY0FBYyxJQUFJLENBQUMsSUFBSSxZQUFZLElBQUksQ0FBQyxFQUFDLENBQUM7Z0JBQy9ELE9BQU8sQ0FBQyxHQUFHLENBQUMscURBQXFELEVBQUUsY0FBYyxFQUFDLFlBQVksQ0FBQyxDQUFBO2dCQUMvRixNQUFNLElBQUksS0FBSyxDQUFDLHdDQUF3QyxDQUFDLENBQUE7WUFDM0QsQ0FBQztZQUVELDRCQUE0QjtZQUU1QixNQUFNLFlBQVksR0FBRyxnQkFBTyxDQUFDLGFBQWEsRUFBRSxDQUFBO1lBSTVDLE1BQU0sWUFBWSxHQUFHLE1BQU0sWUFBWSxDQUFDLGVBQWUsQ0FBQztnQkFDdEQsZUFBZSxFQUFDLGVBQWU7Z0JBQy9CLGNBQWMsRUFBRSxjQUFjO2dCQUM5QixZQUFZLEVBQUUsWUFBWTthQUMzQixDQUFDLENBQUE7WUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRSxZQUFZLENBQUMsQ0FBQTtZQUUxQyxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixFQUFFLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQTtZQUU1RCxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixFQUFFLFlBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUE7WUFFMUUsSUFBSSxZQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sS0FBSyxLQUFLLEVBQUMsQ0FBQztnQkFDMUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtnQkFDNUIsT0FBTztvQkFDTCxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7aUJBQ2pCLENBQUE7WUFDSCxDQUFDO1lBRUQscUNBQXFDO1lBQ3JDLGdDQUFnQztZQUNoQyxJQUFJLFlBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxLQUFLLEtBQUssSUFBSSxZQUFZLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFDLENBQUM7Z0JBQzFGLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkNBQTJDLENBQUMsQ0FBQTtnQkFDeEQsTUFBTSxJQUFJLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFBO1lBQ3BDLENBQUM7WUFFRCxJQUFJLFdBQVcsR0FBVyxDQUFDLENBQUE7WUFDM0IsSUFBSSxZQUFZLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFDLENBQUM7Z0JBQy9DLE1BQU0sU0FBUyxHQUFHLFlBQVksQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQTtnQkFDL0YsV0FBVyxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUE7WUFDMUMsQ0FBQztpQkFBSSxDQUFDO2dCQUNKLFdBQVcsR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQTtZQUN0RCxDQUFDO1lBRUQsSUFBSSxXQUFXLElBQUksQ0FBQyxFQUFDLENBQUM7Z0JBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsNENBQTRDLENBQUMsQ0FBQTtnQkFDekQsTUFBTSxJQUFJLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFBO1lBQ3ZDLENBQUM7WUFFRCxzQkFBc0I7WUFDdEIsMENBQTBDO1lBQzFDLGVBQWU7WUFDZixzREFBc0Q7WUFDdEQsaUNBQWlDO1lBQ2pDLGtDQUFrQztZQUNsQywyQ0FBMkM7WUFFM0MscUJBQXFCO1lBQ3JCLG9CQUFvQjtZQUVwQixNQUFNLGVBQWUsR0FBRyxLQUFLLENBQUMsSUFBSSxFQUFFLGlCQUFpQixDQUFDO1lBQ3RELE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDO1lBQ3JDLE1BQU0sV0FBVyxHQUFHLFdBQVcsQ0FBQTtZQUUvQixJQUFJLENBQUMsZUFBZSxFQUFDLENBQUM7Z0JBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEVBQUUsZUFBZSxDQUFDLENBQUE7Z0JBQ3pELE1BQU0sSUFBSSxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQTtZQUM1QyxDQUFDO1lBRUQsSUFBSSxDQUFDLE9BQU8sRUFBQyxDQUFDO2dCQUNaLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsT0FBTyxDQUFDLENBQUE7Z0JBQ3pDLE1BQU0sSUFBSSxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQTtZQUNwQyxDQUFDO1lBRUQsSUFBSSxXQUFXLElBQUksQ0FBQyxFQUFDLENBQUM7Z0JBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLEVBQUUsV0FBVyxDQUFDLENBQUE7Z0JBQ25ELE1BQU0sSUFBSSxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQTtZQUN4QyxDQUFDO1lBRUQsSUFBSSxXQUFXLEdBQTZCO2dCQUMxQyxlQUFlLEVBQUMsZUFBZTtnQkFDL0IsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLFdBQVcsRUFBRSxXQUFXO2FBQ0csQ0FBQTtZQUc3QixJQUFJLGNBQWMsR0FBcUMsSUFBSSxDQUFBO1lBRTNELFFBQVEsWUFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUMsQ0FBQztnQkFDcEMsS0FBSyxLQUFLO29CQUNSLFdBQVcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFBO29CQUN4QixjQUFjLEdBQUcsTUFBTSxZQUFZLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFBO29CQUMvRCxNQUFLO2dCQUNQLEtBQUssS0FBSztvQkFFUixXQUFXLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQTtvQkFDeEIsY0FBYyxHQUFHLE1BQU0sWUFBWSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQTtvQkFFL0QsSUFBSSxjQUFjLENBQUMsT0FBTyxLQUFLLENBQUMsRUFBQyxDQUFDO3dCQUNoQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxFQUFFLGNBQWMsQ0FBQyxDQUFBO3dCQUNqRSxNQUFNLElBQUksS0FBSyxDQUFDLFFBQVEsR0FBQyxjQUFjLENBQUMsTUFBTSxHQUFDLGFBQWEsQ0FBQyxDQUFBO29CQUMvRCxDQUFDO29CQUVELFdBQVcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFBO29CQUN4QixjQUFjLEdBQUcsTUFBTSxZQUFZLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFBO29CQUUvRCxNQUFLO2dCQUNQLEtBQUssS0FBSztvQkFDUixXQUFXLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQTtvQkFDeEIsY0FBYyxHQUFHLE1BQU0sWUFBWSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQTtvQkFDL0QsTUFBSztnQkFDUCxLQUFLLE1BQU07b0JBQ1QsV0FBVyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUE7b0JBQ3hCLGNBQWMsR0FBRyxNQUFNLFlBQVksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUE7b0JBQy9ELE1BQUs7Z0JBQ1A7b0JBQ0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsRUFBRSxZQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFBO29CQUNsRSxNQUFNLElBQUksS0FBSyxDQUFDLHVEQUF1RCxDQUFDLENBQUE7WUFDNUUsQ0FBQztZQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLEVBQUUsY0FBYyxDQUFDLENBQUE7WUFFckQsSUFBSSxjQUFjLElBQUksSUFBSSxJQUFJLGNBQWMsQ0FBQyxPQUFPLEtBQUssQ0FBQyxFQUFDLENBQUM7Z0JBRTFELE9BQU8sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLENBQUMsQ0FBQTtnQkFDdkMsTUFBTSxJQUFJLEtBQUssQ0FBQyxTQUFTLEdBQUMsY0FBYyxDQUFDLE1BQU0sR0FBQyxhQUFhLENBQUMsQ0FBQTtZQUVoRSxDQUFDO1lBRUQsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUE7UUFFN0IsQ0FBQztRQUFBLE9BQU0sS0FBSyxFQUFDLENBQUM7WUFDWixPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxDQUFBO1lBQzFDLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQTtRQUM5QixDQUFDO0lBRUgsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsS0FBSyxDQUFDLGVBQWUsQ0FBQyxLQUEyQjtRQUUvQyxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFLEdBQUcsa0JBQWtCLENBQUE7UUFFeEQsSUFBSSxJQUFJLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQTtRQUVyQixPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBQyxtQ0FBbUMsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUU5RCxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBQyw2QkFBNkIsRUFBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUE7UUFFNUQsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRSxRQUFRLENBQUE7UUFDcEMsTUFBTSxlQUFlLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLElBQUksR0FBRyxDQUFDLENBQUE7UUFDNUUsTUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLGdCQUFnQixDQUFDLENBQUMsQ0FBQTtRQUNyRSxNQUFNLFlBQVksR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQTtRQUUvQyxJQUFJLENBQUMsT0FBTyxFQUFDLENBQUM7WUFDWixNQUFNLElBQUksS0FBSyxDQUFDLGdFQUFnRSxDQUFDLENBQUE7UUFDbkYsQ0FBQztRQUVELElBQUksQ0FBQyxlQUFlLElBQUksZUFBZSxLQUFLLENBQUMsRUFBQyxDQUFDO1lBQzdDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQXFDLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFBO1lBQ3ZGLE1BQU0sSUFBSSxLQUFLLENBQUMsd0VBQXdFLENBQUMsQ0FBQTtRQUMzRixDQUFDO1FBRUQsSUFBSSxDQUFDLGNBQWMsSUFBSSxjQUFjLElBQUksQ0FBQyxJQUFJLFlBQVksSUFBSSxDQUFDLEVBQUMsQ0FBQztZQUMvRCxPQUFPLENBQUMsR0FBRyxDQUFDLHFEQUFxRCxFQUFFLGNBQWMsRUFBQyxZQUFZLENBQUMsQ0FBQTtZQUMvRixNQUFNLElBQUksS0FBSyxDQUFDLHdDQUF3QyxDQUFDLENBQUE7UUFDM0QsQ0FBQztRQUVELElBQUksQ0FBQyxZQUFZLElBQUksWUFBWSxJQUFJLENBQUMsRUFBQyxDQUFDO1lBQ3RDLE1BQU0sSUFBSSxLQUFLLENBQUMseUVBQXlFLENBQUMsQ0FBQTtRQUM1RixDQUFDO1FBR0QsSUFBRyxDQUFDO1lBR0YsTUFBTSxZQUFZLEdBQUcsZ0JBQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQTtZQUU1QyxNQUFNLFlBQVksR0FBRyxNQUFNLFlBQVksQ0FBQyxlQUFlLENBQUM7Z0JBQ3RELGVBQWUsRUFBQyxlQUFlO2dCQUMvQixjQUFjLEVBQUUsY0FBYztnQkFDOUIsWUFBWSxFQUFFLFlBQVk7YUFDM0IsQ0FBQyxDQUFBO1lBRUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMseUJBQXlCLEVBQUUsWUFBWSxDQUFDLENBQUE7WUFDM0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsd0JBQXdCLEVBQUUsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFBO1lBQ25FLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFDLG1DQUFtQyxFQUFFLFlBQVksQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUE7WUFFekYsSUFBSSxNQUFNLEdBQUcsU0FBUyxDQUFBO1lBRXRCLElBQUksWUFBWSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBQyxDQUFDO2dCQUNoRCxRQUFRLFlBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFDLENBQUM7b0JBQ3BDLEtBQUssS0FBSzt3QkFDUixNQUFNLEdBQUcsVUFBVSxDQUFBO3dCQUNuQixNQUFLO29CQUNQLEtBQUssS0FBSzt3QkFDUixNQUFNLEdBQUcsZUFBZSxDQUFBO3dCQUN4QixNQUFLO29CQUNQLEtBQUssS0FBSzt3QkFDUixNQUFNLEdBQUcsWUFBWSxDQUFBO3dCQUNyQixNQUFLO2dCQUNULENBQUM7WUFDSCxDQUFDO2lCQUFJLENBQUM7Z0JBRUosUUFBUSxZQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBQyxDQUFDO29CQUNwQyxLQUFLLEtBQUs7d0JBQ1IsTUFBTSxHQUFHLFVBQVUsQ0FBQTt3QkFDbkIsTUFBSztvQkFDUCxLQUFLLEtBQUs7d0JBQ1IsTUFBTSxHQUFHLFVBQVUsQ0FBQTt3QkFDbkIsTUFBSztvQkFDUCxLQUFLLE1BQU07d0JBQ1QsTUFBTSxHQUFHLFVBQVUsQ0FBQTt3QkFDbkIsTUFBSztnQkFDVCxDQUFDO1lBRUgsQ0FBQztZQUVELElBQUksR0FBRztnQkFDTCxHQUFHLElBQUk7Z0JBQ1AsTUFBTSxFQUFFLE1BQU07YUFDZixDQUFBO1lBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsNkJBQTZCLEVBQUUsSUFBSSxDQUFDLENBQUE7WUFFdkQsT0FBTztnQkFDTCxJQUFJLEVBQUUsSUFBSTthQUNYLENBQUE7UUFFSCxDQUFDO1FBQUEsT0FBTSxLQUFLLEVBQUMsQ0FBQztZQUNaLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLEVBQUUsS0FBSyxDQUFDLENBQUE7WUFDNUMsTUFBTSxLQUFLLENBQUE7UUFDYixDQUFDO0lBRUgsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUF5QjtRQUMzQyxNQUFNLE1BQU0sR0FBVyxJQUFJLENBQUMsYUFBYSxFQUFFLEdBQUcsZ0JBQWdCLENBQUE7UUFDOUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsaUNBQWlDLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDNUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsMkJBQTJCLEVBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFBO1FBQzFELE9BQU87WUFDTCxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7U0FDakIsQ0FBQTtJQUNILENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBeUI7UUFDM0MsTUFBTSxNQUFNLEdBQVcsSUFBSSxDQUFDLGFBQWEsRUFBRSxHQUFHLGdCQUFnQixDQUFBO1FBQzlELE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFDLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQzVELE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFDLDJCQUEyQixFQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUcxRCxNQUFNLFlBQVksR0FBRyxLQUFLLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQTtRQUVyQyxNQUFNLFdBQVcsR0FBRztZQUNsQixHQUFHLFlBQVk7U0FDaEIsQ0FBQTtRQUVELE9BQU87WUFDTCxJQUFJLEVBQUUsV0FBVztTQUNsQixDQUFBO0lBRUgsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUF5QjtRQUMzQyxNQUFNLE1BQU0sR0FBVyxJQUFJLENBQUMsYUFBYSxFQUFFLEdBQUcsZ0JBQWdCLENBQUE7UUFDOUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsaUNBQWlDLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDNUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsMkJBQTJCLEVBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFBO1FBQzFELE9BQU87WUFDTCxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7U0FDakIsQ0FBQTtJQUNILENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxLQUE0QjtRQUdqRCxNQUFNLE1BQU0sR0FBVyxJQUFJLENBQUMsYUFBYSxFQUFFLEdBQUcsbUJBQW1CLENBQUE7UUFFakUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsb0NBQW9DLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDL0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsOEJBQThCLEVBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFBO1FBRTdELE1BQU0sTUFBTSxHQUF5QixLQUFLLENBQUMsSUFBSSxFQUFFLE1BQThCLElBQUksU0FBUyxDQUFBO1FBRzVGLE9BQU87WUFDTCxNQUFNLEVBQUUsTUFBTTtZQUNkLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTtTQUNqQixDQUFBO0lBRUgsQ0FBQztJQUVEOzs7Ozs7OztPQVFHO0lBQ0gsS0FBSyxDQUFDLHVCQUF1QixDQUMzQixPQUEwQztRQUcxQyxNQUFNLE1BQU0sR0FBVyxJQUFJLENBQUMsYUFBYSxFQUFFLEdBQUcsMEJBQTBCLENBQUE7UUFDeEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUMsNkNBQTZDLEVBQUUsT0FBTyxDQUFDLENBQUE7UUFDMUUsZ0NBQWdDO1FBRWhDLE1BQU0sSUFBSSxLQUFLLENBQUMsZ0ZBQWdGLENBQUMsQ0FBQTtRQUNqRyw0QkFBNEI7UUFDNUIsb0NBQW9DO1FBRXBDLGNBQWM7UUFDZCw2Q0FBNkM7UUFDN0MsSUFBSTtRQUVKLDhCQUE4QjtRQUM5QixxREFBcUQ7UUFDckQsd0RBQXdEO1FBQ3hELDRDQUE0QztRQUM1QyxXQUFXO1FBQ1gsaURBQWlEO1FBQ2pELElBQUk7UUFFSix5QkFBeUI7UUFDekIsMENBQTBDO1FBQzFDLElBQUk7UUFFSixzQkFBc0I7UUFDdEIsNkJBQTZCO1FBQzdCLGNBQWM7UUFDZCxhQUFhO1FBQ2IscUJBQXFCO1FBQ3JCLCtDQUErQztRQUMvQyx5Q0FBeUM7UUFDekMscUJBQXFCO1FBQ3JCLDZCQUE2QjtRQUM3QiwyQ0FBMkM7UUFDM0MscUJBQXFCO1FBQ3JCLDZCQUE2QjtRQUM3QiwyQ0FBMkM7UUFDM0MscUJBQXFCO1FBQ3JCLCtCQUErQjtRQUMvQiw2Q0FBNkM7UUFDN0MscUJBQXFCO1FBQ3JCLDRCQUE0QjtRQUM1QiwwQ0FBMEM7UUFDMUMscUJBQXFCO1FBQ3JCLDJCQUEyQjtRQUMzQix5Q0FBeUM7UUFDekMscUJBQXFCO1FBQ3JCLDJCQUEyQjtRQUMzQix5Q0FBeUM7UUFDekMsYUFBYTtRQUNiLGdCQUFnQjtRQUNoQixvQ0FBb0M7UUFDcEMsSUFBSTtRQUdKLFdBQVc7UUFDWCx3QkFBd0I7UUFDeEIsWUFBWTtRQUNaLDBFQUEwRTtRQUMxRSxxQ0FBcUM7UUFDckMsb0NBQW9DO1FBQ3BDLDJFQUEyRTtRQUMzRSxNQUFNO1FBQ04sSUFBSTtJQUVOLENBQUM7O0FBbGpCTSxxQ0FBVSxHQUFHLG1CQUFtQixDQUFBO2tCQUZwQiwwQkFBMEIifQ==