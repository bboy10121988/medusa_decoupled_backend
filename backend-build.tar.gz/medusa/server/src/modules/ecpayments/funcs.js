"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getECPayFormURL = getECPayFormURL;
const environment_1 = require("../../internal/configs/environment");
/**
 * getECPayFormURL
 *
 * - 方法用途：根據環境模式回傳對應的 ECPay 付款表單 URL。
 * - 參數說明：無。
 * - 回傳值說明：
 *   - 生產環境回傳正式環境 URL，否則回傳測試環境 URL。
 * - 備註：
 *   - 測試環境：https://payment-stage.ecpay.com.tw/Cashier/AioCheckOut/V5
 *   - 正式環境：https://payment.ecpay.com.tw/Cashier/AioCheckOut/V5
 */
function getECPayFormURL() {
    if ((0, environment_1.isEnvironmentModeProd)()) {
        return "https://payment.ecpay.com.tw/Cashier/AioCheckOut/V5";
    }
    return "https://payment-stage.ecpay.com.tw/Cashier/AioCheckOut/V5";
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnVuY3MuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9lY3BheW1lbnRzL2Z1bmNzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBb0JTLDBDQUFlO0FBcEJ4QixvRUFBMEU7QUFFMUU7Ozs7Ozs7Ozs7R0FVRztBQUNILFNBQVMsZUFBZTtJQUN0QixJQUFJLElBQUEsbUNBQXFCLEdBQUUsRUFBRSxDQUFDO1FBQzVCLE9BQU8scURBQXFELENBQUE7SUFDOUQsQ0FBQztJQUNELE9BQU8sMkRBQTJELENBQUE7QUFDcEUsQ0FBQyJ9