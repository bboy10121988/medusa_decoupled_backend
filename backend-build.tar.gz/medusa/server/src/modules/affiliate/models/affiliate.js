"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Affiliate = void 0;
const utils_1 = require("@medusajs/framework/utils");
const affiliate_link_1 = require("./affiliate-link");
const affiliate_click_1 = require("./affiliate-click");
const affiliate_conversion_1 = require("./affiliate-conversion");
const affiliate_settlement_1 = require("./affiliate-settlement");
exports.Affiliate = utils_1.model.define("affiliate", {
    id: utils_1.model.id().primaryKey(),
    email: utils_1.model.text().unique(),
    password_hash: utils_1.model.text().nullable(), // For simple email/pass auth
    first_name: utils_1.model.text().nullable(),
    last_name: utils_1.model.text().nullable(),
    phone: utils_1.model.text().nullable(),
    code: utils_1.model.text().unique(), // The main referral code for the affiliate
    balance: utils_1.model.bigNumber().default(0),
    total_earnings: utils_1.model.bigNumber().default(0),
    status: utils_1.model.enum(["pending", "active", "rejected", "suspended"]).default("pending"),
    settings: utils_1.model.json().default({}), // Stores payment info, notification prefs
    metadata: utils_1.model.json().nullable(),
    links: utils_1.model.hasMany(() => affiliate_link_1.AffiliateLink, { mappedBy: "affiliate" }),
    clicks: utils_1.model.hasMany(() => affiliate_click_1.AffiliateClick, { mappedBy: "affiliate" }),
    conversions: utils_1.model.hasMany(() => affiliate_conversion_1.AffiliateConversion, { mappedBy: "affiliate" }),
    settlements: utils_1.model.hasMany(() => affiliate_settlement_1.AffiliateSettlement, { mappedBy: "affiliate" }),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWZmaWxpYXRlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvYWZmaWxpYXRlL21vZGVscy9hZmZpbGlhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQWlEO0FBQ2pELHFEQUFnRDtBQUNoRCx1REFBa0Q7QUFDbEQsaUVBQTREO0FBQzVELGlFQUE0RDtBQUUvQyxRQUFBLFNBQVMsR0FBRyxhQUFLLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRTtJQUNqRCxFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRTtJQUMzQixLQUFLLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sRUFBRTtJQUM1QixhQUFhLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFFLDZCQUE2QjtJQUNyRSxVQUFVLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNuQyxTQUFTLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNsQyxLQUFLLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUM5QixJQUFJLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sRUFBRSxFQUFFLDJDQUEyQztJQUN4RSxPQUFPLEVBQUUsYUFBSyxDQUFDLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDckMsY0FBYyxFQUFFLGFBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQzVDLE1BQU0sRUFBRSxhQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO0lBQ3JGLFFBQVEsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFLDBDQUEwQztJQUM5RSxRQUFRLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNqQyxLQUFLLEVBQUUsYUFBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyw4QkFBYSxFQUFFLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxDQUFDO0lBQ3BFLE1BQU0sRUFBRSxhQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLGdDQUFjLEVBQUUsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLENBQUM7SUFDdEUsV0FBVyxFQUFFLGFBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsMENBQW1CLEVBQUUsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLENBQUM7SUFDaEYsV0FBVyxFQUFFLGFBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsMENBQW1CLEVBQUUsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLENBQUM7Q0FDakYsQ0FBQyxDQUFBIn0=