"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AffiliateClick = void 0;
const utils_1 = require("@medusajs/framework/utils");
const affiliate_1 = require("./affiliate");
const affiliate_link_1 = require("./affiliate-link");
exports.AffiliateClick = utils_1.model.define("affiliate_click", {
    id: utils_1.model.id().primaryKey(),
    ip: utils_1.model.text().nullable(),
    user_agent: utils_1.model.text().nullable(),
    metadata: utils_1.model.json().nullable(),
    affiliate: utils_1.model.belongsTo(() => affiliate_1.Affiliate, { mappedBy: "clicks" }),
    link: utils_1.model.belongsTo(() => affiliate_link_1.AffiliateLink, { mappedBy: "clicks_details" }),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWZmaWxpYXRlLWNsaWNrLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvYWZmaWxpYXRlL21vZGVscy9hZmZpbGlhdGUtY2xpY2sudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQWlEO0FBQ2pELDJDQUF1QztBQUN2QyxxREFBZ0Q7QUFFbkMsUUFBQSxjQUFjLEdBQUcsYUFBSyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRTtJQUM1RCxFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRTtJQUMzQixFQUFFLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUMzQixVQUFVLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNuQyxRQUFRLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNqQyxTQUFTLEVBQUUsYUFBSyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxxQkFBUyxFQUFFLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxDQUFDO0lBQ25FLElBQUksRUFBRSxhQUFLLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLDhCQUFhLEVBQUUsRUFBRSxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsQ0FBQztDQUMzRSxDQUFDLENBQUEifQ==