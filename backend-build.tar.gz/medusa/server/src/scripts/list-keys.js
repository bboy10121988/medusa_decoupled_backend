"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const listKeys = async function ({ container }) {
    try {
        // 嘗試直接查詢資料庫
        const dbManager = container.resolve('dbManager');
        const dbClient = dbManager.getClient();
        const result = await dbClient.query('SELECT * FROM publishable_api_key');
        console.log('Database publishable keys:', result.rows);
        if (result.rows.length === 0) {
            // 如果沒有 key，創建一個
            const insertResult = await dbClient.query('INSERT INTO publishable_api_key (id, title, created_at, updated_at) VALUES (?, ?, ?, ?) RETURNING *', ['pk_' + Math.random().toString(36).substr(2, 48), 'Default Store Key', new Date(), new Date()]);
            console.log('Created new key:', insertResult.rows[0]);
        }
    }
    catch (error) {
        console.error('Error:', error);
    }
};
exports.default = listKeys;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGlzdC1rZXlzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NjcmlwdHMvbGlzdC1rZXlzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBRUEsTUFBTSxRQUFRLEdBQUcsS0FBSyxXQUFXLEVBQUUsU0FBUyxFQUFZO0lBQ3RELElBQUksQ0FBQztRQUNILFlBQVk7UUFDWixNQUFNLFNBQVMsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBNkIsQ0FBQTtRQUM1RSxNQUFNLFFBQVEsR0FBRyxTQUFTLENBQUMsU0FBUyxFQUFFLENBQUE7UUFDdEMsTUFBTSxNQUFNLEdBQUcsTUFBTSxRQUFRLENBQUMsS0FBSyxDQUFDLG1DQUFtQyxDQUFDLENBQUE7UUFDeEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUE7UUFFdEQsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUM3QixnQkFBZ0I7WUFDaEIsTUFBTSxZQUFZLEdBQUcsTUFBTSxRQUFRLENBQUMsS0FBSyxDQUN2QyxxR0FBcUcsRUFDckcsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLG1CQUFtQixFQUFFLElBQUksSUFBSSxFQUFFLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxDQUNoRyxDQUFBO1lBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFDdkQsQ0FBQztJQUNILENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUE7SUFDaEMsQ0FBQztBQUNILENBQUMsQ0FBQTtBQUVELGtCQUFlLFFBQVEsQ0FBQSJ9