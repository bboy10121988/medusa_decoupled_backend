"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const createPublishableKey = async function ({ container }) {
    // 添加明確的類型宣告
    const publishableKeyModuleService = container.resolve('publishableKeyModuleService');
    try {
        // 先嘗試列出現有的 keys
        const existingKeys = await publishableKeyModuleService.listPublishableKeys();
        console.log('現有的 publishable keys:', existingKeys.length);
        if (existingKeys.length > 0) {
            console.log('✅ 使用現有的 publishable key:', existingKeys[0].id);
            return existingKeys[0].id;
        }
        // 如果沒有現有的 key，創建新的
        const newKey = await publishableKeyModuleService.createPublishableKeys({
            title: 'Default Store Key'
        });
        console.log('✅ 創建的新 publishable key:', newKey.id);
        return newKey.id;
    }
    catch (error) {
        console.error('❌ 處理 publishable key 失敗:', error);
        throw error;
    }
};
exports.default = createPublishableKey;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLXB1Ymxpc2hhYmxlLWtleS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zY3JpcHRzL2NyZWF0ZS1wdWJsaXNoYWJsZS1rZXkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxNQUFNLG9CQUFvQixHQUFHLEtBQUssV0FBVyxFQUFFLFNBQVMsRUFBWTtJQUNsRSxZQUFZO0lBQ1osTUFBTSwyQkFBMkIsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLDZCQUE2QixDQUdsRixDQUFBO0lBRUQsSUFBSSxDQUFDO1FBQ0gsZ0JBQWdCO1FBQ2hCLE1BQU0sWUFBWSxHQUFHLE1BQU0sMkJBQTJCLENBQUMsbUJBQW1CLEVBQUUsQ0FBQTtRQUM1RSxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixFQUFFLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUV6RCxJQUFJLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDNUIsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUE7WUFDM0QsT0FBTyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO1FBQzNCLENBQUM7UUFFRCxtQkFBbUI7UUFDbkIsTUFBTSxNQUFNLEdBQUcsTUFBTSwyQkFBMkIsQ0FBQyxxQkFBcUIsQ0FBQztZQUNyRSxLQUFLLEVBQUUsbUJBQW1CO1NBQzNCLENBQUMsQ0FBQTtRQUVGLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBQ2pELE9BQU8sTUFBTSxDQUFDLEVBQUUsQ0FBQTtJQUNsQixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsMEJBQTBCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDaEQsTUFBTSxLQUFLLENBQUE7SUFDYixDQUFDO0FBQ0gsQ0FBQyxDQUFBO0FBRUQsa0JBQWUsb0JBQW9CLENBQUEifQ==