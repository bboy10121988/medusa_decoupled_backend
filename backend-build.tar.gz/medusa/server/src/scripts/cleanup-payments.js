"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = cleanupInvalidPayments;
/**
 * 清理無效的 Payment 記錄
 * 修復 "Payment with id xxx not found" 錯誤
 */
async function cleanupInvalidPayments({ container }) {
    const logger = container.resolve("logger");
    const query = container.resolve("query");
    try {
        logger.info("🔍 開始檢查無效的 Payment 記錄...");
        // 查找所有訂單及其關聯的 payments
        const { data: orders } = await query.graph({
            entity: "order",
            fields: ["id", "payments.*"],
        });
        logger.info(`📊 找到 ${orders.length} 個訂單`);
        let invalidPaymentCount = 0;
        for (const order of orders) {
            const orderWithPayments = order;
            if (orderWithPayments.payments && orderWithPayments.payments.length > 0) {
                for (const payment of orderWithPayments.payments) {
                    // 檢查 payment 是否有效
                    if (!payment || !payment.id) {
                        invalidPaymentCount++;
                        logger.warn(`⚠️ 發現無效的 payment 在訂單 ${order.id}`);
                    }
                }
            }
        }
        if (invalidPaymentCount === 0) {
            logger.info("✅ 沒有發現無效的 Payment 記錄");
        }
        else {
            logger.info(`🔧 發現 ${invalidPaymentCount} 個無效的 Payment 記錄`);
            logger.info("建議手動清理這些記錄或聯繫技術支援");
        }
        // 檢查特定的 Payment ID (如果在環境變數中指定)
        const problematicPaymentId = process.env.CHECK_PAYMENT_ID || "pay_01K6YNDWH90JBY1RDXWT1AGBA6";
        try {
            const { data: specificPayments } = await query.graph({
                entity: "payment",
                fields: ["id", "amount", "currency_code", "status"],
                filters: { id: problematicPaymentId }
            });
            if (specificPayments.length === 0) {
                logger.warn(`❌ Payment ID ${problematicPaymentId} 不存在於資料庫中`);
                logger.info("這可能是舊的或已刪除的 payment 記錄引起的快取問題");
            }
            else {
                logger.info(`✅ Payment ID ${problematicPaymentId} 存在且狀態正常`);
            }
        }
        catch (error) {
            logger.error(`❌ 檢查 Payment ID ${problematicPaymentId} 時發生錯誤:`, error.message);
        }
    }
    catch (error) {
        logger.error("❌ 清理 Payment 記錄時發生錯誤:", error);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xlYW51cC1wYXltZW50cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zY3JpcHRzL2NsZWFudXAtcGF5bWVudHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFNQSx5Q0E0REM7QUFoRUQ7OztHQUdHO0FBQ1ksS0FBSyxVQUFVLHNCQUFzQixDQUFDLEVBQUUsU0FBUyxFQUFZO0lBQzFFLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUE7SUFDMUMsTUFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQTtJQUV4QyxJQUFJLENBQUM7UUFDSCxNQUFNLENBQUMsSUFBSSxDQUFDLDBCQUEwQixDQUFDLENBQUE7UUFFdkMsdUJBQXVCO1FBQ3ZCLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1lBQ3pDLE1BQU0sRUFBRSxPQUFPO1lBQ2YsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLFlBQVksQ0FBQztTQUM3QixDQUFDLENBQUE7UUFFRixNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsTUFBTSxDQUFDLE1BQU0sTUFBTSxDQUFDLENBQUE7UUFFekMsSUFBSSxtQkFBbUIsR0FBRyxDQUFDLENBQUE7UUFFM0IsS0FBSyxNQUFNLEtBQUssSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUMzQixNQUFNLGlCQUFpQixHQUFHLEtBQVksQ0FBQTtZQUN0QyxJQUFJLGlCQUFpQixDQUFDLFFBQVEsSUFBSSxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUN4RSxLQUFLLE1BQU0sT0FBTyxJQUFJLGlCQUFpQixDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUNqRCxrQkFBa0I7b0JBQ2xCLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLENBQUM7d0JBQzVCLG1CQUFtQixFQUFFLENBQUE7d0JBQ3JCLE1BQU0sQ0FBQyxJQUFJLENBQUMsd0JBQXdCLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFBO29CQUNqRCxDQUFDO2dCQUNILENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztRQUVELElBQUksbUJBQW1CLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDOUIsTUFBTSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFBO1FBQ3JDLENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLG1CQUFtQixrQkFBa0IsQ0FBQyxDQUFBO1lBQzNELE1BQU0sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQTtRQUNsQyxDQUFDO1FBRUQsZ0NBQWdDO1FBQ2hDLE1BQU0sb0JBQW9CLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsSUFBSSxnQ0FBZ0MsQ0FBQTtRQUU3RixJQUFJLENBQUM7WUFDSCxNQUFNLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO2dCQUNuRCxNQUFNLEVBQUUsU0FBUztnQkFDakIsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxlQUFlLEVBQUUsUUFBUSxDQUFDO2dCQUNuRCxPQUFPLEVBQUUsRUFBRSxFQUFFLEVBQUUsb0JBQW9CLEVBQUU7YUFDdEMsQ0FBQyxDQUFBO1lBRUYsSUFBSSxnQkFBZ0IsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ2xDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLG9CQUFvQixXQUFXLENBQUMsQ0FBQTtnQkFDNUQsTUFBTSxDQUFDLElBQUksQ0FBQywrQkFBK0IsQ0FBQyxDQUFBO1lBQzlDLENBQUM7aUJBQU0sQ0FBQztnQkFDTixNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixvQkFBb0IsVUFBVSxDQUFDLENBQUE7WUFDN0QsQ0FBQztRQUNILENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsTUFBTSxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsb0JBQW9CLFNBQVMsRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUE7UUFDL0UsQ0FBQztJQUVILENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsTUFBTSxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLENBQUMsQ0FBQTtJQUM5QyxDQUFDO0FBQ0gsQ0FBQyJ9